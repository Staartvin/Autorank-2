package org.apache.commons.pool;

import java.util.NoSuchElementException;

public abstract interface ObjectPool<T>
{
  public abstract T borrowObject()
    throws Exception, NoSuchElementException, IllegalStateException;

  public abstract void returnObject(T paramT)
    throws Exception;

  public abstract void invalidateObject(T paramT)
    throws Exception;

  public abstract void addObject()
    throws Exception, IllegalStateException, UnsupportedOperationException;

  public abstract int getNumIdle()
    throws UnsupportedOperationException;

  public abstract int getNumActive()
    throws UnsupportedOperationException;

  public abstract void clear()
    throws Exception, UnsupportedOperationException;

  public abstract void close()
    throws Exception;

  @Deprecated
  public abstract void setFactory(PoolableObjectFactory<T> paramPoolableObjectFactory)
    throws IllegalStateException, UnsupportedOperationException;
}

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.pool.ObjectPool
 * JD-Core Version:    0.6.2
 */