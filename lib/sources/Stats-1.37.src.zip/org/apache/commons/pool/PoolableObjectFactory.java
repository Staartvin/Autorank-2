package org.apache.commons.pool;

public abstract interface PoolableObjectFactory<T>
{
  public abstract T makeObject()
    throws Exception;

  public abstract void destroyObject(T paramT)
    throws Exception;

  public abstract boolean validateObject(T paramT);

  public abstract void activateObject(T paramT)
    throws Exception;

  public abstract void passivateObject(T paramT)
    throws Exception;
}

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.pool.PoolableObjectFactory
 * JD-Core Version:    0.6.2
 */