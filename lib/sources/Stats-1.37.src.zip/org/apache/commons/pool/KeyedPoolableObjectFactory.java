package org.apache.commons.pool;

public abstract interface KeyedPoolableObjectFactory<K, V>
{
  public abstract V makeObject(K paramK)
    throws Exception;

  public abstract void destroyObject(K paramK, V paramV)
    throws Exception;

  public abstract boolean validateObject(K paramK, V paramV);

  public abstract void activateObject(K paramK, V paramV)
    throws Exception;

  public abstract void passivateObject(K paramK, V paramV)
    throws Exception;
}

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.pool.KeyedPoolableObjectFactory
 * JD-Core Version:    0.6.2
 */