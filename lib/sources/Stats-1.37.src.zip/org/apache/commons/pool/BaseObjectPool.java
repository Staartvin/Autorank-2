/*     */ package org.apache.commons.pool;
/*     */ 
/*     */ public abstract class BaseObjectPool<T>
/*     */   implements ObjectPool<T>
/*     */ {
/* 145 */   private volatile boolean closed = false;
/*     */ 
/*     */   public abstract T borrowObject()
/*     */     throws Exception;
/*     */ 
/*     */   public abstract void returnObject(T paramT)
/*     */     throws Exception;
/*     */ 
/*     */   public abstract void invalidateObject(T paramT)
/*     */     throws Exception;
/*     */ 
/*     */   public int getNumIdle()
/*     */     throws UnsupportedOperationException
/*     */   {
/*  69 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getNumActive()
/*     */     throws UnsupportedOperationException
/*     */   {
/*  79 */     return -1;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */     throws Exception, UnsupportedOperationException
/*     */   {
/*  88 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void addObject()
/*     */     throws Exception, UnsupportedOperationException
/*     */   {
/*  99 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws Exception
/*     */   {
/* 107 */     this.closed = true;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setFactory(PoolableObjectFactory<T> factory)
/*     */     throws IllegalStateException, UnsupportedOperationException
/*     */   {
/* 122 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public final boolean isClosed()
/*     */   {
/* 130 */     return this.closed;
/*     */   }
/*     */ 
/*     */   protected final void assertOpen()
/*     */     throws IllegalStateException
/*     */   {
/* 139 */     if (isClosed())
/* 140 */       throw new IllegalStateException("Pool not open");
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.pool.BaseObjectPool
 * JD-Core Version:    0.6.2
 */