package org.apache.commons.pool;

public abstract interface KeyedObjectPoolFactory<K, V>
{
  public abstract KeyedObjectPool<K, V> createPool()
    throws IllegalStateException;
}

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.pool.KeyedObjectPoolFactory
 * JD-Core Version:    0.6.2
 */