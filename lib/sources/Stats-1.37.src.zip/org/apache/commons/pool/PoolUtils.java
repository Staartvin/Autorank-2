/*      */ package org.apache.commons.pool;
/*      */ 
/*      */ import java.util.Collection;
/*      */ import java.util.Collections;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Timer;
/*      */ import java.util.TimerTask;
/*      */ 
/*      */ public final class PoolUtils
/*      */ {
/*      */   private static Timer MIN_IDLE_TIMER;
/*      */ 
/*      */   public static void checkRethrow(Throwable t)
/*      */   {
/*   64 */     if ((t instanceof ThreadDeath)) {
/*   65 */       throw ((ThreadDeath)t);
/*      */     }
/*   67 */     if ((t instanceof VirtualMachineError))
/*   68 */       throw ((VirtualMachineError)t);
/*      */   }
/*      */ 
/*      */   public static <V> PoolableObjectFactory<V> adapt(KeyedPoolableObjectFactory<Object, V> keyedFactory)
/*      */     throws IllegalArgumentException
/*      */   {
/*   86 */     return adapt(keyedFactory, new Object());
/*      */   }
/*      */ 
/*      */   public static <K, V> PoolableObjectFactory<V> adapt(KeyedPoolableObjectFactory<K, V> keyedFactory, K key)
/*      */     throws IllegalArgumentException
/*      */   {
/*  103 */     return new PoolableObjectFactoryAdaptor(keyedFactory, key);
/*      */   }
/*      */ 
/*      */   public static <K, V> KeyedPoolableObjectFactory<K, V> adapt(PoolableObjectFactory<V> factory)
/*      */     throws IllegalArgumentException
/*      */   {
/*  118 */     return new KeyedPoolableObjectFactoryAdaptor(factory);
/*      */   }
/*      */ 
/*      */   public static <V> ObjectPool<V> adapt(KeyedObjectPool<Object, V> keyedPool)
/*      */     throws IllegalArgumentException
/*      */   {
/*  133 */     return adapt(keyedPool, new Object());
/*      */   }
/*      */ 
/*      */   public static <V> ObjectPool<V> adapt(KeyedObjectPool<Object, V> keyedPool, Object key)
/*      */     throws IllegalArgumentException
/*      */   {
/*  149 */     return new ObjectPoolAdaptor(keyedPool, key);
/*      */   }
/*      */ 
/*      */   public static <K, V> KeyedObjectPool<K, V> adapt(ObjectPool<V> pool)
/*      */     throws IllegalArgumentException
/*      */   {
/*  164 */     return new KeyedObjectPoolAdaptor(pool);
/*      */   }
/*      */ 
/*      */   public static <T> ObjectPool<T> checkedPool(ObjectPool<T> pool, Class<T> type)
/*      */   {
/*  178 */     if (pool == null) {
/*  179 */       throw new IllegalArgumentException("pool must not be null.");
/*      */     }
/*  181 */     if (type == null) {
/*  182 */       throw new IllegalArgumentException("type must not be null.");
/*      */     }
/*  184 */     return new CheckedObjectPool(pool, type);
/*      */   }
/*      */ 
/*      */   public static <K, V> KeyedObjectPool<K, V> checkedPool(KeyedObjectPool<K, V> keyedPool, Class<V> type)
/*      */   {
/*  199 */     if (keyedPool == null) {
/*  200 */       throw new IllegalArgumentException("keyedPool must not be null.");
/*      */     }
/*  202 */     if (type == null) {
/*  203 */       throw new IllegalArgumentException("type must not be null.");
/*      */     }
/*  205 */     return new CheckedKeyedObjectPool(keyedPool, type);
/*      */   }
/*      */ 
/*      */   public static <T> TimerTask checkMinIdle(ObjectPool<T> pool, int minIdle, long period)
/*      */     throws IllegalArgumentException
/*      */   {
/*  224 */     if (pool == null) {
/*  225 */       throw new IllegalArgumentException("keyedPool must not be null.");
/*      */     }
/*  227 */     if (minIdle < 0) {
/*  228 */       throw new IllegalArgumentException("minIdle must be non-negative.");
/*      */     }
/*  230 */     TimerTask task = new ObjectPoolMinIdleTimerTask(pool, minIdle);
/*  231 */     getMinIdleTimer().schedule(task, 0L, period);
/*  232 */     return task;
/*      */   }
/*      */ 
/*      */   public static <K, V> TimerTask checkMinIdle(KeyedObjectPool<K, V> keyedPool, K key, int minIdle, long period)
/*      */     throws IllegalArgumentException
/*      */   {
/*  254 */     if (keyedPool == null) {
/*  255 */       throw new IllegalArgumentException("keyedPool must not be null.");
/*      */     }
/*  257 */     if (key == null) {
/*  258 */       throw new IllegalArgumentException("key must not be null.");
/*      */     }
/*  260 */     if (minIdle < 0) {
/*  261 */       throw new IllegalArgumentException("minIdle must be non-negative.");
/*      */     }
/*  263 */     TimerTask task = new KeyedObjectPoolMinIdleTimerTask(keyedPool, key, minIdle);
/*  264 */     getMinIdleTimer().schedule(task, 0L, period);
/*  265 */     return task;
/*      */   }
/*      */ 
/*      */   public static <K, V> Map<K, TimerTask> checkMinIdle(KeyedObjectPool<K, V> keyedPool, Collection<? extends K> keys, int minIdle, long period)
/*      */     throws IllegalArgumentException
/*      */   {
/*  287 */     if (keys == null) {
/*  288 */       throw new IllegalArgumentException("keys must not be null.");
/*      */     }
/*  290 */     Map tasks = new HashMap(keys.size());
/*  291 */     Iterator iter = keys.iterator();
/*  292 */     while (iter.hasNext()) {
/*  293 */       Object key = iter.next();
/*  294 */       TimerTask task = checkMinIdle(keyedPool, key, minIdle, period);
/*  295 */       tasks.put(key, task);
/*      */     }
/*  297 */     return tasks;
/*      */   }
/*      */ 
/*      */   public static <T> void prefill(ObjectPool<T> pool, int count)
/*      */     throws Exception, IllegalArgumentException
/*      */   {
/*  311 */     if (pool == null) {
/*  312 */       throw new IllegalArgumentException("pool must not be null.");
/*      */     }
/*  314 */     for (int i = 0; i < count; i++)
/*  315 */       pool.addObject();
/*      */   }
/*      */ 
/*      */   public static <K, V> void prefill(KeyedObjectPool<K, V> keyedPool, K key, int count)
/*      */     throws Exception, IllegalArgumentException
/*      */   {
/*  333 */     if (keyedPool == null) {
/*  334 */       throw new IllegalArgumentException("keyedPool must not be null.");
/*      */     }
/*  336 */     if (key == null) {
/*  337 */       throw new IllegalArgumentException("key must not be null.");
/*      */     }
/*  339 */     for (int i = 0; i < count; i++)
/*  340 */       keyedPool.addObject(key);
/*      */   }
/*      */ 
/*      */   public static <K, V> void prefill(KeyedObjectPool<K, V> keyedPool, Collection<? extends K> keys, int count)
/*      */     throws Exception, IllegalArgumentException
/*      */   {
/*  361 */     if (keys == null) {
/*  362 */       throw new IllegalArgumentException("keys must not be null.");
/*      */     }
/*  364 */     Iterator iter = keys.iterator();
/*  365 */     while (iter.hasNext())
/*  366 */       prefill(keyedPool, iter.next(), count);
/*      */   }
/*      */ 
/*      */   public static <T> ObjectPool<T> synchronizedPool(ObjectPool<T> pool)
/*      */   {
/*  386 */     if (pool == null) {
/*  387 */       throw new IllegalArgumentException("pool must not be null.");
/*      */     }
/*      */ 
/*  399 */     return new SynchronizedObjectPool(pool);
/*      */   }
/*      */ 
/*      */   public static <K, V> KeyedObjectPool<K, V> synchronizedPool(KeyedObjectPool<K, V> keyedPool)
/*      */   {
/*  419 */     if (keyedPool == null) {
/*  420 */       throw new IllegalArgumentException("keyedPool must not be null.");
/*      */     }
/*      */ 
/*  430 */     return new SynchronizedKeyedObjectPool(keyedPool);
/*      */   }
/*      */ 
/*      */   public static <T> PoolableObjectFactory<T> synchronizedPoolableFactory(PoolableObjectFactory<T> factory)
/*      */   {
/*  442 */     return new SynchronizedPoolableObjectFactory(factory);
/*      */   }
/*      */ 
/*      */   public static <K, V> KeyedPoolableObjectFactory<K, V> synchronizedPoolableFactory(KeyedPoolableObjectFactory<K, V> keyedFactory)
/*      */   {
/*  455 */     return new SynchronizedKeyedPoolableObjectFactory(keyedFactory);
/*      */   }
/*      */ 
/*      */   public static <T> ObjectPool<T> erodingPool(ObjectPool<T> pool)
/*      */   {
/*  471 */     return erodingPool(pool, 1.0F);
/*      */   }
/*      */ 
/*      */   public static <T> ObjectPool<T> erodingPool(ObjectPool<T> pool, float factor)
/*      */   {
/*  496 */     if (pool == null) {
/*  497 */       throw new IllegalArgumentException("pool must not be null.");
/*      */     }
/*  499 */     if (factor <= 0.0F) {
/*  500 */       throw new IllegalArgumentException("factor must be positive.");
/*      */     }
/*  502 */     return new ErodingObjectPool(pool, factor);
/*      */   }
/*      */ 
/*      */   public static <K, V> KeyedObjectPool<K, V> erodingPool(KeyedObjectPool<K, V> keyedPool)
/*      */   {
/*  521 */     return erodingPool(keyedPool, 1.0F);
/*      */   }
/*      */ 
/*      */   public static <K, V> KeyedObjectPool<K, V> erodingPool(KeyedObjectPool<K, V> keyedPool, float factor)
/*      */   {
/*  548 */     return erodingPool(keyedPool, factor, false);
/*      */   }
/*      */ 
/*      */   public static <K, V> KeyedObjectPool<K, V> erodingPool(KeyedObjectPool<K, V> keyedPool, float factor, boolean perKey)
/*      */   {
/*  583 */     if (keyedPool == null) {
/*  584 */       throw new IllegalArgumentException("keyedPool must not be null.");
/*      */     }
/*  586 */     if (factor <= 0.0F) {
/*  587 */       throw new IllegalArgumentException("factor must be positive.");
/*      */     }
/*  589 */     if (perKey) {
/*  590 */       return new ErodingPerKeyKeyedObjectPool(keyedPool, factor);
/*      */     }
/*  592 */     return new ErodingKeyedObjectPool(keyedPool, factor);
/*      */   }
/*      */ 
/*      */   private static synchronized Timer getMinIdleTimer()
/*      */   {
/*  603 */     if (MIN_IDLE_TIMER == null) {
/*  604 */       MIN_IDLE_TIMER = new Timer(true);
/*      */     }
/*  606 */     return MIN_IDLE_TIMER;
/*      */   }
/*      */ 
/*      */   private static class ErodingPerKeyKeyedObjectPool<K, V> extends PoolUtils.ErodingKeyedObjectPool<K, V>
/*      */   {
/*      */     private final float factor;
/* 2429 */     private final Map<K, PoolUtils.ErodingFactor> factors = Collections.synchronizedMap(new HashMap());
/*      */ 
/*      */     public ErodingPerKeyKeyedObjectPool(KeyedObjectPool<K, V> keyedPool, float factor)
/*      */     {
/* 2438 */       super(null);
/* 2439 */       this.factor = factor;
/*      */     }
/*      */ 
/*      */     protected int numIdle(K key)
/*      */     {
/* 2447 */       return getKeyedPool().getNumIdle(key);
/*      */     }
/*      */ 
/*      */     protected PoolUtils.ErodingFactor getErodingFactor(K key)
/*      */     {
/* 2455 */       PoolUtils.ErodingFactor factor = (PoolUtils.ErodingFactor)this.factors.get(key);
/*      */ 
/* 2458 */       if (factor == null) {
/* 2459 */         factor = new PoolUtils.ErodingFactor(this.factor);
/* 2460 */         this.factors.put(key, factor);
/*      */       }
/* 2462 */       return factor;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 2470 */       return "ErodingPerKeyKeyedObjectPool{factor=" + this.factor + ", keyedPool=" + getKeyedPool() + '}';
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class ErodingKeyedObjectPool<K, V>
/*      */     implements KeyedObjectPool<K, V>
/*      */   {
/*      */     private final KeyedObjectPool<K, V> keyedPool;
/*      */     private final PoolUtils.ErodingFactor erodingFactor;
/*      */ 
/*      */     public ErodingKeyedObjectPool(KeyedObjectPool<K, V> keyedPool, float factor)
/*      */     {
/* 2238 */       this(keyedPool, new PoolUtils.ErodingFactor(factor));
/*      */     }
/*      */ 
/*      */     protected ErodingKeyedObjectPool(KeyedObjectPool<K, V> keyedPool, PoolUtils.ErodingFactor erodingFactor)
/*      */     {
/* 2249 */       if (keyedPool == null) {
/* 2250 */         throw new IllegalArgumentException("keyedPool must not be null.");
/*      */       }
/* 2252 */       this.keyedPool = keyedPool;
/* 2253 */       this.erodingFactor = erodingFactor;
/*      */     }
/*      */ 
/*      */     public V borrowObject(K key)
/*      */       throws Exception, NoSuchElementException, IllegalStateException
/*      */     {
/* 2260 */       return this.keyedPool.borrowObject(key);
/*      */     }
/*      */ 
/*      */     public void returnObject(K key, V obj)
/*      */       throws Exception
/*      */     {
/* 2274 */       boolean discard = false;
/* 2275 */       long now = System.currentTimeMillis();
/* 2276 */       PoolUtils.ErodingFactor factor = getErodingFactor(key);
/* 2277 */       synchronized (this.keyedPool) {
/* 2278 */         if (factor.getNextShrink() < now) {
/* 2279 */           int numIdle = numIdle(key);
/* 2280 */           if (numIdle > 0) {
/* 2281 */             discard = true;
/*      */           }
/*      */ 
/* 2284 */           factor.update(now, numIdle);
/*      */         }
/*      */       }
/*      */       try {
/* 2288 */         if (discard)
/* 2289 */           this.keyedPool.invalidateObject(key, obj);
/*      */         else
/* 2291 */           this.keyedPool.returnObject(key, obj);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     protected int numIdle(K key)
/*      */     {
/* 2307 */       return getKeyedPool().getNumIdle();
/*      */     }
/*      */ 
/*      */     protected PoolUtils.ErodingFactor getErodingFactor(K key)
/*      */     {
/* 2316 */       return this.erodingFactor;
/*      */     }
/*      */ 
/*      */     public void invalidateObject(K key, V obj)
/*      */     {
/*      */       try
/*      */       {
/* 2324 */         this.keyedPool.invalidateObject(key, obj);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     public void addObject(K key)
/*      */       throws Exception, IllegalStateException, UnsupportedOperationException
/*      */     {
/* 2334 */       this.keyedPool.addObject(key);
/*      */     }
/*      */ 
/*      */     public int getNumIdle()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 2341 */       return this.keyedPool.getNumIdle();
/*      */     }
/*      */ 
/*      */     public int getNumIdle(K key)
/*      */       throws UnsupportedOperationException
/*      */     {
/* 2348 */       return this.keyedPool.getNumIdle(key);
/*      */     }
/*      */ 
/*      */     public int getNumActive()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 2355 */       return this.keyedPool.getNumActive();
/*      */     }
/*      */ 
/*      */     public int getNumActive(K key)
/*      */       throws UnsupportedOperationException
/*      */     {
/* 2362 */       return this.keyedPool.getNumActive(key);
/*      */     }
/*      */ 
/*      */     public void clear()
/*      */       throws Exception, UnsupportedOperationException
/*      */     {
/* 2369 */       this.keyedPool.clear();
/*      */     }
/*      */ 
/*      */     public void clear(K key)
/*      */       throws Exception, UnsupportedOperationException
/*      */     {
/* 2376 */       this.keyedPool.clear(key);
/*      */     }
/*      */ 
/*      */     public void close()
/*      */     {
/*      */       try
/*      */       {
/* 2384 */         this.keyedPool.close();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public void setFactory(KeyedPoolableObjectFactory<K, V> factory)
/*      */       throws IllegalStateException, UnsupportedOperationException
/*      */     {
/* 2396 */       this.keyedPool.setFactory(factory);
/*      */     }
/*      */ 
/*      */     protected KeyedObjectPool<K, V> getKeyedPool()
/*      */     {
/* 2405 */       return this.keyedPool;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 2413 */       return "ErodingKeyedObjectPool{erodingFactor=" + this.erodingFactor + ", keyedPool=" + this.keyedPool + '}';
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class ErodingObjectPool<T>
/*      */     implements ObjectPool<T>
/*      */   {
/*      */     private final ObjectPool<T> pool;
/*      */     private final PoolUtils.ErodingFactor factor;
/*      */ 
/*      */     public ErodingObjectPool(ObjectPool<T> pool, float factor)
/*      */     {
/* 2102 */       this.pool = pool;
/* 2103 */       this.factor = new PoolUtils.ErodingFactor(factor);
/*      */     }
/*      */ 
/*      */     public T borrowObject()
/*      */       throws Exception, NoSuchElementException, IllegalStateException
/*      */     {
/* 2110 */       return this.pool.borrowObject();
/*      */     }
/*      */ 
/*      */     public void returnObject(T obj)
/*      */     {
/* 2123 */       boolean discard = false;
/* 2124 */       long now = System.currentTimeMillis();
/* 2125 */       synchronized (this.pool) {
/* 2126 */         if (this.factor.getNextShrink() < now) {
/* 2127 */           int numIdle = this.pool.getNumIdle();
/* 2128 */           if (numIdle > 0) {
/* 2129 */             discard = true;
/*      */           }
/*      */ 
/* 2132 */           this.factor.update(now, numIdle);
/*      */         }
/*      */       }
/*      */       try {
/* 2136 */         if (discard)
/* 2137 */           this.pool.invalidateObject(obj);
/*      */         else
/* 2139 */           this.pool.returnObject(obj);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     public void invalidateObject(T obj)
/*      */     {
/*      */       try
/*      */       {
/* 2151 */         this.pool.invalidateObject(obj);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     public void addObject()
/*      */       throws Exception, IllegalStateException, UnsupportedOperationException
/*      */     {
/* 2161 */       this.pool.addObject();
/*      */     }
/*      */ 
/*      */     public int getNumIdle()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 2168 */       return this.pool.getNumIdle();
/*      */     }
/*      */ 
/*      */     public int getNumActive()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 2175 */       return this.pool.getNumActive();
/*      */     }
/*      */ 
/*      */     public void clear()
/*      */       throws Exception, UnsupportedOperationException
/*      */     {
/* 2182 */       this.pool.clear();
/*      */     }
/*      */ 
/*      */     public void close()
/*      */     {
/*      */       try
/*      */       {
/* 2190 */         this.pool.close();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public void setFactory(PoolableObjectFactory<T> factory)
/*      */       throws IllegalStateException, UnsupportedOperationException
/*      */     {
/* 2202 */       this.pool.setFactory(factory);
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 2210 */       return "ErodingObjectPool{factor=" + this.factor + ", pool=" + this.pool + '}';
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class ErodingFactor
/*      */   {
/*      */     private final float factor;
/*      */     private volatile transient long nextShrink;
/*      */     private volatile transient int idleHighWaterMark;
/*      */ 
/*      */     public ErodingFactor(float factor)
/*      */     {
/* 2032 */       this.factor = factor;
/* 2033 */       this.nextShrink = (System.currentTimeMillis() + ()(900000.0F * factor));
/* 2034 */       this.idleHighWaterMark = 1;
/*      */     }
/*      */ 
/*      */     public void update(int numIdle)
/*      */     {
/* 2043 */       update(System.currentTimeMillis(), numIdle);
/*      */     }
/*      */ 
/*      */     public void update(long now, int numIdle)
/*      */     {
/* 2053 */       int idle = Math.max(0, numIdle);
/* 2054 */       this.idleHighWaterMark = Math.max(idle, this.idleHighWaterMark);
/* 2055 */       float maxInterval = 15.0F;
/* 2056 */       float minutes = 15.0F + -14.0F / this.idleHighWaterMark * idle;
/* 2057 */       this.nextShrink = (now + ()(minutes * 60000.0F * this.factor));
/*      */     }
/*      */ 
/*      */     public long getNextShrink()
/*      */     {
/* 2066 */       return this.nextShrink;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 2074 */       return "ErodingFactor{factor=" + this.factor + ", idleHighWaterMark=" + this.idleHighWaterMark + '}';
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedKeyedPoolableObjectFactory<K, V>
/*      */     implements KeyedPoolableObjectFactory<K, V>
/*      */   {
/*      */     private final Object lock;
/*      */     private final KeyedPoolableObjectFactory<K, V> keyedFactory;
/*      */ 
/*      */     SynchronizedKeyedPoolableObjectFactory(KeyedPoolableObjectFactory<K, V> keyedFactory)
/*      */       throws IllegalArgumentException
/*      */     {
/* 1942 */       if (keyedFactory == null) {
/* 1943 */         throw new IllegalArgumentException("keyedFactory must not be null.");
/*      */       }
/* 1945 */       this.keyedFactory = keyedFactory;
/* 1946 */       this.lock = new Object();
/*      */     }
/*      */ 
/*      */     public V makeObject(K key)
/*      */       throws Exception
/*      */     {
/* 1953 */       synchronized (this.lock) {
/* 1954 */         return this.keyedFactory.makeObject(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void destroyObject(K key, V obj)
/*      */       throws Exception
/*      */     {
/* 1962 */       synchronized (this.lock) {
/* 1963 */         this.keyedFactory.destroyObject(key, obj);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean validateObject(K key, V obj)
/*      */     {
/* 1971 */       synchronized (this.lock) {
/* 1972 */         return this.keyedFactory.validateObject(key, obj);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void activateObject(K key, V obj)
/*      */       throws Exception
/*      */     {
/* 1980 */       synchronized (this.lock) {
/* 1981 */         this.keyedFactory.activateObject(key, obj);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void passivateObject(K key, V obj)
/*      */       throws Exception
/*      */     {
/* 1989 */       synchronized (this.lock) {
/* 1990 */         this.keyedFactory.passivateObject(key, obj);
/*      */       }
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1999 */       StringBuffer sb = new StringBuffer();
/* 2000 */       sb.append("SynchronizedKeyedPoolableObjectFactory");
/* 2001 */       sb.append("{keyedFactory=").append(this.keyedFactory);
/* 2002 */       sb.append('}');
/* 2003 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedPoolableObjectFactory<T>
/*      */     implements PoolableObjectFactory<T>
/*      */   {
/*      */     private final Object lock;
/*      */     private final PoolableObjectFactory<T> factory;
/*      */ 
/*      */     SynchronizedPoolableObjectFactory(PoolableObjectFactory<T> factory)
/*      */       throws IllegalArgumentException
/*      */     {
/* 1855 */       if (factory == null) {
/* 1856 */         throw new IllegalArgumentException("factory must not be null.");
/*      */       }
/* 1858 */       this.factory = factory;
/* 1859 */       this.lock = new Object();
/*      */     }
/*      */ 
/*      */     public T makeObject()
/*      */       throws Exception
/*      */     {
/* 1866 */       synchronized (this.lock) {
/* 1867 */         return this.factory.makeObject();
/*      */       }
/*      */     }
/*      */ 
/*      */     public void destroyObject(T obj)
/*      */       throws Exception
/*      */     {
/* 1875 */       synchronized (this.lock) {
/* 1876 */         this.factory.destroyObject(obj);
/*      */       }
/*      */     }
/*      */ 
/*      */     public boolean validateObject(T obj)
/*      */     {
/* 1884 */       synchronized (this.lock) {
/* 1885 */         return this.factory.validateObject(obj);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void activateObject(T obj)
/*      */       throws Exception
/*      */     {
/* 1893 */       synchronized (this.lock) {
/* 1894 */         this.factory.activateObject(obj);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void passivateObject(T obj)
/*      */       throws Exception
/*      */     {
/* 1902 */       synchronized (this.lock) {
/* 1903 */         this.factory.passivateObject(obj);
/*      */       }
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1912 */       StringBuffer sb = new StringBuffer();
/* 1913 */       sb.append("SynchronizedPoolableObjectFactory");
/* 1914 */       sb.append("{factory=").append(this.factory);
/* 1915 */       sb.append('}');
/* 1916 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedKeyedObjectPool<K, V>
/*      */     implements KeyedObjectPool<K, V>
/*      */   {
/*      */     private final Object lock;
/*      */     private final KeyedObjectPool<K, V> keyedPool;
/*      */ 
/*      */     SynchronizedKeyedObjectPool(KeyedObjectPool<K, V> keyedPool)
/*      */       throws IllegalArgumentException
/*      */     {
/* 1689 */       if (keyedPool == null) {
/* 1690 */         throw new IllegalArgumentException("keyedPool must not be null.");
/*      */       }
/* 1692 */       this.keyedPool = keyedPool;
/* 1693 */       this.lock = new Object();
/*      */     }
/*      */ 
/*      */     public V borrowObject(K key)
/*      */       throws Exception, NoSuchElementException, IllegalStateException
/*      */     {
/* 1700 */       synchronized (this.lock) {
/* 1701 */         return this.keyedPool.borrowObject(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void returnObject(K key, V obj)
/*      */     {
/* 1709 */       synchronized (this.lock) {
/*      */         try {
/* 1711 */           this.keyedPool.returnObject(key, obj);
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void invalidateObject(K key, V obj)
/*      */     {
/* 1722 */       synchronized (this.lock) {
/*      */         try {
/* 1724 */           this.keyedPool.invalidateObject(key, obj);
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void addObject(K key)
/*      */       throws Exception, IllegalStateException, UnsupportedOperationException
/*      */     {
/* 1735 */       synchronized (this.lock) {
/* 1736 */         this.keyedPool.addObject(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int getNumIdle(K key)
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1744 */       synchronized (this.lock) {
/* 1745 */         return this.keyedPool.getNumIdle(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int getNumActive(K key)
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1753 */       synchronized (this.lock) {
/* 1754 */         return this.keyedPool.getNumActive(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public int getNumIdle()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1762 */       synchronized (this.lock) {
/* 1763 */         return this.keyedPool.getNumIdle();
/*      */       }
/*      */     }
/*      */ 
/*      */     public int getNumActive()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1771 */       synchronized (this.lock) {
/* 1772 */         return this.keyedPool.getNumActive();
/*      */       }
/*      */     }
/*      */ 
/*      */     public void clear()
/*      */       throws Exception, UnsupportedOperationException
/*      */     {
/* 1780 */       synchronized (this.lock) {
/* 1781 */         this.keyedPool.clear();
/*      */       }
/*      */     }
/*      */ 
/*      */     public void clear(K key)
/*      */       throws Exception, UnsupportedOperationException
/*      */     {
/* 1789 */       synchronized (this.lock) {
/* 1790 */         this.keyedPool.clear(key);
/*      */       }
/*      */     }
/*      */ 
/*      */     public void close()
/*      */     {
/*      */       try
/*      */       {
/* 1799 */         synchronized (this.lock) {
/* 1800 */           this.keyedPool.close();
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public void setFactory(KeyedPoolableObjectFactory<K, V> factory)
/*      */       throws IllegalStateException, UnsupportedOperationException
/*      */     {
/* 1815 */       synchronized (this.lock) {
/* 1816 */         this.keyedPool.setFactory(factory);
/*      */       }
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1825 */       StringBuffer sb = new StringBuffer();
/* 1826 */       sb.append("SynchronizedKeyedObjectPool");
/* 1827 */       sb.append("{keyedPool=").append(this.keyedPool);
/* 1828 */       sb.append('}');
/* 1829 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class SynchronizedObjectPool<T>
/*      */     implements ObjectPool<T>
/*      */   {
/*      */     private final Object lock;
/*      */     private final ObjectPool<T> pool;
/*      */ 
/*      */     SynchronizedObjectPool(ObjectPool<T> pool)
/*      */       throws IllegalArgumentException
/*      */     {
/* 1547 */       if (pool == null) {
/* 1548 */         throw new IllegalArgumentException("pool must not be null.");
/*      */       }
/* 1550 */       this.pool = pool;
/* 1551 */       this.lock = new Object();
/*      */     }
/*      */ 
/*      */     public T borrowObject()
/*      */       throws Exception, NoSuchElementException, IllegalStateException
/*      */     {
/* 1558 */       synchronized (this.lock) {
/* 1559 */         return this.pool.borrowObject();
/*      */       }
/*      */     }
/*      */ 
/*      */     public void returnObject(T obj)
/*      */     {
/* 1567 */       synchronized (this.lock) {
/*      */         try {
/* 1569 */           this.pool.returnObject(obj);
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void invalidateObject(T obj)
/*      */     {
/* 1580 */       synchronized (this.lock) {
/*      */         try {
/* 1582 */           this.pool.invalidateObject(obj);
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*      */     public void addObject()
/*      */       throws Exception, IllegalStateException, UnsupportedOperationException
/*      */     {
/* 1593 */       synchronized (this.lock) {
/* 1594 */         this.pool.addObject();
/*      */       }
/*      */     }
/*      */ 
/*      */     public int getNumIdle()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1602 */       synchronized (this.lock) {
/* 1603 */         return this.pool.getNumIdle();
/*      */       }
/*      */     }
/*      */ 
/*      */     public int getNumActive()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1611 */       synchronized (this.lock) {
/* 1612 */         return this.pool.getNumActive();
/*      */       }
/*      */     }
/*      */ 
/*      */     public void clear()
/*      */       throws Exception, UnsupportedOperationException
/*      */     {
/* 1620 */       synchronized (this.lock) {
/* 1621 */         this.pool.clear();
/*      */       }
/*      */     }
/*      */ 
/*      */     public void close()
/*      */     {
/*      */       try
/*      */       {
/* 1630 */         synchronized (this.lock) {
/* 1631 */           this.pool.close();
/*      */         }
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public void setFactory(PoolableObjectFactory<T> factory)
/*      */       throws IllegalStateException, UnsupportedOperationException
/*      */     {
/* 1646 */       synchronized (this.lock) {
/* 1647 */         this.pool.setFactory(factory);
/*      */       }
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1656 */       StringBuffer sb = new StringBuffer();
/* 1657 */       sb.append("SynchronizedObjectPool");
/* 1658 */       sb.append("{pool=").append(this.pool);
/* 1659 */       sb.append('}');
/* 1660 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class KeyedObjectPoolMinIdleTimerTask<K, V> extends TimerTask
/*      */   {
/*      */     private final int minIdle;
/*      */     private final K key;
/*      */     private final KeyedObjectPool<K, V> keyedPool;
/*      */ 
/*      */     KeyedObjectPoolMinIdleTimerTask(KeyedObjectPool<K, V> keyedPool, K key, int minIdle)
/*      */       throws IllegalArgumentException
/*      */     {
/* 1476 */       if (keyedPool == null) {
/* 1477 */         throw new IllegalArgumentException("keyedPool must not be null.");
/*      */       }
/* 1479 */       this.keyedPool = keyedPool;
/* 1480 */       this.key = key;
/* 1481 */       this.minIdle = minIdle;
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/* 1489 */       boolean success = false;
/*      */       try {
/* 1491 */         if (this.keyedPool.getNumIdle(this.key) < this.minIdle) {
/* 1492 */           this.keyedPool.addObject(this.key);
/*      */         }
/* 1494 */         success = true;
/*      */       }
/*      */       catch (Exception e) {
/* 1497 */         cancel();
/*      */       }
/*      */       finally
/*      */       {
/* 1501 */         if (!success)
/* 1502 */           cancel();
/*      */       }
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1512 */       StringBuffer sb = new StringBuffer();
/* 1513 */       sb.append("KeyedObjectPoolMinIdleTimerTask");
/* 1514 */       sb.append("{minIdle=").append(this.minIdle);
/* 1515 */       sb.append(", key=").append(this.key);
/* 1516 */       sb.append(", keyedPool=").append(this.keyedPool);
/* 1517 */       sb.append('}');
/* 1518 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class ObjectPoolMinIdleTimerTask<T> extends TimerTask
/*      */   {
/*      */     private final int minIdle;
/*      */     private final ObjectPool<T> pool;
/*      */ 
/*      */     ObjectPoolMinIdleTimerTask(ObjectPool<T> pool, int minIdle)
/*      */       throws IllegalArgumentException
/*      */     {
/* 1407 */       if (pool == null) {
/* 1408 */         throw new IllegalArgumentException("pool must not be null.");
/*      */       }
/* 1410 */       this.pool = pool;
/* 1411 */       this.minIdle = minIdle;
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/* 1419 */       boolean success = false;
/*      */       try {
/* 1421 */         if (this.pool.getNumIdle() < this.minIdle) {
/* 1422 */           this.pool.addObject();
/*      */         }
/* 1424 */         success = true;
/*      */       }
/*      */       catch (Exception e) {
/* 1427 */         cancel();
/*      */       }
/*      */       finally
/*      */       {
/* 1431 */         if (!success)
/* 1432 */           cancel();
/*      */       }
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1442 */       StringBuffer sb = new StringBuffer();
/* 1443 */       sb.append("ObjectPoolMinIdleTimerTask");
/* 1444 */       sb.append("{minIdle=").append(this.minIdle);
/* 1445 */       sb.append(", pool=").append(this.pool);
/* 1446 */       sb.append('}');
/* 1447 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class CheckedKeyedObjectPool<K, V>
/*      */     implements KeyedObjectPool<K, V>
/*      */   {
/*      */     private final Class<V> type;
/*      */     private final KeyedObjectPool<K, V> keyedPool;
/*      */ 
/*      */     CheckedKeyedObjectPool(KeyedObjectPool<K, V> keyedPool, Class<V> type)
/*      */     {
/* 1236 */       if (keyedPool == null) {
/* 1237 */         throw new IllegalArgumentException("keyedPool must not be null.");
/*      */       }
/* 1239 */       if (type == null) {
/* 1240 */         throw new IllegalArgumentException("type must not be null.");
/*      */       }
/* 1242 */       this.keyedPool = keyedPool;
/* 1243 */       this.type = type;
/*      */     }
/*      */ 
/*      */     public V borrowObject(K key)
/*      */       throws Exception, NoSuchElementException, IllegalStateException
/*      */     {
/* 1254 */       Object obj = this.keyedPool.borrowObject(key);
/* 1255 */       if (this.type.isInstance(obj)) {
/* 1256 */         return obj;
/*      */       }
/* 1258 */       throw new ClassCastException("Borrowed object for key: " + key + " is not of type: " + this.type.getName() + " was: " + obj);
/*      */     }
/*      */ 
/*      */     public void returnObject(K key, V obj)
/*      */     {
/* 1270 */       if (this.type.isInstance(obj))
/*      */         try {
/* 1272 */           this.keyedPool.returnObject(key, obj);
/*      */         }
/*      */         catch (Exception e) {
/*      */         }
/*      */       else
/* 1277 */         throw new ClassCastException("Returned object for key: " + key + " is not of type: " + this.type.getName() + " was: " + obj);
/*      */     }
/*      */ 
/*      */     public void invalidateObject(K key, V obj)
/*      */     {
/* 1289 */       if (this.type.isInstance(obj))
/*      */         try {
/* 1291 */           this.keyedPool.invalidateObject(key, obj);
/*      */         }
/*      */         catch (Exception e) {
/*      */         }
/*      */       else
/* 1296 */         throw new ClassCastException("Invalidated object for key: " + key + " is not of type: " + this.type.getName() + " was: " + obj);
/*      */     }
/*      */ 
/*      */     public void addObject(K key)
/*      */       throws Exception, IllegalStateException, UnsupportedOperationException
/*      */     {
/* 1304 */       this.keyedPool.addObject(key);
/*      */     }
/*      */ 
/*      */     public int getNumIdle(K key)
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1311 */       return this.keyedPool.getNumIdle(key);
/*      */     }
/*      */ 
/*      */     public int getNumActive(K key)
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1318 */       return this.keyedPool.getNumActive(key);
/*      */     }
/*      */ 
/*      */     public int getNumIdle()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1325 */       return this.keyedPool.getNumIdle();
/*      */     }
/*      */ 
/*      */     public int getNumActive()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1332 */       return this.keyedPool.getNumActive();
/*      */     }
/*      */ 
/*      */     public void clear()
/*      */       throws Exception, UnsupportedOperationException
/*      */     {
/* 1339 */       this.keyedPool.clear();
/*      */     }
/*      */ 
/*      */     public void clear(K key)
/*      */       throws Exception, UnsupportedOperationException
/*      */     {
/* 1346 */       this.keyedPool.clear(key);
/*      */     }
/*      */ 
/*      */     public void close()
/*      */     {
/*      */       try
/*      */       {
/* 1354 */         this.keyedPool.close();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public void setFactory(KeyedPoolableObjectFactory<K, V> factory)
/*      */       throws IllegalStateException, UnsupportedOperationException
/*      */     {
/* 1368 */       this.keyedPool.setFactory(factory);
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1376 */       StringBuffer sb = new StringBuffer();
/* 1377 */       sb.append("CheckedKeyedObjectPool");
/* 1378 */       sb.append("{type=").append(this.type);
/* 1379 */       sb.append(", keyedPool=").append(this.keyedPool);
/* 1380 */       sb.append('}');
/* 1381 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class CheckedObjectPool<T>
/*      */     implements ObjectPool<T>
/*      */   {
/*      */     private final Class<T> type;
/*      */     private final ObjectPool<T> pool;
/*      */ 
/*      */     CheckedObjectPool(ObjectPool<T> pool, Class<T> type)
/*      */     {
/* 1088 */       if (pool == null) {
/* 1089 */         throw new IllegalArgumentException("pool must not be null.");
/*      */       }
/* 1091 */       if (type == null) {
/* 1092 */         throw new IllegalArgumentException("type must not be null.");
/*      */       }
/* 1094 */       this.pool = pool;
/* 1095 */       this.type = type;
/*      */     }
/*      */ 
/*      */     public T borrowObject()
/*      */       throws Exception, NoSuchElementException, IllegalStateException
/*      */     {
/* 1105 */       Object obj = this.pool.borrowObject();
/* 1106 */       if (this.type.isInstance(obj)) {
/* 1107 */         return obj;
/*      */       }
/* 1109 */       throw new ClassCastException("Borrowed object is not of type: " + this.type.getName() + " was: " + obj);
/*      */     }
/*      */ 
/*      */     public void returnObject(T obj)
/*      */     {
/* 1120 */       if (this.type.isInstance(obj))
/*      */         try {
/* 1122 */           this.pool.returnObject(obj);
/*      */         }
/*      */         catch (Exception e) {
/*      */         }
/*      */       else
/* 1127 */         throw new ClassCastException("Returned object is not of type: " + this.type.getName() + " was: " + obj);
/*      */     }
/*      */ 
/*      */     public void invalidateObject(T obj)
/*      */     {
/* 1138 */       if (this.type.isInstance(obj))
/*      */         try {
/* 1140 */           this.pool.invalidateObject(obj);
/*      */         }
/*      */         catch (Exception e) {
/*      */         }
/*      */       else
/* 1145 */         throw new ClassCastException("Invalidated object is not of type: " + this.type.getName() + " was: " + obj);
/*      */     }
/*      */ 
/*      */     public void addObject()
/*      */       throws Exception, IllegalStateException, UnsupportedOperationException
/*      */     {
/* 1153 */       this.pool.addObject();
/*      */     }
/*      */ 
/*      */     public int getNumIdle()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1160 */       return this.pool.getNumIdle();
/*      */     }
/*      */ 
/*      */     public int getNumActive()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1167 */       return this.pool.getNumActive();
/*      */     }
/*      */ 
/*      */     public void clear()
/*      */       throws Exception, UnsupportedOperationException
/*      */     {
/* 1174 */       this.pool.clear();
/*      */     }
/*      */ 
/*      */     public void close()
/*      */     {
/*      */       try
/*      */       {
/* 1182 */         this.pool.close();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public void setFactory(PoolableObjectFactory<T> factory)
/*      */       throws IllegalStateException, UnsupportedOperationException
/*      */     {
/* 1196 */       this.pool.setFactory(factory);
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1204 */       StringBuffer sb = new StringBuffer();
/* 1205 */       sb.append("CheckedObjectPool");
/* 1206 */       sb.append("{type=").append(this.type);
/* 1207 */       sb.append(", pool=").append(this.pool);
/* 1208 */       sb.append('}');
/* 1209 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class KeyedObjectPoolAdaptor<K, V>
/*      */     implements KeyedObjectPool<K, V>
/*      */   {
/*      */     private final ObjectPool<V> pool;
/*      */ 
/*      */     KeyedObjectPoolAdaptor(ObjectPool<V> pool)
/*      */       throws IllegalArgumentException
/*      */     {
/*  925 */       if (pool == null) {
/*  926 */         throw new IllegalArgumentException("pool must not be null.");
/*      */       }
/*  928 */       this.pool = pool;
/*      */     }
/*      */ 
/*      */     public V borrowObject(K key)
/*      */       throws Exception, NoSuchElementException, IllegalStateException
/*      */     {
/*  938 */       return this.pool.borrowObject();
/*      */     }
/*      */ 
/*      */     public void returnObject(K key, V obj)
/*      */     {
/*      */       try
/*      */       {
/*  949 */         this.pool.returnObject(obj);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     public void invalidateObject(K key, V obj)
/*      */     {
/*      */       try
/*      */       {
/*  963 */         this.pool.invalidateObject(obj);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     public void addObject(K key)
/*      */       throws Exception, IllegalStateException
/*      */     {
/*  975 */       this.pool.addObject();
/*      */     }
/*      */ 
/*      */     public int getNumIdle(K key)
/*      */       throws UnsupportedOperationException
/*      */     {
/*  985 */       return this.pool.getNumIdle();
/*      */     }
/*      */ 
/*      */     public int getNumActive(K key)
/*      */       throws UnsupportedOperationException
/*      */     {
/*  995 */       return this.pool.getNumActive();
/*      */     }
/*      */ 
/*      */     public int getNumIdle()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1002 */       return this.pool.getNumIdle();
/*      */     }
/*      */ 
/*      */     public int getNumActive()
/*      */       throws UnsupportedOperationException
/*      */     {
/* 1009 */       return this.pool.getNumActive();
/*      */     }
/*      */ 
/*      */     public void clear()
/*      */       throws Exception, UnsupportedOperationException
/*      */     {
/* 1016 */       this.pool.clear();
/*      */     }
/*      */ 
/*      */     public void clear(K key)
/*      */       throws Exception, UnsupportedOperationException
/*      */     {
/* 1025 */       this.pool.clear();
/*      */     }
/*      */ 
/*      */     public void close()
/*      */     {
/*      */       try
/*      */       {
/* 1033 */         this.pool.close();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public void setFactory(KeyedPoolableObjectFactory<K, V> factory)
/*      */       throws IllegalStateException, UnsupportedOperationException
/*      */     {
/* 1048 */       this.pool.setFactory(PoolUtils.adapt(factory));
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 1056 */       StringBuffer sb = new StringBuffer();
/* 1057 */       sb.append("KeyedObjectPoolAdaptor");
/* 1058 */       sb.append("{pool=").append(this.pool);
/* 1059 */       sb.append('}');
/* 1060 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class ObjectPoolAdaptor<V>
/*      */     implements ObjectPool<V>
/*      */   {
/*      */     private final Object key;
/*      */     private final KeyedObjectPool<Object, V> keyedPool;
/*      */ 
/*      */     ObjectPoolAdaptor(KeyedObjectPool<Object, V> keyedPool, Object key)
/*      */       throws IllegalArgumentException
/*      */     {
/*  807 */       if (keyedPool == null) {
/*  808 */         throw new IllegalArgumentException("keyedPool must not be null.");
/*      */       }
/*  810 */       if (key == null) {
/*  811 */         throw new IllegalArgumentException("key must not be null.");
/*      */       }
/*  813 */       this.keyedPool = keyedPool;
/*  814 */       this.key = key;
/*      */     }
/*      */ 
/*      */     public V borrowObject()
/*      */       throws Exception, NoSuchElementException, IllegalStateException
/*      */     {
/*  821 */       return this.keyedPool.borrowObject(this.key);
/*      */     }
/*      */ 
/*      */     public void returnObject(V obj)
/*      */     {
/*      */       try
/*      */       {
/*  829 */         this.keyedPool.returnObject(this.key, obj);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     public void invalidateObject(V obj)
/*      */     {
/*      */       try
/*      */       {
/*  840 */         this.keyedPool.invalidateObject(this.key, obj);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     public void addObject()
/*      */       throws Exception, IllegalStateException
/*      */     {
/*  850 */       this.keyedPool.addObject(this.key);
/*      */     }
/*      */ 
/*      */     public int getNumIdle()
/*      */       throws UnsupportedOperationException
/*      */     {
/*  857 */       return this.keyedPool.getNumIdle(this.key);
/*      */     }
/*      */ 
/*      */     public int getNumActive()
/*      */       throws UnsupportedOperationException
/*      */     {
/*  864 */       return this.keyedPool.getNumActive(this.key);
/*      */     }
/*      */ 
/*      */     public void clear()
/*      */       throws Exception, UnsupportedOperationException
/*      */     {
/*  871 */       this.keyedPool.clear();
/*      */     }
/*      */ 
/*      */     public void close()
/*      */     {
/*      */       try
/*      */       {
/*  879 */         this.keyedPool.close();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*      */     @Deprecated
/*      */     public void setFactory(PoolableObjectFactory<V> factory)
/*      */       throws IllegalStateException, UnsupportedOperationException
/*      */     {
/*  893 */       this.keyedPool.setFactory(PoolUtils.adapt(factory));
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  901 */       StringBuffer sb = new StringBuffer();
/*  902 */       sb.append("ObjectPoolAdaptor");
/*  903 */       sb.append("{key=").append(this.key);
/*  904 */       sb.append(", keyedPool=").append(this.keyedPool);
/*  905 */       sb.append('}');
/*  906 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class KeyedPoolableObjectFactoryAdaptor<K, V>
/*      */     implements KeyedPoolableObjectFactory<K, V>
/*      */   {
/*      */     private final PoolableObjectFactory<V> factory;
/*      */ 
/*      */     KeyedPoolableObjectFactoryAdaptor(PoolableObjectFactory<V> factory)
/*      */       throws IllegalArgumentException
/*      */     {
/*  717 */       if (factory == null) {
/*  718 */         throw new IllegalArgumentException("factory must not be null.");
/*      */       }
/*  720 */       this.factory = factory;
/*      */     }
/*      */ 
/*      */     public V makeObject(K key)
/*      */       throws Exception
/*      */     {
/*  730 */       return this.factory.makeObject();
/*      */     }
/*      */ 
/*      */     public void destroyObject(K key, V obj)
/*      */       throws Exception
/*      */     {
/*  740 */       this.factory.destroyObject(obj);
/*      */     }
/*      */ 
/*      */     public boolean validateObject(K key, V obj)
/*      */     {
/*  751 */       return this.factory.validateObject(obj);
/*      */     }
/*      */ 
/*      */     public void activateObject(K key, V obj)
/*      */       throws Exception
/*      */     {
/*  761 */       this.factory.activateObject(obj);
/*      */     }
/*      */ 
/*      */     public void passivateObject(K key, V obj)
/*      */       throws Exception
/*      */     {
/*  771 */       this.factory.passivateObject(obj);
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  779 */       StringBuffer sb = new StringBuffer();
/*  780 */       sb.append("KeyedPoolableObjectFactoryAdaptor");
/*  781 */       sb.append("{factory=").append(this.factory);
/*  782 */       sb.append('}');
/*  783 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ 
/*      */   private static class PoolableObjectFactoryAdaptor<K, V>
/*      */     implements PoolableObjectFactory<V>
/*      */   {
/*      */     private final K key;
/*      */     private final KeyedPoolableObjectFactory<K, V> keyedFactory;
/*      */ 
/*      */     PoolableObjectFactoryAdaptor(KeyedPoolableObjectFactory<K, V> keyedFactory, K key)
/*      */       throws IllegalArgumentException
/*      */     {
/*  630 */       if (keyedFactory == null) {
/*  631 */         throw new IllegalArgumentException("keyedFactory must not be null.");
/*      */       }
/*  633 */       if (key == null) {
/*  634 */         throw new IllegalArgumentException("key must not be null.");
/*      */       }
/*  636 */       this.keyedFactory = keyedFactory;
/*  637 */       this.key = key;
/*      */     }
/*      */ 
/*      */     public V makeObject()
/*      */       throws Exception
/*      */     {
/*  646 */       return this.keyedFactory.makeObject(this.key);
/*      */     }
/*      */ 
/*      */     public void destroyObject(V obj)
/*      */       throws Exception
/*      */     {
/*  655 */       this.keyedFactory.destroyObject(this.key, obj);
/*      */     }
/*      */ 
/*      */     public boolean validateObject(V obj)
/*      */     {
/*  665 */       return this.keyedFactory.validateObject(this.key, obj);
/*      */     }
/*      */ 
/*      */     public void activateObject(V obj)
/*      */       throws Exception
/*      */     {
/*  674 */       this.keyedFactory.activateObject(this.key, obj);
/*      */     }
/*      */ 
/*      */     public void passivateObject(V obj)
/*      */       throws Exception
/*      */     {
/*  683 */       this.keyedFactory.passivateObject(this.key, obj);
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/*  691 */       StringBuffer sb = new StringBuffer();
/*  692 */       sb.append("PoolableObjectFactoryAdaptor");
/*  693 */       sb.append("{key=").append(this.key);
/*  694 */       sb.append(", keyedFactory=").append(this.keyedFactory);
/*  695 */       sb.append('}');
/*  696 */       return sb.toString();
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.pool.PoolUtils
 * JD-Core Version:    0.6.2
 */