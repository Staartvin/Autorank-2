/*      */ package org.apache.commons.pool.impl;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Serializable;
/*      */ import java.lang.ref.WeakReference;
/*      */ import java.lang.reflect.Array;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.ConcurrentModificationException;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.NoSuchElementException;
/*      */ 
/*      */ class CursorableLinkedList<E>
/*      */   implements List<E>, Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 8836393098519411393L;
/*      */   protected transient int _size;
/*      */   protected transient Listable<E> _head;
/*      */   protected transient int _modCount;
/*      */   protected transient List<WeakReference<CursorableLinkedList<E>.Cursor>> _cursors;
/*      */ 
/*      */   CursorableLinkedList()
/*      */   {
/*  945 */     this._size = 0;
/*      */ 
/*  959 */     this._head = new Listable(null, null, null);
/*      */ 
/*  962 */     this._modCount = 0;
/*      */ 
/*  968 */     this._cursors = new ArrayList();
/*      */   }
/*      */ 
/*      */   public boolean add(E o)
/*      */   {
/*   78 */     insertListable(this._head.prev(), null, o);
/*   79 */     return true;
/*      */   }
/*      */ 
/*      */   public void add(int index, E element)
/*      */   {
/*   98 */     if (index == this._size) {
/*   99 */       add(element);
/*      */     } else {
/*  101 */       if ((index < 0) || (index > this._size)) {
/*  102 */         throw new IndexOutOfBoundsException(String.valueOf(index) + " < 0 or " + String.valueOf(index) + " > " + this._size);
/*      */       }
/*  104 */       Listable succ = isEmpty() ? null : getListableAt(index);
/*  105 */       Listable pred = null == succ ? null : succ.prev();
/*  106 */       insertListable(pred, succ, element);
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean addAll(Collection<? extends E> c)
/*      */   {
/*  128 */     if (c.isEmpty()) {
/*  129 */       return false;
/*      */     }
/*  131 */     Iterator it = c.iterator();
/*  132 */     while (it.hasNext()) {
/*  133 */       insertListable(this._head.prev(), null, it.next());
/*      */     }
/*  135 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean addAll(int index, Collection<? extends E> c)
/*      */   {
/*  164 */     if (c.isEmpty())
/*  165 */       return false;
/*  166 */     if ((this._size == index) || (this._size == 0)) {
/*  167 */       return addAll(c);
/*      */     }
/*  169 */     Listable succ = getListableAt(index);
/*  170 */     Listable pred = null == succ ? null : succ.prev();
/*  171 */     Iterator it = c.iterator();
/*  172 */     while (it.hasNext()) {
/*  173 */       pred = insertListable(pred, succ, it.next());
/*      */     }
/*  175 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean addFirst(E o)
/*      */   {
/*  187 */     insertListable(null, this._head.next(), o);
/*  188 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean addLast(E o)
/*      */   {
/*  199 */     insertListable(this._head.prev(), null, o);
/*  200 */     return true;
/*      */   }
/*      */ 
/*      */   public void clear()
/*      */   {
/*  217 */     Iterator it = iterator();
/*  218 */     while (it.hasNext()) {
/*  219 */       it.next();
/*  220 */       it.remove();
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean contains(Object o)
/*      */   {
/*  234 */     Listable elt = this._head.next(); for (Listable past = null; (null != elt) && (past != this._head.prev()); elt = (past = elt).next()) {
/*  235 */       if (((null == o) && (null == elt.value())) || ((o != null) && (o.equals(elt.value()))))
/*      */       {
/*  237 */         return true;
/*      */       }
/*      */     }
/*  240 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean containsAll(Collection<?> c)
/*      */   {
/*  252 */     Iterator it = c.iterator();
/*  253 */     while (it.hasNext()) {
/*  254 */       if (!contains(it.next())) {
/*  255 */         return false;
/*      */       }
/*      */     }
/*  258 */     return true;
/*      */   }
/*      */ 
/*      */   public CursorableLinkedList<E>.Cursor cursor()
/*      */   {
/*  287 */     return new Cursor(0);
/*      */   }
/*      */ 
/*      */   public CursorableLinkedList<E>.Cursor cursor(int i)
/*      */   {
/*  307 */     return new Cursor(i);
/*      */   }
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/*  326 */     if (o == this)
/*  327 */       return true;
/*  328 */     if (!(o instanceof List)) {
/*  329 */       return false;
/*      */     }
/*  331 */     Iterator it = ((List)o).listIterator();
/*  332 */     Listable elt = this._head.next(); for (Listable past = null; (null != elt) && (past != this._head.prev()); elt = (past = elt).next()) {
/*  333 */       if ((!it.hasNext()) || (null == elt.value() ? null != it.next() : !elt.value().equals(it.next()))) {
/*  334 */         return false;
/*      */       }
/*      */     }
/*  337 */     return !it.hasNext();
/*      */   }
/*      */ 
/*      */   public E get(int index)
/*      */   {
/*  350 */     return getListableAt(index).value();
/*      */   }
/*      */ 
/*      */   public E getFirst()
/*      */   {
/*      */     try
/*      */     {
/*  358 */       return this._head.next().value(); } catch (NullPointerException e) {
/*      */     }
/*  360 */     throw new NoSuchElementException();
/*      */   }
/*      */ 
/*      */   public E getLast()
/*      */   {
/*      */     try
/*      */     {
/*  369 */       return this._head.prev().value(); } catch (NullPointerException e) {
/*      */     }
/*  371 */     throw new NoSuchElementException();
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/*  398 */     int hash = 1;
/*  399 */     Listable elt = this._head.next(); for (Listable past = null; (null != elt) && (past != this._head.prev()); elt = (past = elt).next()) {
/*  400 */       hash = 31 * hash + (null == elt.value() ? 0 : elt.value().hashCode());
/*      */     }
/*  402 */     return hash;
/*      */   }
/*      */ 
/*      */   public int indexOf(Object o)
/*      */   {
/*  417 */     int ndx = 0;
/*      */ 
/*  421 */     if (null == o) {
/*  422 */       Listable elt = this._head.next(); for (Listable past = null; (null != elt) && (past != this._head.prev()); elt = (past = elt).next()) {
/*  423 */         if (null == elt.value()) {
/*  424 */           return ndx;
/*      */         }
/*  426 */         ndx++;
/*      */       }
/*      */     }
/*      */     else {
/*  430 */       Listable elt = this._head.next(); for (Listable past = null; (null != elt) && (past != this._head.prev()); elt = (past = elt).next()) {
/*  431 */         if (o.equals(elt.value())) {
/*  432 */           return ndx;
/*      */         }
/*  434 */         ndx++;
/*      */       }
/*      */     }
/*  437 */     return -1;
/*      */   }
/*      */ 
/*      */   public boolean isEmpty()
/*      */   {
/*  445 */     return 0 == this._size;
/*      */   }
/*      */ 
/*      */   public Iterator<E> iterator()
/*      */   {
/*  453 */     return listIterator(0);
/*      */   }
/*      */ 
/*      */   public int lastIndexOf(Object o)
/*      */   {
/*  468 */     int ndx = this._size - 1;
/*      */ 
/*  472 */     if (null == o) {
/*  473 */       Listable elt = this._head.prev(); for (Listable past = null; (null != elt) && (past != this._head.next()); elt = (past = elt).prev()) {
/*  474 */         if (null == elt.value()) {
/*  475 */           return ndx;
/*      */         }
/*  477 */         ndx--;
/*      */       }
/*      */     } else {
/*  480 */       Listable elt = this._head.prev(); for (Listable past = null; (null != elt) && (past != this._head.next()); elt = (past = elt).prev()) {
/*  481 */         if (o.equals(elt.value())) {
/*  482 */           return ndx;
/*      */         }
/*  484 */         ndx--;
/*      */       }
/*      */     }
/*  487 */     return -1;
/*      */   }
/*      */ 
/*      */   public ListIterator<E> listIterator()
/*      */   {
/*  495 */     return listIterator(0);
/*      */   }
/*      */ 
/*      */   public ListIterator<E> listIterator(int index)
/*      */   {
/*  503 */     if ((index < 0) || (index > this._size)) {
/*  504 */       throw new IndexOutOfBoundsException(index + " < 0 or > " + this._size);
/*      */     }
/*  506 */     return new ListIter(index);
/*      */   }
/*      */ 
/*      */   public boolean remove(Object o)
/*      */   {
/*  520 */     Listable elt = this._head.next(); for (Listable past = null; (null != elt) && (past != this._head.prev()); elt = (past = elt).next()) {
/*  521 */       if ((null == o) && (null == elt.value())) {
/*  522 */         removeListable(elt);
/*  523 */         return true;
/*  524 */       }if ((o != null) && (o.equals(elt.value()))) {
/*  525 */         removeListable(elt);
/*  526 */         return true;
/*      */       }
/*      */     }
/*  529 */     return false;
/*      */   }
/*      */ 
/*      */   public E remove(int index)
/*      */   {
/*  545 */     Listable elt = getListableAt(index);
/*  546 */     Object ret = elt.value();
/*  547 */     removeListable(elt);
/*  548 */     return ret;
/*      */   }
/*      */ 
/*      */   public boolean removeAll(Collection<?> c)
/*      */   {
/*  560 */     if ((0 == c.size()) || (0 == this._size)) {
/*  561 */       return false;
/*      */     }
/*  563 */     boolean changed = false;
/*  564 */     Iterator it = iterator();
/*  565 */     while (it.hasNext()) {
/*  566 */       if (c.contains(it.next())) {
/*  567 */         it.remove();
/*  568 */         changed = true;
/*      */       }
/*      */     }
/*  571 */     return changed;
/*      */   }
/*      */ 
/*      */   public E removeFirst()
/*      */   {
/*  579 */     if (this._head.next() != null) {
/*  580 */       Object val = this._head.next().value();
/*  581 */       removeListable(this._head.next());
/*  582 */       return val;
/*      */     }
/*  584 */     throw new NoSuchElementException();
/*      */   }
/*      */ 
/*      */   public E removeLast()
/*      */   {
/*  592 */     if (this._head.prev() != null) {
/*  593 */       Object val = this._head.prev().value();
/*  594 */       removeListable(this._head.prev());
/*  595 */       return val;
/*      */     }
/*  597 */     throw new NoSuchElementException();
/*      */   }
/*      */ 
/*      */   public boolean retainAll(Collection<?> c)
/*      */   {
/*  612 */     boolean changed = false;
/*  613 */     Iterator it = iterator();
/*  614 */     while (it.hasNext()) {
/*  615 */       if (!c.contains(it.next())) {
/*  616 */         it.remove();
/*  617 */         changed = true;
/*      */       }
/*      */     }
/*  620 */     return changed;
/*      */   }
/*      */ 
/*      */   public E set(int index, E element)
/*      */   {
/*  639 */     Listable elt = getListableAt(index);
/*  640 */     Object val = elt.setValue(element);
/*  641 */     broadcastListableChanged(elt);
/*  642 */     return val;
/*      */   }
/*      */ 
/*      */   public int size()
/*      */   {
/*  650 */     return this._size;
/*      */   }
/*      */ 
/*      */   public Object[] toArray()
/*      */   {
/*  661 */     Object[] array = new Object[this._size];
/*  662 */     int i = 0;
/*  663 */     Listable elt = this._head.next(); for (Listable past = null; (null != elt) && (past != this._head.prev()); elt = (past = elt).next()) {
/*  664 */       array[(i++)] = elt.value();
/*      */     }
/*  666 */     return array;
/*      */   }
/*      */ 
/*      */   public <T> T[] toArray(T[] a)
/*      */   {
/*  686 */     if (a.length < this._size) {
/*  687 */       a = (Object[])Array.newInstance(a.getClass().getComponentType(), this._size);
/*      */     }
/*  689 */     int i = 0;
/*  690 */     Listable elt = this._head.next(); for (Listable past = null; (null != elt) && (past != this._head.prev()); elt = (past = elt).next()) {
/*  691 */       a[(i++)] = elt.value();
/*      */     }
/*  693 */     if (a.length > this._size) {
/*  694 */       a[this._size] = null;
/*      */     }
/*  696 */     return a;
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/*  705 */     StringBuffer buf = new StringBuffer();
/*  706 */     buf.append("[");
/*  707 */     Listable elt = this._head.next(); for (Listable past = null; (null != elt) && (past != this._head.prev()); elt = (past = elt).next()) {
/*  708 */       if (this._head.next() != elt) {
/*  709 */         buf.append(", ");
/*      */       }
/*  711 */       buf.append(elt.value());
/*      */     }
/*  713 */     buf.append("]");
/*  714 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   public List<E> subList(int i, int j)
/*      */   {
/*  722 */     if ((i < 0) || (j > this._size) || (i > j))
/*  723 */       throw new IndexOutOfBoundsException();
/*  724 */     if ((i == 0) && (j == this._size)) {
/*  725 */       return this;
/*      */     }
/*  727 */     return new CursorableSubList(this, i, j);
/*      */   }
/*      */ 
/*      */   protected Listable<E> insertListable(Listable<E> before, Listable<E> after, E value)
/*      */   {
/*  742 */     this._modCount += 1;
/*  743 */     this._size += 1;
/*  744 */     Listable elt = new Listable(before, after, value);
/*  745 */     if (null != before)
/*  746 */       before.setNext(elt);
/*      */     else {
/*  748 */       this._head.setNext(elt);
/*      */     }
/*      */ 
/*  751 */     if (null != after)
/*  752 */       after.setPrev(elt);
/*      */     else {
/*  754 */       this._head.setPrev(elt);
/*      */     }
/*  756 */     broadcastListableInserted(elt);
/*  757 */     return elt;
/*      */   }
/*      */ 
/*      */   protected void removeListable(Listable<E> elt)
/*      */   {
/*  766 */     this._modCount += 1;
/*  767 */     this._size -= 1;
/*  768 */     if (this._head.next() == elt) {
/*  769 */       this._head.setNext(elt.next());
/*      */     }
/*  771 */     if (null != elt.next()) {
/*  772 */       elt.next().setPrev(elt.prev());
/*      */     }
/*  774 */     if (this._head.prev() == elt) {
/*  775 */       this._head.setPrev(elt.prev());
/*      */     }
/*  777 */     if (null != elt.prev()) {
/*  778 */       elt.prev().setNext(elt.next());
/*      */     }
/*  780 */     broadcastListableRemoved(elt);
/*      */   }
/*      */ 
/*      */   protected Listable<E> getListableAt(int index)
/*      */   {
/*  792 */     if ((index < 0) || (index >= this._size)) {
/*  793 */       throw new IndexOutOfBoundsException(String.valueOf(index) + " < 0 or " + String.valueOf(index) + " >= " + this._size);
/*      */     }
/*  795 */     if (index <= this._size / 2) {
/*  796 */       Listable elt = this._head.next();
/*  797 */       for (int i = 0; i < index; i++) {
/*  798 */         elt = elt.next();
/*      */       }
/*  800 */       return elt;
/*      */     }
/*  802 */     Listable elt = this._head.prev();
/*  803 */     for (int i = this._size - 1; i > index; i--) {
/*  804 */       elt = elt.prev();
/*      */     }
/*  806 */     return elt;
/*      */   }
/*      */ 
/*      */   protected void registerCursor(CursorableLinkedList<E>.Cursor cur)
/*      */   {
/*  817 */     for (Iterator it = this._cursors.iterator(); it.hasNext(); ) {
/*  818 */       WeakReference ref = (WeakReference)it.next();
/*  819 */       if (ref.get() == null) {
/*  820 */         it.remove();
/*      */       }
/*      */     }
/*      */ 
/*  824 */     this._cursors.add(new WeakReference(cur));
/*      */   }
/*      */ 
/*      */   protected void unregisterCursor(CursorableLinkedList<E>.Cursor cur)
/*      */   {
/*  832 */     for (Iterator it = this._cursors.iterator(); it.hasNext(); ) {
/*  833 */       WeakReference ref = (WeakReference)it.next();
/*  834 */       Cursor cursor = (Cursor)ref.get();
/*  835 */       if (cursor == null)
/*      */       {
/*  839 */         it.remove();
/*      */       }
/*  841 */       else if (cursor == cur) {
/*  842 */         ref.clear();
/*  843 */         it.remove();
/*  844 */         break;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void invalidateCursors()
/*      */   {
/*  854 */     Iterator it = this._cursors.iterator();
/*  855 */     while (it.hasNext()) {
/*  856 */       WeakReference ref = (WeakReference)it.next();
/*  857 */       Cursor cursor = (Cursor)ref.get();
/*  858 */       if (cursor != null)
/*      */       {
/*  860 */         cursor.invalidate();
/*  861 */         ref.clear();
/*      */       }
/*  863 */       it.remove();
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void broadcastListableChanged(Listable<E> elt)
/*      */   {
/*  873 */     Iterator it = this._cursors.iterator();
/*  874 */     while (it.hasNext()) {
/*  875 */       WeakReference ref = (WeakReference)it.next();
/*  876 */       Cursor cursor = (Cursor)ref.get();
/*  877 */       if (cursor == null)
/*  878 */         it.remove();
/*      */       else
/*  880 */         cursor.listableChanged(elt);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void broadcastListableRemoved(Listable<E> elt)
/*      */   {
/*  890 */     Iterator it = this._cursors.iterator();
/*  891 */     while (it.hasNext()) {
/*  892 */       WeakReference ref = (WeakReference)it.next();
/*  893 */       Cursor cursor = (Cursor)ref.get();
/*  894 */       if (cursor == null)
/*  895 */         it.remove();
/*      */       else
/*  897 */         cursor.listableRemoved(elt);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void broadcastListableInserted(Listable<E> elt)
/*      */   {
/*  907 */     Iterator it = this._cursors.iterator();
/*  908 */     while (it.hasNext()) {
/*  909 */       WeakReference ref = (WeakReference)it.next();
/*  910 */       Cursor cursor = (Cursor)ref.get();
/*  911 */       if (cursor == null)
/*  912 */         it.remove();
/*      */       else
/*  914 */         cursor.listableInserted(elt);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void writeObject(ObjectOutputStream out) throws IOException
/*      */   {
/*  920 */     out.defaultWriteObject();
/*  921 */     out.writeInt(this._size);
/*  922 */     Listable cur = this._head.next();
/*  923 */     while (cur != null) {
/*  924 */       out.writeObject(cur.value());
/*  925 */       cur = cur.next();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
/*      */   {
/*  931 */     in.defaultReadObject();
/*  932 */     this._size = 0;
/*  933 */     this._modCount = 0;
/*  934 */     this._cursors = new ArrayList();
/*  935 */     this._head = new Listable(null, null, null);
/*  936 */     int size = in.readInt();
/*  937 */     for (int i = 0; i < size; i++)
/*  938 */       add(in.readObject());
/*      */   }
/*      */ 
/*      */   public class Cursor extends CursorableLinkedList<E>.ListIter
/*      */     implements ListIterator<E>
/*      */   {
/* 1123 */     boolean _valid = false;
/*      */ 
/*      */     Cursor(int index) {
/* 1126 */       super(index);
/* 1127 */       this._valid = true;
/* 1128 */       CursorableLinkedList.this.registerCursor(this);
/*      */     }
/*      */ 
/*      */     public int previousIndex()
/*      */     {
/* 1133 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public int nextIndex()
/*      */     {
/* 1138 */       throw new UnsupportedOperationException();
/*      */     }
/*      */ 
/*      */     public void add(E o)
/*      */     {
/* 1143 */       checkForComod();
/* 1144 */       CursorableLinkedList.Listable elt = CursorableLinkedList.this.insertListable(this._cur.prev(), this._cur.next(), o);
/* 1145 */       this._cur.setPrev(elt);
/* 1146 */       this._cur.setNext(elt.next());
/* 1147 */       this._lastReturned = null;
/* 1148 */       this._nextIndex += 1;
/* 1149 */       this._expectedModCount += 1;
/*      */     }
/*      */ 
/*      */     protected void listableRemoved(CursorableLinkedList.Listable<E> elt) {
/* 1153 */       if (null == CursorableLinkedList.this._head.prev())
/* 1154 */         this._cur.setNext(null);
/* 1155 */       else if (this._cur.next() == elt) {
/* 1156 */         this._cur.setNext(elt.next());
/*      */       }
/* 1158 */       if (null == CursorableLinkedList.this._head.next())
/* 1159 */         this._cur.setPrev(null);
/* 1160 */       else if (this._cur.prev() == elt) {
/* 1161 */         this._cur.setPrev(elt.prev());
/*      */       }
/* 1163 */       if (this._lastReturned == elt)
/* 1164 */         this._lastReturned = null;
/*      */     }
/*      */ 
/*      */     protected void listableInserted(CursorableLinkedList.Listable<E> elt)
/*      */     {
/* 1169 */       if ((null == this._cur.next()) && (null == this._cur.prev()))
/* 1170 */         this._cur.setNext(elt);
/* 1171 */       else if (this._cur.prev() == elt.prev()) {
/* 1172 */         this._cur.setNext(elt);
/*      */       }
/* 1174 */       if (this._cur.next() == elt.next()) {
/* 1175 */         this._cur.setPrev(elt);
/*      */       }
/* 1177 */       if (this._lastReturned == elt)
/* 1178 */         this._lastReturned = null;
/*      */     }
/*      */ 
/*      */     protected void listableChanged(CursorableLinkedList.Listable<E> elt)
/*      */     {
/* 1183 */       if (this._lastReturned == elt)
/* 1184 */         this._lastReturned = null;
/*      */     }
/*      */ 
/*      */     protected void checkForComod()
/*      */     {
/* 1190 */       if (!this._valid)
/* 1191 */         throw new ConcurrentModificationException();
/*      */     }
/*      */ 
/*      */     protected void invalidate()
/*      */     {
/* 1196 */       this._valid = false;
/*      */     }
/*      */ 
/*      */     public void close()
/*      */     {
/* 1208 */       if (this._valid) {
/* 1209 */         this._valid = false;
/* 1210 */         CursorableLinkedList.this.unregisterCursor(this);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   class ListIter
/*      */     implements ListIterator<E>
/*      */   {
/* 1011 */     CursorableLinkedList.Listable<E> _cur = null;
/* 1012 */     CursorableLinkedList.Listable<E> _lastReturned = null;
/* 1013 */     int _expectedModCount = CursorableLinkedList.this._modCount;
/* 1014 */     int _nextIndex = 0;
/*      */ 
/*      */     ListIter(int index)
/*      */     {
/*      */       CursorableLinkedList.Listable temp;
/* 1017 */       if (index == 0) {
/* 1018 */         this._cur = new CursorableLinkedList.Listable(null, CursorableLinkedList.this._head.next(), null);
/* 1019 */         this._nextIndex = 0;
/* 1020 */       } else if (index == CursorableLinkedList.this._size) {
/* 1021 */         this._cur = new CursorableLinkedList.Listable(CursorableLinkedList.this._head.prev(), null, null);
/* 1022 */         this._nextIndex = CursorableLinkedList.this._size;
/*      */       } else {
/* 1024 */         temp = CursorableLinkedList.this.getListableAt(index);
/* 1025 */         this._cur = new CursorableLinkedList.Listable(temp.prev(), temp, null);
/* 1026 */         this._nextIndex = index;
/*      */       }
/*      */     }
/*      */ 
/*      */     public E previous() {
/* 1031 */       checkForComod();
/* 1032 */       if (!hasPrevious()) {
/* 1033 */         throw new NoSuchElementException();
/*      */       }
/* 1035 */       Object ret = this._cur.prev().value();
/* 1036 */       this._lastReturned = this._cur.prev();
/* 1037 */       this._cur.setNext(this._cur.prev());
/* 1038 */       this._cur.setPrev(this._cur.prev().prev());
/* 1039 */       this._nextIndex -= 1;
/* 1040 */       return ret;
/*      */     }
/*      */ 
/*      */     public boolean hasNext()
/*      */     {
/* 1045 */       checkForComod();
/* 1046 */       return (null != this._cur.next()) && (this._cur.prev() != CursorableLinkedList.this._head.prev());
/*      */     }
/*      */ 
/*      */     public E next() {
/* 1050 */       checkForComod();
/* 1051 */       if (!hasNext()) {
/* 1052 */         throw new NoSuchElementException();
/*      */       }
/* 1054 */       Object ret = this._cur.next().value();
/* 1055 */       this._lastReturned = this._cur.next();
/* 1056 */       this._cur.setPrev(this._cur.next());
/* 1057 */       this._cur.setNext(this._cur.next().next());
/* 1058 */       this._nextIndex += 1;
/* 1059 */       return ret;
/*      */     }
/*      */ 
/*      */     public int previousIndex()
/*      */     {
/* 1064 */       checkForComod();
/* 1065 */       if (!hasPrevious()) {
/* 1066 */         return -1;
/*      */       }
/* 1068 */       return this._nextIndex - 1;
/*      */     }
/*      */ 
/*      */     public boolean hasPrevious() {
/* 1072 */       checkForComod();
/* 1073 */       return (null != this._cur.prev()) && (this._cur.next() != CursorableLinkedList.this._head.next());
/*      */     }
/*      */ 
/*      */     public void set(E o) {
/* 1077 */       checkForComod();
/*      */       try {
/* 1079 */         this._lastReturned.setValue(o);
/*      */       } catch (NullPointerException e) {
/* 1081 */         throw new IllegalStateException();
/*      */       }
/*      */     }
/*      */ 
/*      */     public int nextIndex() {
/* 1086 */       checkForComod();
/* 1087 */       if (!hasNext()) {
/* 1088 */         return CursorableLinkedList.this.size();
/*      */       }
/* 1090 */       return this._nextIndex;
/*      */     }
/*      */ 
/*      */     public void remove() {
/* 1094 */       checkForComod();
/* 1095 */       if (null == this._lastReturned) {
/* 1096 */         throw new IllegalStateException();
/*      */       }
/* 1098 */       this._cur.setNext(this._lastReturned == CursorableLinkedList.this._head.prev() ? null : this._lastReturned.next());
/* 1099 */       this._cur.setPrev(this._lastReturned == CursorableLinkedList.this._head.next() ? null : this._lastReturned.prev());
/* 1100 */       CursorableLinkedList.this.removeListable(this._lastReturned);
/* 1101 */       this._lastReturned = null;
/* 1102 */       this._nextIndex -= 1;
/* 1103 */       this._expectedModCount += 1;
/*      */     }
/*      */ 
/*      */     public void add(E o)
/*      */     {
/* 1108 */       checkForComod();
/* 1109 */       this._cur.setPrev(CursorableLinkedList.this.insertListable(this._cur.prev(), this._cur.next(), o));
/* 1110 */       this._lastReturned = null;
/* 1111 */       this._nextIndex += 1;
/* 1112 */       this._expectedModCount += 1;
/*      */     }
/*      */ 
/*      */     protected void checkForComod() {
/* 1116 */       if (this._expectedModCount != CursorableLinkedList.this._modCount)
/* 1117 */         throw new ConcurrentModificationException();
/*      */     }
/*      */   }
/*      */ 
/*      */   static class Listable<E>
/*      */     implements Serializable
/*      */   {
/*  973 */     private Listable<E> _prev = null;
/*  974 */     private Listable<E> _next = null;
/*  975 */     private E _val = null;
/*      */ 
/*      */     Listable(Listable<E> prev, Listable<E> next, E val) {
/*  978 */       this._prev = prev;
/*  979 */       this._next = next;
/*  980 */       this._val = val;
/*      */     }
/*      */ 
/*      */     Listable<E> next() {
/*  984 */       return this._next;
/*      */     }
/*      */ 
/*      */     Listable<E> prev() {
/*  988 */       return this._prev;
/*      */     }
/*      */ 
/*      */     E value() {
/*  992 */       return this._val;
/*      */     }
/*      */ 
/*      */     void setNext(Listable<E> next) {
/*  996 */       this._next = next;
/*      */     }
/*      */ 
/*      */     void setPrev(Listable<E> prev) {
/* 1000 */       this._prev = prev;
/*      */     }
/*      */ 
/*      */     E setValue(E val) {
/* 1004 */       Object temp = this._val;
/* 1005 */       this._val = val;
/* 1006 */       return temp;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.pool.impl.CursorableLinkedList
 * JD-Core Version:    0.6.2
 */