/*      */ package org.apache.commons.pool.impl;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.TimerTask;
/*      */ import org.apache.commons.pool.BaseObjectPool;
/*      */ import org.apache.commons.pool.ObjectPool;
/*      */ import org.apache.commons.pool.PoolUtils;
/*      */ import org.apache.commons.pool.PoolableObjectFactory;
/*      */ 
/*      */ public class GenericObjectPool<T> extends BaseObjectPool<T>
/*      */   implements ObjectPool<T>
/*      */ {
/*      */   public static final byte WHEN_EXHAUSTED_FAIL = 0;
/*      */   public static final byte WHEN_EXHAUSTED_BLOCK = 1;
/*      */   public static final byte WHEN_EXHAUSTED_GROW = 2;
/*      */   public static final int DEFAULT_MAX_IDLE = 8;
/*      */   public static final int DEFAULT_MIN_IDLE = 0;
/*      */   public static final int DEFAULT_MAX_ACTIVE = 8;
/*      */   public static final byte DEFAULT_WHEN_EXHAUSTED_ACTION = 1;
/*      */   public static final boolean DEFAULT_LIFO = true;
/*      */   public static final long DEFAULT_MAX_WAIT = -1L;
/*      */   public static final boolean DEFAULT_TEST_ON_BORROW = false;
/*      */   public static final boolean DEFAULT_TEST_ON_RETURN = false;
/*      */   public static final boolean DEFAULT_TEST_WHILE_IDLE = false;
/*      */   public static final long DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS = -1L;
/*      */   public static final int DEFAULT_NUM_TESTS_PER_EVICTION_RUN = 3;
/*      */   public static final long DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS = 1800000L;
/*      */   public static final long DEFAULT_SOFT_MIN_EVICTABLE_IDLE_TIME_MILLIS = -1L;
/* 1918 */   private int _maxIdle = 8;
/*      */ 
/* 1925 */   private int _minIdle = 0;
/*      */ 
/* 1932 */   private int _maxActive = 8;
/*      */ 
/* 1950 */   private long _maxWait = -1L;
/*      */ 
/* 1964 */   private byte _whenExhaustedAction = 1;
/*      */ 
/* 1977 */   private volatile boolean _testOnBorrow = false;
/*      */ 
/* 1988 */   private volatile boolean _testOnReturn = false;
/*      */ 
/* 2001 */   private boolean _testWhileIdle = false;
/*      */ 
/* 2012 */   private long _timeBetweenEvictionRunsMillis = -1L;
/*      */ 
/* 2027 */   private int _numTestsPerEvictionRun = 3;
/*      */ 
/* 2041 */   private long _minEvictableIdleTimeMillis = 1800000L;
/*      */ 
/* 2054 */   private long _softMinEvictableIdleTimeMillis = -1L;
/*      */ 
/* 2057 */   private boolean _lifo = true;
/*      */ 
/* 2060 */   private CursorableLinkedList<GenericKeyedObjectPool.ObjectTimestampPair<T>> _pool = null;
/*      */ 
/* 2063 */   private CursorableLinkedList<GenericKeyedObjectPool.ObjectTimestampPair<T>>.Cursor _evictionCursor = null;
/*      */ 
/* 2066 */   private PoolableObjectFactory<T> _factory = null;
/*      */ 
/* 2072 */   private int _numActive = 0;
/*      */ 
/* 2077 */   private GenericObjectPool<T>.Evictor _evictor = null;
/*      */ 
/* 2084 */   private int _numInternalProcessing = 0;
/*      */ 
/* 2091 */   private final LinkedList<Latch<T>> _allocationQueue = new LinkedList();
/*      */ 
/*      */   public GenericObjectPool()
/*      */   {
/*  344 */     this(null, 8, (byte)1, -1L, 8, 0, false, false, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericObjectPool(PoolableObjectFactory<T> factory)
/*      */   {
/*  354 */     this(factory, 8, (byte)1, -1L, 8, 0, false, false, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericObjectPool(PoolableObjectFactory<T> factory, Config config)
/*      */   {
/*  365 */     this(factory, config.maxActive, config.whenExhaustedAction, config.maxWait, config.maxIdle, config.minIdle, config.testOnBorrow, config.testOnReturn, config.timeBetweenEvictionRunsMillis, config.numTestsPerEvictionRun, config.minEvictableIdleTimeMillis, config.testWhileIdle, config.softMinEvictableIdleTimeMillis, config.lifo);
/*      */   }
/*      */ 
/*      */   public GenericObjectPool(PoolableObjectFactory<T> factory, int maxActive)
/*      */   {
/*  377 */     this(factory, maxActive, (byte)1, -1L, 8, 0, false, false, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericObjectPool(PoolableObjectFactory<T> factory, int maxActive, byte whenExhaustedAction, long maxWait)
/*      */   {
/*  391 */     this(factory, maxActive, whenExhaustedAction, maxWait, 8, 0, false, false, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericObjectPool(PoolableObjectFactory<T> factory, int maxActive, byte whenExhaustedAction, long maxWait, boolean testOnBorrow, boolean testOnReturn)
/*      */   {
/*  410 */     this(factory, maxActive, whenExhaustedAction, maxWait, 8, 0, testOnBorrow, testOnReturn, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericObjectPool(PoolableObjectFactory<T> factory, int maxActive, byte whenExhaustedAction, long maxWait, int maxIdle)
/*      */   {
/*  425 */     this(factory, maxActive, whenExhaustedAction, maxWait, maxIdle, 0, false, false, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericObjectPool(PoolableObjectFactory<T> factory, int maxActive, byte whenExhaustedAction, long maxWait, int maxIdle, boolean testOnBorrow, boolean testOnReturn)
/*      */   {
/*  445 */     this(factory, maxActive, whenExhaustedAction, maxWait, maxIdle, 0, testOnBorrow, testOnReturn, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericObjectPool(PoolableObjectFactory<T> factory, int maxActive, byte whenExhaustedAction, long maxWait, int maxIdle, boolean testOnBorrow, boolean testOnReturn, long timeBetweenEvictionRunsMillis, int numTestsPerEvictionRun, long minEvictableIdleTimeMillis, boolean testWhileIdle)
/*      */   {
/*  474 */     this(factory, maxActive, whenExhaustedAction, maxWait, maxIdle, 0, testOnBorrow, testOnReturn, timeBetweenEvictionRunsMillis, numTestsPerEvictionRun, minEvictableIdleTimeMillis, testWhileIdle);
/*      */   }
/*      */ 
/*      */   public GenericObjectPool(PoolableObjectFactory<T> factory, int maxActive, byte whenExhaustedAction, long maxWait, int maxIdle, int minIdle, boolean testOnBorrow, boolean testOnReturn, long timeBetweenEvictionRunsMillis, int numTestsPerEvictionRun, long minEvictableIdleTimeMillis, boolean testWhileIdle)
/*      */   {
/*  503 */     this(factory, maxActive, whenExhaustedAction, maxWait, maxIdle, minIdle, testOnBorrow, testOnReturn, timeBetweenEvictionRunsMillis, numTestsPerEvictionRun, minEvictableIdleTimeMillis, testWhileIdle, -1L);
/*      */   }
/*      */ 
/*      */   public GenericObjectPool(PoolableObjectFactory<T> factory, int maxActive, byte whenExhaustedAction, long maxWait, int maxIdle, int minIdle, boolean testOnBorrow, boolean testOnReturn, long timeBetweenEvictionRunsMillis, int numTestsPerEvictionRun, long minEvictableIdleTimeMillis, boolean testWhileIdle, long softMinEvictableIdleTimeMillis)
/*      */   {
/*  538 */     this(factory, maxActive, whenExhaustedAction, maxWait, maxIdle, minIdle, testOnBorrow, testOnReturn, timeBetweenEvictionRunsMillis, numTestsPerEvictionRun, minEvictableIdleTimeMillis, testWhileIdle, softMinEvictableIdleTimeMillis, true);
/*      */   }
/*      */ 
/*      */   public GenericObjectPool(PoolableObjectFactory<T> factory, int maxActive, byte whenExhaustedAction, long maxWait, int maxIdle, int minIdle, boolean testOnBorrow, boolean testOnReturn, long timeBetweenEvictionRunsMillis, int numTestsPerEvictionRun, long minEvictableIdleTimeMillis, boolean testWhileIdle, long softMinEvictableIdleTimeMillis, boolean lifo)
/*      */   {
/*  575 */     this._factory = factory;
/*  576 */     this._maxActive = maxActive;
/*  577 */     this._lifo = lifo;
/*  578 */     switch (whenExhaustedAction) {
/*      */     case 0:
/*      */     case 1:
/*      */     case 2:
/*  582 */       this._whenExhaustedAction = whenExhaustedAction;
/*  583 */       break;
/*      */     default:
/*  585 */       throw new IllegalArgumentException("whenExhaustedAction " + whenExhaustedAction + " not recognized.");
/*      */     }
/*  587 */     this._maxWait = maxWait;
/*  588 */     this._maxIdle = maxIdle;
/*  589 */     this._minIdle = minIdle;
/*  590 */     this._testOnBorrow = testOnBorrow;
/*  591 */     this._testOnReturn = testOnReturn;
/*  592 */     this._timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis;
/*  593 */     this._numTestsPerEvictionRun = numTestsPerEvictionRun;
/*  594 */     this._minEvictableIdleTimeMillis = minEvictableIdleTimeMillis;
/*  595 */     this._softMinEvictableIdleTimeMillis = softMinEvictableIdleTimeMillis;
/*  596 */     this._testWhileIdle = testWhileIdle;
/*      */ 
/*  598 */     this._pool = new CursorableLinkedList();
/*  599 */     startEvictor(this._timeBetweenEvictionRunsMillis);
/*      */   }
/*      */ 
/*      */   public synchronized int getMaxActive()
/*      */   {
/*  616 */     return this._maxActive;
/*      */   }
/*      */ 
/*      */   public void setMaxActive(int maxActive)
/*      */   {
/*  630 */     synchronized (this) {
/*  631 */       this._maxActive = maxActive;
/*      */     }
/*  633 */     allocate();
/*      */   }
/*      */ 
/*      */   public synchronized byte getWhenExhaustedAction()
/*      */   {
/*  645 */     return this._whenExhaustedAction;
/*      */   }
/*      */ 
/*      */   public void setWhenExhaustedAction(byte whenExhaustedAction)
/*      */   {
/*  659 */     synchronized (this) {
/*  660 */       switch (whenExhaustedAction) {
/*      */       case 0:
/*      */       case 1:
/*      */       case 2:
/*  664 */         this._whenExhaustedAction = whenExhaustedAction;
/*  665 */         break;
/*      */       default:
/*  667 */         throw new IllegalArgumentException("whenExhaustedAction " + whenExhaustedAction + " not recognized.");
/*      */       }
/*      */     }
/*  670 */     allocate();
/*      */   }
/*      */ 
/*      */   public synchronized long getMaxWait()
/*      */   {
/*  690 */     return this._maxWait;
/*      */   }
/*      */ 
/*      */   public void setMaxWait(long maxWait)
/*      */   {
/*  709 */     synchronized (this) {
/*  710 */       this._maxWait = maxWait;
/*      */     }
/*  712 */     allocate();
/*      */   }
/*      */ 
/*      */   public synchronized int getMaxIdle()
/*      */   {
/*  721 */     return this._maxIdle;
/*      */   }
/*      */ 
/*      */   public void setMaxIdle(int maxIdle)
/*      */   {
/*  738 */     synchronized (this) {
/*  739 */       this._maxIdle = maxIdle;
/*      */     }
/*  741 */     allocate();
/*      */   }
/*      */ 
/*      */   public void setMinIdle(int minIdle)
/*      */   {
/*  757 */     synchronized (this) {
/*  758 */       this._minIdle = minIdle;
/*      */     }
/*  760 */     allocate();
/*      */   }
/*      */ 
/*      */   public synchronized int getMinIdle()
/*      */   {
/*  772 */     return this._minIdle;
/*      */   }
/*      */ 
/*      */   public boolean getTestOnBorrow()
/*      */   {
/*  787 */     return this._testOnBorrow;
/*      */   }
/*      */ 
/*      */   public void setTestOnBorrow(boolean testOnBorrow)
/*      */   {
/*  802 */     this._testOnBorrow = testOnBorrow;
/*      */   }
/*      */ 
/*      */   public boolean getTestOnReturn()
/*      */   {
/*  815 */     return this._testOnReturn;
/*      */   }
/*      */ 
/*      */   public void setTestOnReturn(boolean testOnReturn)
/*      */   {
/*  828 */     this._testOnReturn = testOnReturn;
/*      */   }
/*      */ 
/*      */   public synchronized long getTimeBetweenEvictionRunsMillis()
/*      */   {
/*  841 */     return this._timeBetweenEvictionRunsMillis;
/*      */   }
/*      */ 
/*      */   public synchronized void setTimeBetweenEvictionRunsMillis(long timeBetweenEvictionRunsMillis)
/*      */   {
/*  854 */     this._timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis;
/*  855 */     startEvictor(this._timeBetweenEvictionRunsMillis);
/*      */   }
/*      */ 
/*      */   public synchronized int getNumTestsPerEvictionRun()
/*      */   {
/*  867 */     return this._numTestsPerEvictionRun;
/*      */   }
/*      */ 
/*      */   public synchronized void setNumTestsPerEvictionRun(int numTestsPerEvictionRun)
/*      */   {
/*  885 */     this._numTestsPerEvictionRun = numTestsPerEvictionRun;
/*      */   }
/*      */ 
/*      */   public synchronized long getMinEvictableIdleTimeMillis()
/*      */   {
/*  898 */     return this._minEvictableIdleTimeMillis;
/*      */   }
/*      */ 
/*      */   public synchronized void setMinEvictableIdleTimeMillis(long minEvictableIdleTimeMillis)
/*      */   {
/*  913 */     this._minEvictableIdleTimeMillis = minEvictableIdleTimeMillis;
/*      */   }
/*      */ 
/*      */   public synchronized long getSoftMinEvictableIdleTimeMillis()
/*      */   {
/*  927 */     return this._softMinEvictableIdleTimeMillis;
/*      */   }
/*      */ 
/*      */   public synchronized void setSoftMinEvictableIdleTimeMillis(long softMinEvictableIdleTimeMillis)
/*      */   {
/*  944 */     this._softMinEvictableIdleTimeMillis = softMinEvictableIdleTimeMillis;
/*      */   }
/*      */ 
/*      */   public synchronized boolean getTestWhileIdle()
/*      */   {
/*  958 */     return this._testWhileIdle;
/*      */   }
/*      */ 
/*      */   public synchronized void setTestWhileIdle(boolean testWhileIdle)
/*      */   {
/*  972 */     this._testWhileIdle = testWhileIdle;
/*      */   }
/*      */ 
/*      */   public synchronized boolean getLifo()
/*      */   {
/*  986 */     return this._lifo;
/*      */   }
/*      */ 
/*      */   public synchronized void setLifo(boolean lifo)
/*      */   {
/* 1000 */     this._lifo = lifo;
/*      */   }
/*      */ 
/*      */   public void setConfig(Config conf)
/*      */   {
/* 1010 */     synchronized (this) {
/* 1011 */       setMaxIdle(conf.maxIdle);
/* 1012 */       setMinIdle(conf.minIdle);
/* 1013 */       setMaxActive(conf.maxActive);
/* 1014 */       setMaxWait(conf.maxWait);
/* 1015 */       setWhenExhaustedAction(conf.whenExhaustedAction);
/* 1016 */       setTestOnBorrow(conf.testOnBorrow);
/* 1017 */       setTestOnReturn(conf.testOnReturn);
/* 1018 */       setTestWhileIdle(conf.testWhileIdle);
/* 1019 */       setNumTestsPerEvictionRun(conf.numTestsPerEvictionRun);
/* 1020 */       setMinEvictableIdleTimeMillis(conf.minEvictableIdleTimeMillis);
/* 1021 */       setTimeBetweenEvictionRunsMillis(conf.timeBetweenEvictionRunsMillis);
/* 1022 */       setSoftMinEvictableIdleTimeMillis(conf.softMinEvictableIdleTimeMillis);
/* 1023 */       setLifo(conf.lifo);
/*      */     }
/* 1025 */     allocate();
/*      */   }
/*      */ 
/*      */   public T borrowObject()
/*      */     throws Exception
/*      */   {
/* 1059 */     long starttime = System.currentTimeMillis();
/* 1060 */     Latch latch = new Latch(null);
/*      */     byte whenExhaustedAction;
/*      */     long maxWait;
/* 1063 */     synchronized (this)
/*      */     {
/* 1067 */       whenExhaustedAction = this._whenExhaustedAction;
/* 1068 */       maxWait = this._maxWait;
/*      */ 
/* 1071 */       this._allocationQueue.add(latch);
/*      */     }
/*      */ 
/* 1075 */     allocate();
/*      */     while (true)
/*      */     {
/* 1078 */       synchronized (this) {
/* 1079 */         assertOpen();
/*      */       }
/*      */ 
/* 1083 */       if (latch.getPair() == null)
/*      */       {
/* 1085 */         if (!latch.mayCreate())
/*      */         {
/* 1089 */           switch (whenExhaustedAction)
/*      */           {
/*      */           case 2:
/* 1092 */             synchronized (this)
/*      */             {
/* 1095 */               if ((latch.getPair() == null) && (!latch.mayCreate())) {
/* 1096 */                 this._allocationQueue.remove(latch);
/* 1097 */                 this._numInternalProcessing += 1;
/*      */               }
/*      */             }
/* 1100 */             break;
/*      */           case 0:
/* 1102 */             synchronized (this)
/*      */             {
/* 1105 */               if ((latch.getPair() == null) && (latch.mayCreate())) {
/*      */                 break label582;
/*      */               }
/* 1108 */               this._allocationQueue.remove(latch);
/*      */             }
/* 1110 */             throw new NoSuchElementException("Pool exhausted");
/*      */           case 1:
/*      */             try {
/* 1113 */               synchronized (latch)
/*      */               {
/* 1116 */                 if ((latch.getPair() == null) && (!latch.mayCreate())) {
/* 1117 */                   if (maxWait <= 0L) {
/* 1118 */                     latch.wait();
/*      */                   }
/*      */                   else
/*      */                   {
/* 1122 */                     long elapsed = System.currentTimeMillis() - starttime;
/* 1123 */                     long waitTime = maxWait - elapsed;
/* 1124 */                     if (waitTime > 0L)
/*      */                     {
/* 1126 */                       latch.wait(waitTime);
/*      */                     }
/*      */                   }
/*      */                 }
/* 1130 */                 else break label582;
/*      */ 
/*      */               }
/*      */ 
/* 1134 */               if (isClosed() == true)
/* 1135 */                 throw new IllegalStateException("Pool closed");
/*      */             }
/*      */             catch (InterruptedException e) {
/* 1138 */               boolean doAllocate = false;
/* 1139 */               synchronized (this)
/*      */               {
/* 1141 */                 if ((latch.getPair() == null) && (!latch.mayCreate()))
/*      */                 {
/* 1144 */                   this._allocationQueue.remove(latch);
/* 1145 */                 } else if ((latch.getPair() == null) && (latch.mayCreate()))
/*      */                 {
/* 1148 */                   this._numInternalProcessing -= 1;
/* 1149 */                   doAllocate = true;
/*      */                 }
/*      */                 else {
/* 1152 */                   this._numInternalProcessing -= 1;
/* 1153 */                   this._numActive += 1;
/* 1154 */                   returnObject(latch.getPair().getValue());
/*      */                 }
/*      */               }
/* 1157 */               if (doAllocate) {
/* 1158 */                 allocate();
/*      */               }
/* 1160 */               Thread.currentThread().interrupt();
/* 1161 */               throw e;
/*      */             }
/* 1163 */             if ((maxWait <= 0L) || (System.currentTimeMillis() - starttime < maxWait)) continue;
/* 1164 */             synchronized (this)
/*      */             {
/* 1167 */               if ((latch.getPair() == null) && (!latch.mayCreate()))
/*      */               {
/* 1169 */                 this._allocationQueue.remove(latch);
/*      */               }
/* 1171 */               else break label582;
/*      */             }
/*      */ 
/* 1174 */             throw new NoSuchElementException("Timeout waiting for idle object");
/*      */           default:
/* 1179 */             throw new IllegalArgumentException("WhenExhaustedAction property " + whenExhaustedAction + " not recognized.");
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1185 */         label582: boolean newlyCreated = false;
/* 1186 */         if (null == latch.getPair()) {
/*      */           try {
/* 1188 */             Object obj = this._factory.makeObject();
/* 1189 */             latch.setPair(new GenericKeyedObjectPool.ObjectTimestampPair(obj));
/* 1190 */             newlyCreated = true;
/*      */           } finally {
/* 1192 */             if (!newlyCreated)
/*      */             {
/* 1194 */               synchronized (this) {
/* 1195 */                 this._numInternalProcessing -= 1;
/*      */               }
/*      */ 
/* 1198 */               allocate();
/*      */             }
/*      */           }
/*      */         }
/*      */         try
/*      */         {
/* 1204 */           this._factory.activateObject(latch.getPair().value);
/* 1205 */           if ((this._testOnBorrow) && (!this._factory.validateObject(latch.getPair().value)))
/*      */           {
/* 1207 */             throw new Exception("ValidateObject failed");
/*      */           }
/* 1209 */           synchronized (this) {
/* 1210 */             this._numInternalProcessing -= 1;
/* 1211 */             this._numActive += 1;
/*      */           }
/* 1213 */           return latch.getPair().value;
/*      */         }
/*      */         catch (Throwable e) {
/* 1216 */           PoolUtils.checkRethrow(e);
/*      */           try
/*      */           {
/* 1219 */             this._factory.destroyObject(latch.getPair().value);
/*      */           } catch (Throwable e2) {
/* 1221 */             PoolUtils.checkRethrow(e2);
/*      */           }
/*      */ 
/* 1224 */           synchronized (this) {
/* 1225 */             this._numInternalProcessing -= 1;
/* 1226 */             if (!newlyCreated) {
/* 1227 */               latch.reset();
/* 1228 */               this._allocationQueue.add(0, latch);
/*      */             }
/*      */           }
/* 1231 */           allocate();
/* 1232 */           if (newlyCreated)
/* 1233 */             throw new NoSuchElementException("Could not create a validated object, cause: " + e.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void allocate()
/*      */   {
/* 1249 */     if (isClosed()) return;
/*      */ 
/* 1253 */     while ((!this._pool.isEmpty()) && (!this._allocationQueue.isEmpty())) {
/* 1254 */       Latch latch = (Latch)this._allocationQueue.removeFirst();
/* 1255 */       latch.setPair((GenericKeyedObjectPool.ObjectTimestampPair)this._pool.removeFirst());
/* 1256 */       this._numInternalProcessing += 1;
/* 1257 */       synchronized (latch) {
/* 1258 */         latch.notify();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1267 */     while ((!this._allocationQueue.isEmpty()) && ((this._maxActive < 0) || (this._numActive + this._numInternalProcessing < this._maxActive))) {
/* 1268 */       Latch latch = (Latch)this._allocationQueue.removeFirst();
/* 1269 */       latch.setMayCreate(true);
/* 1270 */       this._numInternalProcessing += 1;
/* 1271 */       synchronized (latch) {
/* 1272 */         latch.notify();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void invalidateObject(T obj)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/* 1289 */       if (this._factory != null)
/* 1290 */         this._factory.destroyObject(obj);
/*      */     }
/*      */     finally {
/* 1293 */       synchronized (this) {
/* 1294 */         this._numActive -= 1;
/*      */       }
/* 1296 */       allocate();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void clear()
/*      */   {
/* 1317 */     List toDestroy = new ArrayList();
/*      */ 
/* 1319 */     synchronized (this) {
/* 1320 */       toDestroy.addAll(this._pool);
/* 1321 */       this._numInternalProcessing += this._pool._size;
/* 1322 */       this._pool.clear();
/*      */     }
/* 1324 */     destroy(toDestroy, this._factory);
/*      */   }
/*      */ 
/*      */   private void destroy(Collection<GenericKeyedObjectPool.ObjectTimestampPair<T>> c, PoolableObjectFactory<T> factory)
/*      */   {
/* 1337 */     for (Iterator it = c.iterator(); it.hasNext(); )
/*      */       try {
/* 1339 */         factory.destroyObject(((GenericKeyedObjectPool.ObjectTimestampPair)it.next()).value);
/*      */       } catch (Exception e) {
/*      */       }
/*      */       finally {
/* 1343 */         synchronized (this) {
/* 1344 */           this._numInternalProcessing -= 1;
/*      */         }
/* 1346 */         allocate();
/*      */       }
/*      */   }
/*      */ 
/*      */   public synchronized int getNumActive()
/*      */   {
/* 1358 */     return this._numActive;
/*      */   }
/*      */ 
/*      */   public synchronized int getNumIdle()
/*      */   {
/* 1368 */     return this._pool.size();
/*      */   }
/*      */ 
/*      */   public void returnObject(T obj)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/* 1393 */       addObjectToPool(obj, true);
/*      */     } catch (Exception e) {
/* 1395 */       if (this._factory != null) {
/*      */         try {
/* 1397 */           this._factory.destroyObject(obj);
/*      */         }
/*      */         catch (Exception e2)
/*      */         {
/*      */         }
/*      */ 
/* 1404 */         synchronized (this) {
/* 1405 */           this._numActive -= 1;
/*      */         }
/* 1407 */         allocate();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void addObjectToPool(T obj, boolean decrementNumActive)
/*      */     throws Exception
/*      */   {
/* 1426 */     boolean success = true;
/* 1427 */     if ((this._testOnReturn) && (!this._factory.validateObject(obj)))
/* 1428 */       success = false;
/*      */     else {
/* 1430 */       this._factory.passivateObject(obj);
/*      */     }
/*      */ 
/* 1433 */     boolean shouldDestroy = !success;
/*      */ 
/* 1437 */     boolean doAllocate = false;
/* 1438 */     synchronized (this) {
/* 1439 */       if (isClosed()) {
/* 1440 */         shouldDestroy = true;
/*      */       }
/* 1442 */       else if ((this._maxIdle >= 0) && (this._pool.size() >= this._maxIdle)) {
/* 1443 */         shouldDestroy = true;
/* 1444 */       } else if (success)
/*      */       {
/* 1447 */         if (this._lifo)
/* 1448 */           this._pool.addFirst(new GenericKeyedObjectPool.ObjectTimestampPair(obj));
/*      */         else {
/* 1450 */           this._pool.addLast(new GenericKeyedObjectPool.ObjectTimestampPair(obj));
/*      */         }
/* 1452 */         if (decrementNumActive) {
/* 1453 */           this._numActive -= 1;
/*      */         }
/* 1455 */         doAllocate = true;
/*      */       }
/*      */     }
/*      */ 
/* 1459 */     if (doAllocate) {
/* 1460 */       allocate();
/*      */     }
/*      */ 
/* 1464 */     if (shouldDestroy) {
/*      */       try {
/* 1466 */         this._factory.destroyObject(obj);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/* 1471 */       if (decrementNumActive) {
/* 1472 */         synchronized (this) {
/* 1473 */           this._numActive -= 1;
/*      */         }
/* 1475 */         allocate();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws Exception
/*      */   {
/* 1493 */     super.close();
/* 1494 */     synchronized (this) {
/* 1495 */       clear();
/* 1496 */       startEvictor(-1L);
/*      */ 
/* 1498 */       while (this._allocationQueue.size() > 0) {
/* 1499 */         Latch l = (Latch)this._allocationQueue.removeFirst();
/*      */ 
/* 1501 */         synchronized (l)
/*      */         {
/* 1503 */           l.notify();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public void setFactory(PoolableObjectFactory<T> factory)
/*      */     throws IllegalStateException
/*      */   {
/* 1524 */     List toDestroy = new ArrayList();
/* 1525 */     PoolableObjectFactory oldFactory = this._factory;
/* 1526 */     synchronized (this) {
/* 1527 */       assertOpen();
/* 1528 */       if (0 < getNumActive()) {
/* 1529 */         throw new IllegalStateException("Objects are already active");
/*      */       }
/* 1531 */       toDestroy.addAll(this._pool);
/* 1532 */       this._numInternalProcessing += this._pool._size;
/* 1533 */       this._pool.clear();
/*      */ 
/* 1535 */       this._factory = factory;
/*      */     }
/* 1537 */     destroy(toDestroy, oldFactory);
/*      */   }
/*      */ 
/*      */   public void evict()
/*      */     throws Exception
/*      */   {
/* 1554 */     assertOpen();
/* 1555 */     synchronized (this) {
/* 1556 */       if (this._pool.isEmpty()) {
/* 1557 */         return;
/*      */       }
/* 1559 */       if (null == this._evictionCursor) {
/* 1560 */         this._evictionCursor = this._pool.cursor(this._lifo ? this._pool.size() : 0);
/*      */       }
/*      */     }
/*      */ 
/* 1564 */     int i = 0; for (int m = getNumTests(); i < m; i++)
/*      */     {
/*      */       GenericKeyedObjectPool.ObjectTimestampPair pair;
/* 1566 */       synchronized (this) {
/* 1567 */         if (((this._lifo) && (!this._evictionCursor.hasPrevious())) || ((!this._lifo) && (!this._evictionCursor.hasNext())))
/*      */         {
/* 1569 */           this._evictionCursor.close();
/* 1570 */           this._evictionCursor = this._pool.cursor(this._lifo ? this._pool.size() : 0);
/*      */         }
/*      */ 
/* 1573 */         pair = this._lifo ? (GenericKeyedObjectPool.ObjectTimestampPair)this._evictionCursor.previous() : (GenericKeyedObjectPool.ObjectTimestampPair)this._evictionCursor.next();
/*      */ 
/* 1577 */         this._evictionCursor.remove();
/* 1578 */         this._numInternalProcessing += 1;
/*      */       }
/*      */ 
/* 1581 */       boolean removeObject = false;
/* 1582 */       long idleTimeMilis = System.currentTimeMillis() - pair.tstamp;
/* 1583 */       if ((getMinEvictableIdleTimeMillis() > 0L) && (idleTimeMilis > getMinEvictableIdleTimeMillis()))
/*      */       {
/* 1585 */         removeObject = true;
/* 1586 */       } else if ((getSoftMinEvictableIdleTimeMillis() > 0L) && (idleTimeMilis > getSoftMinEvictableIdleTimeMillis()) && (getNumIdle() + 1 > getMinIdle()))
/*      */       {
/* 1589 */         removeObject = true;
/*      */       }
/* 1591 */       if ((getTestWhileIdle()) && (!removeObject)) {
/* 1592 */         boolean active = false;
/*      */         try {
/* 1594 */           this._factory.activateObject(pair.value);
/* 1595 */           active = true;
/*      */         } catch (Exception e) {
/* 1597 */           removeObject = true;
/*      */         }
/* 1599 */         if (active) {
/* 1600 */           if (!this._factory.validateObject(pair.value))
/* 1601 */             removeObject = true;
/*      */           else {
/*      */             try {
/* 1604 */               this._factory.passivateObject(pair.value);
/*      */             } catch (Exception e) {
/* 1606 */               removeObject = true;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1612 */       if (removeObject)
/*      */         try {
/* 1614 */           this._factory.destroyObject(pair.value);
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/* 1619 */       synchronized (this) {
/* 1620 */         if (!removeObject) {
/* 1621 */           this._evictionCursor.add(pair);
/* 1622 */           if (this._lifo)
/*      */           {
/* 1624 */             this._evictionCursor.previous();
/*      */           }
/*      */         }
/* 1627 */         this._numInternalProcessing -= 1;
/*      */       }
/*      */     }
/* 1630 */     allocate();
/*      */   }
/*      */ 
/*      */   private void ensureMinIdle()
/*      */     throws Exception
/*      */   {
/* 1645 */     int objectDeficit = calculateDeficit(false);
/* 1646 */     for (int j = 0; (j < objectDeficit) && (calculateDeficit(true) > 0); j++)
/*      */       try {
/* 1648 */         addObject();
/*      */       } finally {
/* 1650 */         synchronized (this) {
/* 1651 */           this._numInternalProcessing -= 1;
/*      */         }
/* 1653 */         allocate();
/*      */       }
/*      */   }
/*      */ 
/*      */   private synchronized int calculateDeficit(boolean incrementInternal)
/*      */   {
/* 1669 */     int objectDeficit = getMinIdle() - getNumIdle();
/* 1670 */     if (this._maxActive > 0) {
/* 1671 */       int growLimit = Math.max(0, getMaxActive() - getNumActive() - getNumIdle() - this._numInternalProcessing);
/*      */ 
/* 1673 */       objectDeficit = Math.min(objectDeficit, growLimit);
/*      */     }
/* 1675 */     if ((incrementInternal) && (objectDeficit > 0)) {
/* 1676 */       this._numInternalProcessing += 1;
/*      */     }
/* 1678 */     return objectDeficit;
/*      */   }
/*      */ 
/*      */   public void addObject()
/*      */     throws Exception
/*      */   {
/* 1687 */     assertOpen();
/* 1688 */     if (this._factory == null) {
/* 1689 */       throw new IllegalStateException("Cannot add objects without a factory.");
/*      */     }
/* 1691 */     Object obj = this._factory.makeObject();
/*      */     try {
/* 1693 */       assertOpen();
/* 1694 */       addObjectToPool(obj, false);
/*      */     } catch (IllegalStateException ex) {
/*      */       try {
/* 1697 */         this._factory.destroyObject(obj);
/*      */       }
/*      */       catch (Exception ex2) {
/*      */       }
/* 1701 */       throw ex;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected synchronized void startEvictor(long delay)
/*      */   {
/* 1715 */     if (null != this._evictor) {
/* 1716 */       EvictionTimer.cancel(this._evictor);
/* 1717 */       this._evictor = null;
/*      */     }
/* 1719 */     if (delay > 0L) {
/* 1720 */       this._evictor = new Evictor(null);
/* 1721 */       EvictionTimer.schedule(this._evictor, delay, delay);
/*      */     }
/*      */   }
/*      */ 
/*      */   synchronized String debugInfo()
/*      */   {
/* 1732 */     StringBuffer buf = new StringBuffer();
/* 1733 */     buf.append("Active: ").append(getNumActive()).append("\n");
/* 1734 */     buf.append("Idle: ").append(getNumIdle()).append("\n");
/* 1735 */     buf.append("Idle Objects:\n");
/* 1736 */     Iterator it = this._pool.iterator();
/* 1737 */     long time = System.currentTimeMillis();
/* 1738 */     while (it.hasNext()) {
/* 1739 */       GenericKeyedObjectPool.ObjectTimestampPair pair = (GenericKeyedObjectPool.ObjectTimestampPair)it.next();
/* 1740 */       buf.append("\t").append(pair.value).append("\t").append(time - pair.tstamp).append("\n");
/*      */     }
/* 1742 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   private int getNumTests()
/*      */   {
/* 1754 */     if (this._numTestsPerEvictionRun >= 0) {
/* 1755 */       return Math.min(this._numTestsPerEvictionRun, this._pool.size());
/*      */     }
/* 1757 */     return (int)Math.ceil(this._pool.size() / Math.abs(this._numTestsPerEvictionRun));
/*      */   }
/*      */ 
/*      */   private static final class Latch<T>
/*      */   {
/*      */     private GenericKeyedObjectPool.ObjectTimestampPair<T> _pair;
/* 1866 */     private boolean _mayCreate = false;
/*      */ 
/*      */     private synchronized GenericKeyedObjectPool.ObjectTimestampPair<T> getPair()
/*      */     {
/* 1873 */       return this._pair;
/*      */     }
/*      */ 
/*      */     private synchronized void setPair(GenericKeyedObjectPool.ObjectTimestampPair<T> pair)
/*      */     {
/* 1881 */       this._pair = pair;
/*      */     }
/*      */ 
/*      */     private synchronized boolean mayCreate()
/*      */     {
/* 1889 */       return this._mayCreate;
/*      */     }
/*      */ 
/*      */     private synchronized void setMayCreate(boolean mayCreate)
/*      */     {
/* 1897 */       this._mayCreate = mayCreate;
/*      */     }
/*      */ 
/*      */     private synchronized void reset()
/*      */     {
/* 1905 */       this._pair = null;
/* 1906 */       this._mayCreate = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Config
/*      */   {
/* 1803 */     public int maxIdle = 8;
/*      */ 
/* 1807 */     public int minIdle = 0;
/*      */ 
/* 1811 */     public int maxActive = 8;
/*      */ 
/* 1815 */     public long maxWait = -1L;
/*      */ 
/* 1819 */     public byte whenExhaustedAction = 1;
/*      */ 
/* 1823 */     public boolean testOnBorrow = false;
/*      */ 
/* 1827 */     public boolean testOnReturn = false;
/*      */ 
/* 1831 */     public boolean testWhileIdle = false;
/*      */ 
/* 1835 */     public long timeBetweenEvictionRunsMillis = -1L;
/*      */ 
/* 1839 */     public int numTestsPerEvictionRun = 3;
/*      */ 
/* 1843 */     public long minEvictableIdleTimeMillis = 1800000L;
/*      */ 
/* 1847 */     public long softMinEvictableIdleTimeMillis = -1L;
/*      */ 
/* 1851 */     public boolean lifo = true;
/*      */   }
/*      */ 
/*      */   private class Evictor extends TimerTask
/*      */   {
/*      */     private Evictor()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       try
/*      */       {
/* 1775 */         GenericObjectPool.this.evict();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */       catch (OutOfMemoryError oome) {
/* 1781 */         oome.printStackTrace(System.err);
/*      */       }
/*      */       try {
/* 1784 */         GenericObjectPool.this.ensureMinIdle();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.pool.impl.GenericObjectPool
 * JD-Core Version:    0.6.2
 */