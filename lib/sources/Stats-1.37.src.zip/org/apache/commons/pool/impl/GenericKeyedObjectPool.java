/*      */ package org.apache.commons.pool.impl;
/*      */ 
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.NoSuchElementException;
/*      */ import java.util.Set;
/*      */ import java.util.TimerTask;
/*      */ import java.util.TreeMap;
/*      */ import org.apache.commons.pool.BaseKeyedObjectPool;
/*      */ import org.apache.commons.pool.KeyedObjectPool;
/*      */ import org.apache.commons.pool.KeyedPoolableObjectFactory;
/*      */ import org.apache.commons.pool.PoolUtils;
/*      */ 
/*      */ public class GenericKeyedObjectPool<K, V> extends BaseKeyedObjectPool<K, V>
/*      */   implements KeyedObjectPool<K, V>
/*      */ {
/*      */   public static final byte WHEN_EXHAUSTED_FAIL = 0;
/*      */   public static final byte WHEN_EXHAUSTED_BLOCK = 1;
/*      */   public static final byte WHEN_EXHAUSTED_GROW = 2;
/*      */   public static final int DEFAULT_MAX_IDLE = 8;
/*      */   public static final int DEFAULT_MAX_ACTIVE = 8;
/*      */   public static final int DEFAULT_MAX_TOTAL = -1;
/*      */   public static final byte DEFAULT_WHEN_EXHAUSTED_ACTION = 1;
/*      */   public static final long DEFAULT_MAX_WAIT = -1L;
/*      */   public static final boolean DEFAULT_TEST_ON_BORROW = false;
/*      */   public static final boolean DEFAULT_TEST_ON_RETURN = false;
/*      */   public static final boolean DEFAULT_TEST_WHILE_IDLE = false;
/*      */   public static final long DEFAULT_TIME_BETWEEN_EVICTION_RUNS_MILLIS = -1L;
/*      */   public static final int DEFAULT_NUM_TESTS_PER_EVICTION_RUN = 3;
/*      */   public static final long DEFAULT_MIN_EVICTABLE_IDLE_TIME_MILLIS = 1800000L;
/*      */   public static final int DEFAULT_MIN_IDLE = 0;
/*      */   public static final boolean DEFAULT_LIFO = true;
/* 2571 */   private int _maxIdle = 8;
/*      */ 
/* 2578 */   private volatile int _minIdle = 0;
/*      */ 
/* 2585 */   private int _maxActive = 8;
/*      */ 
/* 2592 */   private int _maxTotal = -1;
/*      */ 
/* 2610 */   private long _maxWait = -1L;
/*      */ 
/* 2624 */   private byte _whenExhaustedAction = 1;
/*      */ 
/* 2637 */   private volatile boolean _testOnBorrow = false;
/*      */ 
/* 2648 */   private volatile boolean _testOnReturn = false;
/*      */ 
/* 2661 */   private boolean _testWhileIdle = false;
/*      */ 
/* 2672 */   private long _timeBetweenEvictionRunsMillis = -1L;
/*      */ 
/* 2687 */   private int _numTestsPerEvictionRun = 3;
/*      */ 
/* 2701 */   private long _minEvictableIdleTimeMillis = 1800000L;
/*      */ 
/* 2704 */   private Map<K, GenericKeyedObjectPool<K, V>.ObjectQueue> _poolMap = null;
/*      */ 
/* 2707 */   private int _totalActive = 0;
/*      */ 
/* 2710 */   private int _totalIdle = 0;
/*      */ 
/* 2717 */   private int _totalInternalProcessing = 0;
/*      */ 
/* 2720 */   private KeyedPoolableObjectFactory<K, V> _factory = null;
/*      */ 
/* 2725 */   private GenericKeyedObjectPool<K, V>.Evictor _evictor = null;
/*      */ 
/* 2731 */   private CursorableLinkedList<K> _poolList = null;
/*      */ 
/* 2734 */   private CursorableLinkedList<ObjectTimestampPair<V>>.Cursor _evictionCursor = null;
/*      */ 
/* 2737 */   private CursorableLinkedList<K>.Cursor _evictionKeyCursor = null;
/*      */ 
/* 2740 */   private boolean _lifo = true;
/*      */ 
/* 2747 */   private LinkedList<GenericKeyedObjectPool<K, V>.Latch<K, V>> _allocationQueue = new LinkedList();
/*      */ 
/*      */   public GenericKeyedObjectPool()
/*      */   {
/*  364 */     this(null, 8, (byte)1, -1L, 8, false, false, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericKeyedObjectPool(KeyedPoolableObjectFactory<K, V> factory)
/*      */   {
/*  375 */     this(factory, 8, (byte)1, -1L, 8, false, false, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericKeyedObjectPool(KeyedPoolableObjectFactory<K, V> factory, Config config)
/*      */   {
/*  387 */     this(factory, config.maxActive, config.whenExhaustedAction, config.maxWait, config.maxIdle, config.maxTotal, config.minIdle, config.testOnBorrow, config.testOnReturn, config.timeBetweenEvictionRunsMillis, config.numTestsPerEvictionRun, config.minEvictableIdleTimeMillis, config.testWhileIdle, config.lifo);
/*      */   }
/*      */ 
/*      */   public GenericKeyedObjectPool(KeyedPoolableObjectFactory<K, V> factory, int maxActive)
/*      */   {
/*  399 */     this(factory, maxActive, (byte)1, -1L, 8, false, false, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericKeyedObjectPool(KeyedPoolableObjectFactory<K, V> factory, int maxActive, byte whenExhaustedAction, long maxWait)
/*      */   {
/*  415 */     this(factory, maxActive, whenExhaustedAction, maxWait, 8, false, false, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericKeyedObjectPool(KeyedPoolableObjectFactory<K, V> factory, int maxActive, byte whenExhaustedAction, long maxWait, boolean testOnBorrow, boolean testOnReturn)
/*      */   {
/*  435 */     this(factory, maxActive, whenExhaustedAction, maxWait, 8, testOnBorrow, testOnReturn, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericKeyedObjectPool(KeyedPoolableObjectFactory<K, V> factory, int maxActive, byte whenExhaustedAction, long maxWait, int maxIdle)
/*      */   {
/*  453 */     this(factory, maxActive, whenExhaustedAction, maxWait, maxIdle, false, false, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericKeyedObjectPool(KeyedPoolableObjectFactory<K, V> factory, int maxActive, byte whenExhaustedAction, long maxWait, int maxIdle, boolean testOnBorrow, boolean testOnReturn)
/*      */   {
/*  475 */     this(factory, maxActive, whenExhaustedAction, maxWait, maxIdle, testOnBorrow, testOnReturn, -1L, 3, 1800000L, false);
/*      */   }
/*      */ 
/*      */   public GenericKeyedObjectPool(KeyedPoolableObjectFactory<K, V> factory, int maxActive, byte whenExhaustedAction, long maxWait, int maxIdle, boolean testOnBorrow, boolean testOnReturn, long timeBetweenEvictionRunsMillis, int numTestsPerEvictionRun, long minEvictableIdleTimeMillis, boolean testWhileIdle)
/*      */   {
/*  507 */     this(factory, maxActive, whenExhaustedAction, maxWait, maxIdle, -1, testOnBorrow, testOnReturn, timeBetweenEvictionRunsMillis, numTestsPerEvictionRun, minEvictableIdleTimeMillis, testWhileIdle);
/*      */   }
/*      */ 
/*      */   public GenericKeyedObjectPool(KeyedPoolableObjectFactory<K, V> factory, int maxActive, byte whenExhaustedAction, long maxWait, int maxIdle, int maxTotal, boolean testOnBorrow, boolean testOnReturn, long timeBetweenEvictionRunsMillis, int numTestsPerEvictionRun, long minEvictableIdleTimeMillis, boolean testWhileIdle)
/*      */   {
/*  540 */     this(factory, maxActive, whenExhaustedAction, maxWait, maxIdle, maxTotal, 0, testOnBorrow, testOnReturn, timeBetweenEvictionRunsMillis, numTestsPerEvictionRun, minEvictableIdleTimeMillis, testWhileIdle);
/*      */   }
/*      */ 
/*      */   public GenericKeyedObjectPool(KeyedPoolableObjectFactory<K, V> factory, int maxActive, byte whenExhaustedAction, long maxWait, int maxIdle, int maxTotal, int minIdle, boolean testOnBorrow, boolean testOnReturn, long timeBetweenEvictionRunsMillis, int numTestsPerEvictionRun, long minEvictableIdleTimeMillis, boolean testWhileIdle)
/*      */   {
/*  575 */     this(factory, maxActive, whenExhaustedAction, maxWait, maxIdle, maxTotal, minIdle, testOnBorrow, testOnReturn, timeBetweenEvictionRunsMillis, numTestsPerEvictionRun, minEvictableIdleTimeMillis, testWhileIdle, true);
/*      */   }
/*      */ 
/*      */   public GenericKeyedObjectPool(KeyedPoolableObjectFactory<K, V> factory, int maxActive, byte whenExhaustedAction, long maxWait, int maxIdle, int maxTotal, int minIdle, boolean testOnBorrow, boolean testOnReturn, long timeBetweenEvictionRunsMillis, int numTestsPerEvictionRun, long minEvictableIdleTimeMillis, boolean testWhileIdle, boolean lifo)
/*      */   {
/*  611 */     this._factory = factory;
/*  612 */     this._maxActive = maxActive;
/*  613 */     this._lifo = lifo;
/*  614 */     switch (whenExhaustedAction) {
/*      */     case 0:
/*      */     case 1:
/*      */     case 2:
/*  618 */       this._whenExhaustedAction = whenExhaustedAction;
/*  619 */       break;
/*      */     default:
/*  621 */       throw new IllegalArgumentException("whenExhaustedAction " + whenExhaustedAction + " not recognized.");
/*      */     }
/*  623 */     this._maxWait = maxWait;
/*  624 */     this._maxIdle = maxIdle;
/*  625 */     this._maxTotal = maxTotal;
/*  626 */     this._minIdle = minIdle;
/*  627 */     this._testOnBorrow = testOnBorrow;
/*  628 */     this._testOnReturn = testOnReturn;
/*  629 */     this._timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis;
/*  630 */     this._numTestsPerEvictionRun = numTestsPerEvictionRun;
/*  631 */     this._minEvictableIdleTimeMillis = minEvictableIdleTimeMillis;
/*  632 */     this._testWhileIdle = testWhileIdle;
/*      */ 
/*  634 */     this._poolMap = new HashMap();
/*  635 */     this._poolList = new CursorableLinkedList();
/*      */ 
/*  637 */     startEvictor(this._timeBetweenEvictionRunsMillis);
/*      */   }
/*      */ 
/*      */   public synchronized int getMaxActive()
/*      */   {
/*  653 */     return this._maxActive;
/*      */   }
/*      */ 
/*      */   public void setMaxActive(int maxActive)
/*      */   {
/*  664 */     synchronized (this) {
/*  665 */       this._maxActive = maxActive;
/*      */     }
/*  667 */     allocate();
/*      */   }
/*      */ 
/*      */   public synchronized int getMaxTotal()
/*      */   {
/*  677 */     return this._maxTotal;
/*      */   }
/*      */ 
/*      */   public void setMaxTotal(int maxTotal)
/*      */   {
/*  693 */     synchronized (this) {
/*  694 */       this._maxTotal = maxTotal;
/*      */     }
/*  696 */     allocate();
/*      */   }
/*      */ 
/*      */   public synchronized byte getWhenExhaustedAction()
/*      */   {
/*  709 */     return this._whenExhaustedAction;
/*      */   }
/*      */ 
/*      */   public void setWhenExhaustedAction(byte whenExhaustedAction)
/*      */   {
/*  723 */     synchronized (this) {
/*  724 */       switch (whenExhaustedAction) {
/*      */       case 0:
/*      */       case 1:
/*      */       case 2:
/*  728 */         this._whenExhaustedAction = whenExhaustedAction;
/*  729 */         break;
/*      */       default:
/*  731 */         throw new IllegalArgumentException("whenExhaustedAction " + whenExhaustedAction + " not recognized.");
/*      */       }
/*      */     }
/*  734 */     allocate();
/*      */   }
/*      */ 
/*      */   public synchronized long getMaxWait()
/*      */   {
/*  754 */     return this._maxWait;
/*      */   }
/*      */ 
/*      */   public void setMaxWait(long maxWait)
/*      */   {
/*  773 */     synchronized (this) {
/*  774 */       this._maxWait = maxWait;
/*      */     }
/*  776 */     allocate();
/*      */   }
/*      */ 
/*      */   public synchronized int getMaxIdle()
/*      */   {
/*  786 */     return this._maxIdle;
/*      */   }
/*      */ 
/*      */   public void setMaxIdle(int maxIdle)
/*      */   {
/*  804 */     synchronized (this) {
/*  805 */       this._maxIdle = maxIdle;
/*      */     }
/*  807 */     allocate();
/*      */   }
/*      */ 
/*      */   public void setMinIdle(int poolSize)
/*      */   {
/*  822 */     this._minIdle = poolSize;
/*      */   }
/*      */ 
/*      */   public int getMinIdle()
/*      */   {
/*  836 */     return this._minIdle;
/*      */   }
/*      */ 
/*      */   public boolean getTestOnBorrow()
/*      */   {
/*  851 */     return this._testOnBorrow;
/*      */   }
/*      */ 
/*      */   public void setTestOnBorrow(boolean testOnBorrow)
/*      */   {
/*  866 */     this._testOnBorrow = testOnBorrow;
/*      */   }
/*      */ 
/*      */   public boolean getTestOnReturn()
/*      */   {
/*  879 */     return this._testOnReturn;
/*      */   }
/*      */ 
/*      */   public void setTestOnReturn(boolean testOnReturn)
/*      */   {
/*  892 */     this._testOnReturn = testOnReturn;
/*      */   }
/*      */ 
/*      */   public synchronized long getTimeBetweenEvictionRunsMillis()
/*      */   {
/*  905 */     return this._timeBetweenEvictionRunsMillis;
/*      */   }
/*      */ 
/*      */   public synchronized void setTimeBetweenEvictionRunsMillis(long timeBetweenEvictionRunsMillis)
/*      */   {
/*  918 */     this._timeBetweenEvictionRunsMillis = timeBetweenEvictionRunsMillis;
/*  919 */     startEvictor(this._timeBetweenEvictionRunsMillis);
/*      */   }
/*      */ 
/*      */   public synchronized int getNumTestsPerEvictionRun()
/*      */   {
/*  931 */     return this._numTestsPerEvictionRun;
/*      */   }
/*      */ 
/*      */   public synchronized void setNumTestsPerEvictionRun(int numTestsPerEvictionRun)
/*      */   {
/*  950 */     this._numTestsPerEvictionRun = numTestsPerEvictionRun;
/*      */   }
/*      */ 
/*      */   public synchronized long getMinEvictableIdleTimeMillis()
/*      */   {
/*  963 */     return this._minEvictableIdleTimeMillis;
/*      */   }
/*      */ 
/*      */   public synchronized void setMinEvictableIdleTimeMillis(long minEvictableIdleTimeMillis)
/*      */   {
/*  979 */     this._minEvictableIdleTimeMillis = minEvictableIdleTimeMillis;
/*      */   }
/*      */ 
/*      */   public synchronized boolean getTestWhileIdle()
/*      */   {
/*  993 */     return this._testWhileIdle;
/*      */   }
/*      */ 
/*      */   public synchronized void setTestWhileIdle(boolean testWhileIdle)
/*      */   {
/* 1007 */     this._testWhileIdle = testWhileIdle;
/*      */   }
/*      */ 
/*      */   public synchronized void setConfig(Config conf)
/*      */   {
/* 1016 */     setMaxIdle(conf.maxIdle);
/* 1017 */     setMaxActive(conf.maxActive);
/* 1018 */     setMaxTotal(conf.maxTotal);
/* 1019 */     setMinIdle(conf.minIdle);
/* 1020 */     setMaxWait(conf.maxWait);
/* 1021 */     setWhenExhaustedAction(conf.whenExhaustedAction);
/* 1022 */     setTestOnBorrow(conf.testOnBorrow);
/* 1023 */     setTestOnReturn(conf.testOnReturn);
/* 1024 */     setTestWhileIdle(conf.testWhileIdle);
/* 1025 */     setNumTestsPerEvictionRun(conf.numTestsPerEvictionRun);
/* 1026 */     setMinEvictableIdleTimeMillis(conf.minEvictableIdleTimeMillis);
/* 1027 */     setTimeBetweenEvictionRunsMillis(conf.timeBetweenEvictionRunsMillis);
/*      */   }
/*      */ 
/*      */   public synchronized boolean getLifo()
/*      */   {
/* 1041 */     return this._lifo;
/*      */   }
/*      */ 
/*      */   public synchronized void setLifo(boolean lifo)
/*      */   {
/* 1055 */     this._lifo = lifo;
/*      */   }
/*      */ 
/*      */   public V borrowObject(K key)
/*      */     throws Exception
/*      */   {
/* 1093 */     long starttime = System.currentTimeMillis();
/* 1094 */     Latch latch = new Latch(key, null);
/*      */     byte whenExhaustedAction;
/*      */     long maxWait;
/* 1097 */     synchronized (this)
/*      */     {
/* 1101 */       whenExhaustedAction = this._whenExhaustedAction;
/* 1102 */       maxWait = this._maxWait;
/*      */ 
/* 1105 */       this._allocationQueue.add(latch);
/*      */     }
/*      */ 
/* 1109 */     allocate();
/*      */     while (true)
/*      */     {
/* 1112 */       synchronized (this) {
/* 1113 */         assertOpen();
/*      */       }
/*      */ 
/* 1116 */       if (null == latch.getPair())
/*      */       {
/* 1118 */         if (!latch.mayCreate())
/*      */         {
/* 1122 */           switch (whenExhaustedAction)
/*      */           {
/*      */           case 2:
/* 1125 */             synchronized (this)
/*      */             {
/* 1128 */               if ((latch.getPair() == null) && (!latch.mayCreate())) {
/* 1129 */                 this._allocationQueue.remove(latch);
/* 1130 */                 latch.getPool().incrementInternalProcessingCount();
/*      */               }
/*      */             }
/* 1133 */             break;
/*      */           case 0:
/* 1135 */             synchronized (this)
/*      */             {
/* 1138 */               if ((latch.getPair() == null) && (latch.mayCreate())) {
/*      */                 break label607;
/*      */               }
/* 1141 */               this._allocationQueue.remove(latch);
/*      */             }
/* 1143 */             throw new NoSuchElementException("Pool exhausted");
/*      */           case 1:
/*      */             try {
/* 1146 */               synchronized (latch)
/*      */               {
/* 1149 */                 if ((latch.getPair() == null) && (!latch.mayCreate())) {
/* 1150 */                   if (maxWait <= 0L) {
/* 1151 */                     latch.wait();
/*      */                   }
/*      */                   else
/*      */                   {
/* 1155 */                     long elapsed = System.currentTimeMillis() - starttime;
/* 1156 */                     long waitTime = maxWait - elapsed;
/* 1157 */                     if (waitTime > 0L)
/*      */                     {
/* 1159 */                       latch.wait(waitTime);
/*      */                     }
/*      */                   }
/*      */                 }
/* 1163 */                 else break label607;
/*      */ 
/*      */               }
/*      */ 
/* 1167 */               if (isClosed() == true)
/* 1168 */                 throw new IllegalStateException("Pool closed");
/*      */             }
/*      */             catch (InterruptedException e) {
/* 1171 */               boolean doAllocate = false;
/* 1172 */               synchronized (this)
/*      */               {
/* 1174 */                 if ((latch.getPair() == null) && (!latch.mayCreate()))
/*      */                 {
/* 1177 */                   this._allocationQueue.remove(latch);
/* 1178 */                 } else if ((latch.getPair() == null) && (latch.mayCreate()))
/*      */                 {
/* 1181 */                   latch.getPool().decrementInternalProcessingCount();
/* 1182 */                   doAllocate = true;
/*      */                 }
/*      */                 else {
/* 1185 */                   latch.getPool().decrementInternalProcessingCount();
/* 1186 */                   latch.getPool().incrementActiveCount();
/* 1187 */                   returnObject(latch.getkey(), latch.getPair().getValue());
/*      */                 }
/*      */               }
/* 1190 */               if (doAllocate) {
/* 1191 */                 allocate();
/*      */               }
/* 1193 */               Thread.currentThread().interrupt();
/* 1194 */               throw e;
/*      */             }
/* 1196 */             if ((maxWait <= 0L) || (System.currentTimeMillis() - starttime < maxWait)) continue;
/* 1197 */             synchronized (this)
/*      */             {
/* 1200 */               if ((latch.getPair() == null) && (!latch.mayCreate()))
/* 1201 */                 this._allocationQueue.remove(latch);
/*      */               else {
/* 1203 */                 break label607;
/*      */               }
/*      */             }
/* 1206 */             throw new NoSuchElementException("Timeout waiting for idle object");
/*      */           default:
/* 1211 */             throw new IllegalArgumentException("whenExhaustedAction " + whenExhaustedAction + " not recognized.");
/*      */           }
/*      */         }
/*      */       }
/*      */       else
/*      */       {
/* 1217 */         label607: boolean newlyCreated = false;
/* 1218 */         if (null == latch.getPair()) {
/*      */           try {
/* 1220 */             Object obj = this._factory.makeObject(key);
/* 1221 */             latch.setPair(new ObjectTimestampPair(obj));
/* 1222 */             newlyCreated = true;
/*      */           } finally {
/* 1224 */             if (!newlyCreated)
/*      */             {
/* 1226 */               synchronized (this) {
/* 1227 */                 latch.getPool().decrementInternalProcessingCount();
/*      */               }
/*      */ 
/* 1230 */               allocate();
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/*      */         try
/*      */         {
/* 1237 */           this._factory.activateObject(key, latch.getPair().value);
/* 1238 */           if ((this._testOnBorrow) && (!this._factory.validateObject(key, latch.getPair().value))) {
/* 1239 */             throw new Exception("ValidateObject failed");
/*      */           }
/* 1241 */           synchronized (this) {
/* 1242 */             latch.getPool().decrementInternalProcessingCount();
/* 1243 */             latch.getPool().incrementActiveCount();
/*      */           }
/* 1245 */           return latch.getPair().value;
/*      */         } catch (Throwable e) {
/* 1247 */           PoolUtils.checkRethrow(e);
/*      */           try
/*      */           {
/* 1250 */             this._factory.destroyObject(key, latch.getPair().value);
/*      */           } catch (Throwable e2) {
/* 1252 */             PoolUtils.checkRethrow(e2);
/*      */           }
/*      */ 
/* 1255 */           synchronized (this) {
/* 1256 */             latch.getPool().decrementInternalProcessingCount();
/* 1257 */             if (!newlyCreated) {
/* 1258 */               latch.reset();
/* 1259 */               this._allocationQueue.add(0, latch);
/*      */             }
/*      */           }
/* 1262 */           allocate();
/* 1263 */           if (newlyCreated)
/* 1264 */             throw new NoSuchElementException("Could not create a validated object, cause: " + e.getMessage());
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void allocate()
/*      */   {
/* 1282 */     boolean clearOldest = false;
/*      */ 
/* 1284 */     synchronized (this) {
/* 1285 */       if (isClosed()) return;
/*      */ 
/* 1287 */       Iterator allocationQueueIter = this._allocationQueue.iterator();
/*      */ 
/* 1289 */       while (allocationQueueIter.hasNext())
/*      */       {
/* 1291 */         Latch latch = (Latch)allocationQueueIter.next();
/* 1292 */         ObjectQueue pool = (ObjectQueue)this._poolMap.get(latch.getkey());
/* 1293 */         if (null == pool) {
/* 1294 */           pool = new ObjectQueue(null);
/* 1295 */           this._poolMap.put(latch.getkey(), pool);
/* 1296 */           this._poolList.add(latch.getkey());
/*      */         }
/* 1298 */         latch.setPool(pool);
/* 1299 */         if (!pool.queue.isEmpty()) {
/* 1300 */           allocationQueueIter.remove();
/* 1301 */           latch.setPair((ObjectTimestampPair)pool.queue.removeFirst());
/*      */ 
/* 1303 */           pool.incrementInternalProcessingCount();
/* 1304 */           this._totalIdle -= 1;
/* 1305 */           synchronized (latch) {
/* 1306 */             latch.notify();
/*      */           }
/*      */ 
/*      */         }
/* 1314 */         else if ((this._maxTotal > 0) && (this._totalActive + this._totalIdle + this._totalInternalProcessing >= this._maxTotal))
/*      */         {
/* 1316 */           clearOldest = true;
/*      */         }
/*      */         else
/*      */         {
/* 1321 */           if (((this._maxActive < 0) || (pool.activeCount + pool.internalProcessingCount < this._maxActive)) && ((this._maxTotal < 0) || (this._totalActive + this._totalIdle + this._totalInternalProcessing < this._maxTotal)))
/*      */           {
/* 1324 */             allocationQueueIter.remove();
/* 1325 */             latch.setMayCreate(true);
/* 1326 */             pool.incrementInternalProcessingCount();
/* 1327 */             synchronized (latch) {
/* 1328 */               latch.notify();
/*      */             }
/*      */ 
/* 1331 */             continue;
/*      */           }
/*      */ 
/* 1337 */           if (this._maxActive < 0) {
/*      */             break;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 1343 */     if (clearOldest)
/*      */     {
/* 1352 */       clearOldest();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void clear()
/*      */   {
/* 1373 */     Map toDestroy = new HashMap();
/*      */     Iterator it;
/* 1374 */     synchronized (this) {
/* 1375 */       for (it = this._poolMap.keySet().iterator(); it.hasNext(); ) {
/* 1376 */         Object key = it.next();
/* 1377 */         ObjectQueue pool = (ObjectQueue)this._poolMap.get(key);
/*      */ 
/* 1380 */         List objects = new ArrayList();
/* 1381 */         objects.addAll(pool.queue);
/* 1382 */         toDestroy.put(key, objects);
/* 1383 */         it.remove();
/* 1384 */         this._poolList.remove(key);
/* 1385 */         this._totalIdle -= pool.queue.size();
/* 1386 */         this._totalInternalProcessing += pool.queue.size();
/*      */ 
/* 1388 */         pool.queue.clear();
/*      */       }
/*      */     }
/* 1391 */     destroy(toDestroy, this._factory);
/*      */   }
/*      */ 
/*      */   public void clearOldest()
/*      */   {
/* 1402 */     Map toDestroy = new HashMap();
/*      */ 
/* 1405 */     Map map = new TreeMap();
/* 1406 */     synchronized (this) {
/* 1407 */       for (Iterator keyiter = this._poolMap.keySet().iterator(); keyiter.hasNext(); ) {
/* 1408 */         key = keyiter.next();
/* 1409 */         List list = ((ObjectQueue)this._poolMap.get(key)).queue;
/* 1410 */         for (it = list.iterator(); it.hasNext(); )
/*      */         {
/* 1414 */           map.put(it.next(), key);
/*      */         }
/*      */       }
/*      */       Object key;
/*      */       Iterator it;
/* 1419 */       Set setPairKeys = map.entrySet();
/* 1420 */       int itemsToRemove = (int)(map.size() * 0.15D) + 1;
/*      */ 
/* 1422 */       Iterator iter = setPairKeys.iterator();
/* 1423 */       while ((iter.hasNext()) && (itemsToRemove > 0)) {
/* 1424 */         Map.Entry entry = (Map.Entry)iter.next();
/*      */ 
/* 1428 */         Object key = entry.getValue();
/* 1429 */         ObjectTimestampPair pairTimeStamp = (ObjectTimestampPair)entry.getKey();
/* 1430 */         ObjectQueue objectQueue = (ObjectQueue)this._poolMap.get(key);
/* 1431 */         List list = objectQueue.queue;
/* 1432 */         list.remove(pairTimeStamp);
/*      */ 
/* 1434 */         if (toDestroy.containsKey(key)) {
/* 1435 */           ((List)toDestroy.get(key)).add(pairTimeStamp);
/*      */         } else {
/* 1437 */           List listForKey = new ArrayList();
/* 1438 */           listForKey.add(pairTimeStamp);
/* 1439 */           toDestroy.put(key, listForKey);
/*      */         }
/* 1441 */         objectQueue.incrementInternalProcessingCount();
/* 1442 */         this._totalIdle -= 1;
/* 1443 */         itemsToRemove--;
/*      */       }
/*      */     }
/*      */ 
/* 1447 */     destroy(toDestroy, this._factory);
/*      */   }
/*      */ 
/*      */   public void clear(K key)
/*      */   {
/* 1457 */     Map toDestroy = new HashMap();
/*      */ 
/* 1460 */     synchronized (this) {
/* 1461 */       ObjectQueue pool = (ObjectQueue)this._poolMap.remove(key);
/* 1462 */       if (pool == null) {
/* 1463 */         return;
/*      */       }
/* 1465 */       this._poolList.remove(key);
/*      */ 
/* 1469 */       List objects = new ArrayList();
/* 1470 */       objects.addAll(pool.queue);
/* 1471 */       toDestroy.put(key, objects);
/* 1472 */       this._totalIdle -= pool.queue.size();
/* 1473 */       this._totalInternalProcessing += pool.queue.size();
/*      */ 
/* 1475 */       pool.queue.clear();
/*      */     }
/* 1477 */     destroy(toDestroy, this._factory);
/*      */   }
/*      */ 
/*      */   private void destroy(Map<K, List<ObjectTimestampPair<V>>> m, KeyedPoolableObjectFactory<K, V> factory)
/*      */   {
/* 1488 */     for (Iterator entries = m.entrySet().iterator(); entries.hasNext(); ) {
/* 1489 */       Map.Entry entry = (Map.Entry)entries.next();
/* 1490 */       key = entry.getKey();
/* 1491 */       List c = (List)entry.getValue();
/* 1492 */       for (it = c.iterator(); it.hasNext(); )
/*      */         try {
/* 1494 */           factory.destroyObject(key, ((ObjectTimestampPair)it.next()).value);
/*      */         }
/*      */         catch (Exception e) {
/*      */         }
/*      */         finally {
/* 1499 */           synchronized (this) {
/* 1500 */             ObjectQueue objectQueue = (ObjectQueue)this._poolMap.get(key);
/*      */ 
/* 1502 */             if (objectQueue != null) {
/* 1503 */               objectQueue.decrementInternalProcessingCount();
/* 1504 */               if ((objectQueue.internalProcessingCount == 0) && (objectQueue.activeCount == 0) && (objectQueue.queue.isEmpty()))
/*      */               {
/* 1507 */                 this._poolMap.remove(key);
/* 1508 */                 this._poolList.remove(key);
/*      */               }
/*      */             } else {
/* 1511 */               this._totalInternalProcessing -= 1;
/*      */             }
/*      */           }
/* 1514 */           allocate();
/*      */         }
/*      */     }
/*      */     Object key;
/*      */     Iterator it;
/*      */   }
/*      */ 
/*      */   public synchronized int getNumActive()
/*      */   {
/* 1528 */     return this._totalActive;
/*      */   }
/*      */ 
/*      */   public synchronized int getNumIdle()
/*      */   {
/* 1538 */     return this._totalIdle;
/*      */   }
/*      */ 
/*      */   public synchronized int getNumActive(Object key)
/*      */   {
/* 1550 */     ObjectQueue pool = (ObjectQueue)this._poolMap.get(key);
/* 1551 */     return pool != null ? pool.activeCount : 0;
/*      */   }
/*      */ 
/*      */   public synchronized int getNumIdle(Object key)
/*      */   {
/* 1562 */     ObjectQueue pool = (ObjectQueue)this._poolMap.get(key);
/* 1563 */     return pool != null ? pool.queue.size() : 0;
/*      */   }
/*      */ 
/*      */   public void returnObject(K key, V obj)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/* 1587 */       addObjectToPool(key, obj, true);
/*      */     } catch (Exception e) {
/* 1589 */       if (this._factory != null) {
/*      */         try {
/* 1591 */           this._factory.destroyObject(key, obj);
/*      */         }
/*      */         catch (Exception e2)
/*      */         {
/*      */         }
/*      */ 
/* 1598 */         ObjectQueue pool = (ObjectQueue)this._poolMap.get(key);
/* 1599 */         if (pool != null) {
/* 1600 */           synchronized (this) {
/* 1601 */             pool.decrementActiveCount();
/* 1602 */             if ((pool.queue.isEmpty()) && (pool.activeCount == 0) && (pool.internalProcessingCount == 0))
/*      */             {
/* 1605 */               this._poolMap.remove(key);
/* 1606 */               this._poolList.remove(key);
/*      */             }
/*      */           }
/* 1609 */           allocate();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void addObjectToPool(K key, V obj, boolean decrementNumActive)
/*      */     throws Exception
/*      */   {
/* 1633 */     boolean success = true;
/* 1634 */     if ((this._testOnReturn) && (!this._factory.validateObject(key, obj)))
/* 1635 */       success = false;
/*      */     else {
/* 1637 */       this._factory.passivateObject(key, obj);
/*      */     }
/*      */ 
/* 1640 */     boolean shouldDestroy = !success;
/*      */ 
/* 1645 */     boolean doAllocate = false;
/*      */     ObjectQueue pool;
/* 1646 */     synchronized (this)
/*      */     {
/* 1648 */       pool = (ObjectQueue)this._poolMap.get(key);
/*      */ 
/* 1650 */       if (null == pool) {
/* 1651 */         pool = new ObjectQueue(null);
/* 1652 */         this._poolMap.put(key, pool);
/* 1653 */         this._poolList.add(key);
/*      */       }
/* 1655 */       if (isClosed()) {
/* 1656 */         shouldDestroy = true;
/*      */       }
/* 1660 */       else if ((this._maxIdle >= 0) && (pool.queue.size() >= this._maxIdle)) {
/* 1661 */         shouldDestroy = true;
/* 1662 */       } else if (success)
/*      */       {
/* 1665 */         if (this._lifo)
/* 1666 */           pool.queue.addFirst(new ObjectTimestampPair(obj));
/*      */         else {
/* 1668 */           pool.queue.addLast(new ObjectTimestampPair(obj));
/*      */         }
/* 1670 */         this._totalIdle += 1;
/* 1671 */         if (decrementNumActive) {
/* 1672 */           pool.decrementActiveCount();
/*      */         }
/* 1674 */         doAllocate = true;
/*      */       }
/*      */     }
/*      */ 
/* 1678 */     if (doAllocate) {
/* 1679 */       allocate();
/*      */     }
/*      */ 
/* 1683 */     if (shouldDestroy) {
/*      */       try {
/* 1685 */         this._factory.destroyObject(key, obj);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/* 1690 */       if (decrementNumActive) {
/* 1691 */         synchronized (this) {
/* 1692 */           pool.decrementActiveCount();
/* 1693 */           if ((pool.queue.isEmpty()) && (pool.activeCount == 0) && (pool.internalProcessingCount == 0))
/*      */           {
/* 1696 */             this._poolMap.remove(key);
/* 1697 */             this._poolList.remove(key);
/*      */           }
/*      */         }
/* 1700 */         allocate();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void invalidateObject(K key, V obj)
/*      */     throws Exception
/*      */   {
/*      */     try
/*      */     {
/* 1717 */       this._factory.destroyObject(key, obj);
/*      */     } finally {
/* 1719 */       synchronized (this) {
/* 1720 */         ObjectQueue pool = (ObjectQueue)this._poolMap.get(key);
/* 1721 */         if (null == pool) {
/* 1722 */           pool = new ObjectQueue(null);
/* 1723 */           this._poolMap.put(key, pool);
/* 1724 */           this._poolList.add(key);
/*      */         }
/* 1726 */         pool.decrementActiveCount();
/*      */       }
/* 1728 */       allocate();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void addObject(K key)
/*      */     throws Exception
/*      */   {
/* 1744 */     assertOpen();
/* 1745 */     if (this._factory == null) {
/* 1746 */       throw new IllegalStateException("Cannot add objects without a factory.");
/*      */     }
/* 1748 */     Object obj = this._factory.makeObject(key);
/*      */     try {
/* 1750 */       assertOpen();
/* 1751 */       addObjectToPool(key, obj, false);
/*      */     } catch (IllegalStateException ex) {
/*      */       try {
/* 1754 */         this._factory.destroyObject(key, obj);
/*      */       }
/*      */       catch (Exception ex2) {
/*      */       }
/* 1758 */       throw ex;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void preparePool(K key, boolean populateImmediately)
/*      */   {
/* 1775 */     ObjectQueue pool = (ObjectQueue)this._poolMap.get(key);
/* 1776 */     if (null == pool) {
/* 1777 */       pool = new ObjectQueue(null);
/* 1778 */       this._poolMap.put(key, pool);
/* 1779 */       this._poolList.add(key);
/*      */     }
/*      */ 
/* 1782 */     if (populateImmediately)
/*      */       try
/*      */       {
/* 1785 */         ensureMinIdle(key);
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws Exception
/*      */   {
/* 1805 */     super.close();
/* 1806 */     synchronized (this) {
/* 1807 */       clear();
/* 1808 */       if (null != this._evictionCursor) {
/* 1809 */         this._evictionCursor.close();
/* 1810 */         this._evictionCursor = null;
/*      */       }
/* 1812 */       if (null != this._evictionKeyCursor) {
/* 1813 */         this._evictionKeyCursor.close();
/* 1814 */         this._evictionKeyCursor = null;
/*      */       }
/* 1816 */       startEvictor(-1L);
/*      */ 
/* 1818 */       while (this._allocationQueue.size() > 0) {
/* 1819 */         Latch l = (Latch)this._allocationQueue.removeFirst();
/*      */ 
/* 1821 */         synchronized (l)
/*      */         {
/* 1823 */           l.notify();
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   @Deprecated
/*      */   public void setFactory(KeyedPoolableObjectFactory<K, V> factory)
/*      */     throws IllegalStateException
/*      */   {
/* 1843 */     Map toDestroy = new HashMap();
/* 1844 */     KeyedPoolableObjectFactory oldFactory = this._factory;
/* 1845 */     synchronized (this) {
/* 1846 */       assertOpen();
/* 1847 */       if (0 < getNumActive()) {
/* 1848 */         throw new IllegalStateException("Objects are already active");
/*      */       }
/* 1850 */       for (Iterator it = this._poolMap.keySet().iterator(); it.hasNext(); ) {
/* 1851 */         Object key = it.next();
/* 1852 */         ObjectQueue pool = (ObjectQueue)this._poolMap.get(key);
/* 1853 */         if (pool != null)
/*      */         {
/* 1856 */           List objects = new ArrayList();
/* 1857 */           objects.addAll(pool.queue);
/* 1858 */           toDestroy.put(key, objects);
/* 1859 */           it.remove();
/* 1860 */           this._poolList.remove(key);
/* 1861 */           this._totalIdle -= pool.queue.size();
/* 1862 */           this._totalInternalProcessing += pool.queue.size();
/*      */ 
/* 1864 */           pool.queue.clear();
/*      */         }
/*      */       }
/* 1867 */       this._factory = factory;
/*      */     }
/*      */ 
/* 1870 */     destroy(toDestroy, oldFactory);
/*      */   }
/*      */ 
/*      */   public void evict()
/*      */     throws Exception
/*      */   {
/* 1888 */     Object key = null;
/*      */     boolean testWhileIdle;
/*      */     long minEvictableIdleTimeMillis;
/* 1892 */     synchronized (this)
/*      */     {
/* 1896 */       testWhileIdle = this._testWhileIdle;
/* 1897 */       minEvictableIdleTimeMillis = this._minEvictableIdleTimeMillis;
/*      */ 
/* 1900 */       if ((this._evictionKeyCursor != null) && (this._evictionKeyCursor._lastReturned != null))
/*      */       {
/* 1902 */         key = this._evictionKeyCursor._lastReturned.value();
/*      */       }
/*      */     }
/*      */ 
/* 1906 */     int i = 0; for (int m = getNumTests(); i < m; i++)
/*      */     {
/*      */       ObjectTimestampPair pair;
/* 1908 */       synchronized (this)
/*      */       {
/* 1910 */         if ((this._poolMap != null) && (this._poolMap.size() == 0))
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/* 1915 */         if (null == this._evictionKeyCursor) {
/* 1916 */           resetEvictionKeyCursor();
/* 1917 */           key = null;
/*      */         }
/*      */ 
/* 1921 */         if (null == this._evictionCursor)
/*      */         {
/* 1923 */           if (this._evictionKeyCursor.hasNext()) {
/* 1924 */             key = this._evictionKeyCursor.next();
/* 1925 */             resetEvictionObjectCursor(key);
/*      */           }
/*      */           else {
/* 1928 */             resetEvictionKeyCursor();
/* 1929 */             if ((this._evictionKeyCursor != null) && 
/* 1930 */               (this._evictionKeyCursor.hasNext())) {
/* 1931 */               key = this._evictionKeyCursor.next();
/* 1932 */               resetEvictionObjectCursor(key);
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1938 */         if (this._evictionCursor == null)
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/* 1944 */         if (((this._lifo) && (!this._evictionCursor.hasPrevious())) || ((!this._lifo) && (!this._evictionCursor.hasNext())))
/*      */         {
/* 1946 */           if (this._evictionKeyCursor != null) {
/* 1947 */             if (this._evictionKeyCursor.hasNext()) {
/* 1948 */               key = this._evictionKeyCursor.next();
/* 1949 */               resetEvictionObjectCursor(key);
/*      */             } else {
/* 1951 */               resetEvictionKeyCursor();
/* 1952 */               if ((this._evictionKeyCursor != null) && 
/* 1953 */                 (this._evictionKeyCursor.hasNext())) {
/* 1954 */                 key = this._evictionKeyCursor.next();
/* 1955 */                 resetEvictionObjectCursor(key);
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1962 */         if (((!this._lifo) || (this._evictionCursor.hasPrevious())) && ((!this._lifo) && (!this._evictionCursor.hasNext())))
/*      */         {
/*      */           continue;
/*      */         }
/*      */ 
/* 1969 */         pair = this._lifo ? (ObjectTimestampPair)this._evictionCursor.previous() : (ObjectTimestampPair)this._evictionCursor.next();
/*      */ 
/* 1972 */         this._evictionCursor.remove();
/* 1973 */         ObjectQueue objectQueue = (ObjectQueue)this._poolMap.get(key);
/* 1974 */         objectQueue.incrementInternalProcessingCount();
/* 1975 */         this._totalIdle -= 1;
/*      */       }
/*      */ 
/* 1978 */       boolean removeObject = false;
/* 1979 */       if ((minEvictableIdleTimeMillis > 0L) && (System.currentTimeMillis() - pair.tstamp > minEvictableIdleTimeMillis))
/*      */       {
/* 1982 */         removeObject = true;
/*      */       }
/* 1984 */       if ((testWhileIdle) && (!removeObject)) {
/* 1985 */         boolean active = false;
/*      */         try {
/* 1987 */           this._factory.activateObject(key, pair.value);
/* 1988 */           active = true;
/*      */         } catch (Exception e) {
/* 1990 */           removeObject = true;
/*      */         }
/* 1992 */         if (active) {
/* 1993 */           if (!this._factory.validateObject(key, pair.value))
/* 1994 */             removeObject = true;
/*      */           else {
/*      */             try {
/* 1997 */               this._factory.passivateObject(key, pair.value);
/*      */             } catch (Exception e) {
/* 1999 */               removeObject = true;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 2005 */       if (removeObject)
/*      */         try {
/* 2007 */           this._factory.destroyObject(key, pair.value);
/*      */         }
/*      */         catch (Exception e)
/*      */         {
/*      */         }
/* 2012 */       synchronized (this) {
/* 2013 */         ObjectQueue objectQueue = (ObjectQueue)this._poolMap.get(key);
/*      */ 
/* 2015 */         objectQueue.decrementInternalProcessingCount();
/* 2016 */         if (removeObject) {
/* 2017 */           if ((objectQueue.queue.isEmpty()) && (objectQueue.activeCount == 0) && (objectQueue.internalProcessingCount == 0))
/*      */           {
/* 2020 */             this._poolMap.remove(key);
/* 2021 */             this._poolList.remove(key);
/*      */           }
/*      */         } else {
/* 2024 */           this._evictionCursor.add(pair);
/* 2025 */           this._totalIdle += 1;
/* 2026 */           if (this._lifo)
/*      */           {
/* 2028 */             this._evictionCursor.previous();
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 2033 */     allocate();
/*      */   }
/*      */ 
/*      */   private void resetEvictionKeyCursor()
/*      */   {
/* 2041 */     if (this._evictionKeyCursor != null) {
/* 2042 */       this._evictionKeyCursor.close();
/*      */     }
/* 2044 */     this._evictionKeyCursor = this._poolList.cursor();
/* 2045 */     if (null != this._evictionCursor) {
/* 2046 */       this._evictionCursor.close();
/* 2047 */       this._evictionCursor = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void resetEvictionObjectCursor(Object key)
/*      */   {
/* 2057 */     if (this._evictionCursor != null) {
/* 2058 */       this._evictionCursor.close();
/*      */     }
/* 2060 */     if (this._poolMap == null) {
/* 2061 */       return;
/*      */     }
/* 2063 */     ObjectQueue pool = (ObjectQueue)this._poolMap.get(key);
/* 2064 */     if (pool != null) {
/* 2065 */       CursorableLinkedList queue = pool.queue;
/* 2066 */       this._evictionCursor = queue.cursor(this._lifo ? queue.size() : 0);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void ensureMinIdle()
/*      */     throws Exception
/*      */   {
/* 2080 */     if (this._minIdle > 0)
/*      */     {
/*      */       Object[] keysCopy;
/* 2082 */       synchronized (this)
/*      */       {
/* 2084 */         keysCopy = this._poolMap.keySet().toArray();
/*      */       }
/*      */ 
/* 2090 */       for (int i = 0; i < keysCopy.length; i++)
/*      */       {
/* 2092 */         ensureMinIdle(keysCopy[i]);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void ensureMinIdle(K key)
/*      */     throws Exception
/*      */   {
/*      */     ObjectQueue pool;
/* 2111 */     synchronized (this) {
/* 2112 */       pool = (ObjectQueue)this._poolMap.get(key);
/*      */     }
/* 2114 */     if (pool == null) {
/* 2115 */       return;
/*      */     }
/*      */ 
/* 2123 */     int objectDeficit = calculateDeficit(pool, false);
/*      */ 
/* 2125 */     for (int i = 0; (i < objectDeficit) && (calculateDeficit(pool, true) > 0); i++)
/*      */       try {
/* 2127 */         addObject(key);
/*      */       } finally {
/* 2129 */         synchronized (this) {
/* 2130 */           pool.decrementInternalProcessingCount();
/*      */         }
/* 2132 */         allocate();
/*      */       }
/*      */   }
/*      */ 
/*      */   protected synchronized void startEvictor(long delay)
/*      */   {
/* 2147 */     if (null != this._evictor) {
/* 2148 */       EvictionTimer.cancel(this._evictor);
/* 2149 */       this._evictor = null;
/*      */     }
/* 2151 */     if (delay > 0L) {
/* 2152 */       this._evictor = new Evictor(null);
/* 2153 */       EvictionTimer.schedule(this._evictor, delay, delay);
/*      */     }
/*      */   }
/*      */ 
/*      */   synchronized String debugInfo()
/*      */   {
/* 2164 */     StringBuffer buf = new StringBuffer();
/* 2165 */     buf.append("Active: ").append(getNumActive()).append("\n");
/* 2166 */     buf.append("Idle: ").append(getNumIdle()).append("\n");
/* 2167 */     Iterator it = this._poolMap.keySet().iterator();
/* 2168 */     while (it.hasNext()) {
/* 2169 */       Object key = it.next();
/* 2170 */       buf.append("\t").append(key).append(" ").append(this._poolMap.get(key)).append("\n");
/*      */     }
/* 2172 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   private synchronized int getNumTests()
/*      */   {
/* 2184 */     if (this._numTestsPerEvictionRun >= 0) {
/* 2185 */       return Math.min(this._numTestsPerEvictionRun, this._totalIdle);
/*      */     }
/* 2187 */     return (int)Math.ceil(this._totalIdle / Math.abs(this._numTestsPerEvictionRun));
/*      */   }
/*      */ 
/*      */   private synchronized int calculateDeficit(GenericKeyedObjectPool<K, V>.ObjectQueue pool, boolean incrementInternal)
/*      */   {
/* 2204 */     int objectDefecit = 0;
/*      */ 
/* 2208 */     objectDefecit = getMinIdle() - pool.queue.size();
/* 2209 */     if (getMaxActive() > 0) {
/* 2210 */       int growLimit = Math.max(0, getMaxActive() - pool.activeCount - pool.queue.size() - pool.internalProcessingCount);
/* 2211 */       objectDefecit = Math.min(objectDefecit, growLimit);
/*      */     }
/*      */ 
/* 2215 */     if (getMaxTotal() > 0) {
/* 2216 */       int growLimit = Math.max(0, getMaxTotal() - getNumActive() - getNumIdle() - this._totalInternalProcessing);
/* 2217 */       objectDefecit = Math.min(objectDefecit, growLimit);
/*      */     }
/*      */ 
/* 2220 */     if ((incrementInternal) && (objectDefecit > 0)) {
/* 2221 */       pool.incrementInternalProcessingCount();
/*      */     }
/* 2223 */     return objectDefecit;
/*      */   }
/*      */ 
/*      */   private final class Latch<LK, LV>
/*      */   {
/*      */     private final LK _key;
/*      */     private GenericKeyedObjectPool<K, V>.ObjectQueue _pool;
/*      */     private GenericKeyedObjectPool.ObjectTimestampPair<LV> _pair;
/* 2486 */     private boolean _mayCreate = false;
/*      */ 
/*      */     private Latch()
/*      */     {
/* 2493 */       this._key = key;
/*      */     }
/*      */ 
/*      */     private synchronized LK getkey()
/*      */     {
/* 2501 */       return this._key;
/*      */     }
/*      */ 
/*      */     private synchronized GenericKeyedObjectPool<K, V>.ObjectQueue getPool()
/*      */     {
/* 2509 */       return this._pool;
/*      */     }
/*      */ 
/*      */     private synchronized void setPool(GenericKeyedObjectPool<K, V>.ObjectQueue pool)
/*      */     {
/* 2517 */       this._pool = pool;
/*      */     }
/*      */ 
/*      */     private synchronized GenericKeyedObjectPool.ObjectTimestampPair<LV> getPair()
/*      */     {
/* 2526 */       return this._pair;
/*      */     }
/*      */ 
/*      */     private synchronized void setPair(GenericKeyedObjectPool.ObjectTimestampPair<LV> pair)
/*      */     {
/* 2534 */       this._pair = pair;
/*      */     }
/*      */ 
/*      */     private synchronized boolean mayCreate()
/*      */     {
/* 2542 */       return this._mayCreate;
/*      */     }
/*      */ 
/*      */     private synchronized void setMayCreate(boolean mayCreate)
/*      */     {
/* 2551 */       this._mayCreate = mayCreate;
/*      */     }
/*      */ 
/*      */     private synchronized void reset()
/*      */     {
/* 2559 */       this._pair = null;
/* 2560 */       this._mayCreate = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public static class Config
/*      */   {
/* 2415 */     public int maxIdle = 8;
/*      */ 
/* 2419 */     public int maxActive = 8;
/*      */ 
/* 2423 */     public int maxTotal = -1;
/*      */ 
/* 2427 */     public int minIdle = 0;
/*      */ 
/* 2431 */     public long maxWait = -1L;
/*      */ 
/* 2435 */     public byte whenExhaustedAction = 1;
/*      */ 
/* 2439 */     public boolean testOnBorrow = false;
/*      */ 
/* 2443 */     public boolean testOnReturn = false;
/*      */ 
/* 2447 */     public boolean testWhileIdle = false;
/*      */ 
/* 2451 */     public long timeBetweenEvictionRunsMillis = -1L;
/*      */ 
/* 2455 */     public int numTestsPerEvictionRun = 3;
/*      */ 
/* 2459 */     public long minEvictableIdleTimeMillis = 1800000L;
/*      */ 
/* 2463 */     public boolean lifo = true;
/*      */   }
/*      */ 
/*      */   private class Evictor extends TimerTask
/*      */   {
/*      */     private Evictor()
/*      */     {
/*      */     }
/*      */ 
/*      */     public void run()
/*      */     {
/*      */       try
/*      */       {
/* 2387 */         GenericKeyedObjectPool.this.evict();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */       catch (OutOfMemoryError oome) {
/* 2393 */         oome.printStackTrace(System.err);
/*      */       }
/*      */       try
/*      */       {
/* 2397 */         GenericKeyedObjectPool.this.ensureMinIdle();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static class ObjectTimestampPair<T>
/*      */     implements Comparable<T>
/*      */   {
/*      */ 
/*      */     @Deprecated
/*      */     T value;
/*      */ 
/*      */     @Deprecated
/*      */     long tstamp;
/*      */ 
/*      */     ObjectTimestampPair(T val)
/*      */     {
/* 2305 */       this(val, System.currentTimeMillis());
/*      */     }
/*      */ 
/*      */     ObjectTimestampPair(T val, long time)
/*      */     {
/* 2314 */       this.value = val;
/* 2315 */       this.tstamp = time;
/*      */     }
/*      */ 
/*      */     public String toString()
/*      */     {
/* 2325 */       return this.value + ";" + this.tstamp;
/*      */     }
/*      */ 
/*      */     public int compareTo(Object obj)
/*      */     {
/* 2337 */       return compareTo((ObjectTimestampPair)obj);
/*      */     }
/*      */ 
/*      */     public int compareTo(ObjectTimestampPair<T> other)
/*      */     {
/* 2348 */       long tstampdiff = this.tstamp - other.tstamp;
/* 2349 */       if (tstampdiff == 0L)
/*      */       {
/* 2352 */         return System.identityHashCode(this) - System.identityHashCode(other);
/*      */       }
/*      */ 
/* 2355 */       return (int)Math.min(Math.max(tstampdiff, -2147483648L), 2147483647L);
/*      */     }
/*      */ 
/*      */     public T getValue()
/*      */     {
/* 2363 */       return this.value;
/*      */     }
/*      */ 
/*      */     public long getTstamp()
/*      */     {
/* 2370 */       return this.tstamp;
/*      */     }
/*      */   }
/*      */ 
/*      */   private class ObjectQueue
/*      */   {
/* 2233 */     private int activeCount = 0;
/*      */ 
/* 2236 */     private final CursorableLinkedList<GenericKeyedObjectPool.ObjectTimestampPair<V>> queue = new CursorableLinkedList();
/*      */ 
/* 2239 */     private int internalProcessingCount = 0;
/*      */ 
/*      */     private ObjectQueue() {
/*      */     }
/* 2243 */     void incrementActiveCount() { synchronized (GenericKeyedObjectPool.this) {
/* 2244 */         GenericKeyedObjectPool.access$1408(GenericKeyedObjectPool.this);
/*      */       }
/* 2246 */       this.activeCount += 1;
/*      */     }
/*      */ 
/*      */     void decrementActiveCount()
/*      */     {
/* 2251 */       synchronized (GenericKeyedObjectPool.this) {
/* 2252 */         GenericKeyedObjectPool.access$1410(GenericKeyedObjectPool.this);
/*      */       }
/* 2254 */       if (this.activeCount > 0)
/* 2255 */         this.activeCount -= 1;
/*      */     }
/*      */ 
/*      */     void incrementInternalProcessingCount()
/*      */     {
/* 2261 */       synchronized (GenericKeyedObjectPool.this) {
/* 2262 */         GenericKeyedObjectPool.access$1508(GenericKeyedObjectPool.this);
/*      */       }
/* 2264 */       this.internalProcessingCount += 1;
/*      */     }
/*      */ 
/*      */     void decrementInternalProcessingCount()
/*      */     {
/* 2269 */       synchronized (GenericKeyedObjectPool.this) {
/* 2270 */         GenericKeyedObjectPool.access$1510(GenericKeyedObjectPool.this);
/*      */       }
/* 2272 */       this.internalProcessingCount -= 1;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.pool.impl.GenericKeyedObjectPool
 * JD-Core Version:    0.6.2
 */