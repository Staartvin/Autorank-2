/*      */ package org.apache.commons.pool.impl;
/*      */ 
/*      */ import java.util.Collection;
/*      */ import java.util.ConcurrentModificationException;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ 
/*      */ class CursorableSubList<E> extends CursorableLinkedList<E>
/*      */   implements List<E>
/*      */ {
/* 1508 */   protected CursorableLinkedList<E> _list = null;
/*      */ 
/* 1511 */   protected CursorableLinkedList.Listable<E> _pre = null;
/*      */ 
/* 1514 */   protected CursorableLinkedList.Listable<E> _post = null;
/*      */ 
/*      */   CursorableSubList(CursorableLinkedList<E> list, int from, int to)
/*      */   {
/* 1222 */     if ((0 > from) || (list.size() < to))
/* 1223 */       throw new IndexOutOfBoundsException();
/* 1224 */     if (from > to) {
/* 1225 */       throw new IllegalArgumentException();
/*      */     }
/* 1227 */     this._list = list;
/* 1228 */     if (from < list.size()) {
/* 1229 */       this._head.setNext(this._list.getListableAt(from));
/* 1230 */       this._pre = (null == this._head.next() ? null : this._head.next().prev());
/*      */     } else {
/* 1232 */       this._pre = this._list.getListableAt(from - 1);
/*      */     }
/* 1234 */     if (from == to) {
/* 1235 */       this._head.setNext(null);
/* 1236 */       this._head.setPrev(null);
/* 1237 */       if (to < list.size())
/* 1238 */         this._post = this._list.getListableAt(to);
/*      */       else
/* 1240 */         this._post = null;
/*      */     }
/*      */     else {
/* 1243 */       this._head.setPrev(this._list.getListableAt(to - 1));
/* 1244 */       this._post = this._head.prev().next();
/*      */     }
/* 1246 */     this._size = (to - from);
/* 1247 */     this._modCount = this._list._modCount;
/*      */   }
/*      */ 
/*      */   public void clear()
/*      */   {
/* 1254 */     checkForComod();
/* 1255 */     Iterator it = iterator();
/* 1256 */     while (it.hasNext()) {
/* 1257 */       it.next();
/* 1258 */       it.remove();
/*      */     }
/*      */   }
/*      */ 
/*      */   public Iterator<E> iterator()
/*      */   {
/* 1264 */     checkForComod();
/* 1265 */     return super.iterator();
/*      */   }
/*      */ 
/*      */   public int size()
/*      */   {
/* 1270 */     checkForComod();
/* 1271 */     return super.size();
/*      */   }
/*      */ 
/*      */   public boolean isEmpty()
/*      */   {
/* 1276 */     checkForComod();
/* 1277 */     return super.isEmpty();
/*      */   }
/*      */ 
/*      */   public Object[] toArray()
/*      */   {
/* 1282 */     checkForComod();
/* 1283 */     return super.toArray();
/*      */   }
/*      */ 
/*      */   public <T> T[] toArray(T[] a)
/*      */   {
/* 1288 */     checkForComod();
/* 1289 */     return super.toArray(a);
/*      */   }
/*      */ 
/*      */   public boolean contains(Object o)
/*      */   {
/* 1294 */     checkForComod();
/* 1295 */     return super.contains(o);
/*      */   }
/*      */ 
/*      */   public boolean remove(Object o)
/*      */   {
/* 1300 */     checkForComod();
/* 1301 */     return super.remove(o);
/*      */   }
/*      */ 
/*      */   public E removeFirst()
/*      */   {
/* 1306 */     checkForComod();
/* 1307 */     return super.removeFirst();
/*      */   }
/*      */ 
/*      */   public E removeLast()
/*      */   {
/* 1312 */     checkForComod();
/* 1313 */     return super.removeLast();
/*      */   }
/*      */ 
/*      */   public boolean addAll(Collection<? extends E> c)
/*      */   {
/* 1318 */     checkForComod();
/* 1319 */     return super.addAll(c);
/*      */   }
/*      */ 
/*      */   public boolean add(E o)
/*      */   {
/* 1324 */     checkForComod();
/* 1325 */     return super.add(o);
/*      */   }
/*      */ 
/*      */   public boolean addFirst(E o)
/*      */   {
/* 1330 */     checkForComod();
/* 1331 */     return super.addFirst(o);
/*      */   }
/*      */ 
/*      */   public boolean addLast(E o)
/*      */   {
/* 1336 */     checkForComod();
/* 1337 */     return super.addLast(o);
/*      */   }
/*      */ 
/*      */   public boolean removeAll(Collection<?> c)
/*      */   {
/* 1342 */     checkForComod();
/* 1343 */     return super.removeAll(c);
/*      */   }
/*      */ 
/*      */   public boolean containsAll(Collection<?> c)
/*      */   {
/* 1348 */     checkForComod();
/* 1349 */     return super.containsAll(c);
/*      */   }
/*      */ 
/*      */   public boolean addAll(int index, Collection<? extends E> c)
/*      */   {
/* 1354 */     checkForComod();
/* 1355 */     return super.addAll(index, c);
/*      */   }
/*      */ 
/*      */   public int hashCode()
/*      */   {
/* 1360 */     checkForComod();
/* 1361 */     return super.hashCode();
/*      */   }
/*      */ 
/*      */   public boolean retainAll(Collection<?> c)
/*      */   {
/* 1366 */     checkForComod();
/* 1367 */     return super.retainAll(c);
/*      */   }
/*      */ 
/*      */   public E set(int index, E element)
/*      */   {
/* 1372 */     checkForComod();
/* 1373 */     return super.set(index, element);
/*      */   }
/*      */ 
/*      */   public boolean equals(Object o)
/*      */   {
/* 1378 */     checkForComod();
/* 1379 */     return super.equals(o);
/*      */   }
/*      */ 
/*      */   public E get(int index)
/*      */   {
/* 1384 */     checkForComod();
/* 1385 */     return super.get(index);
/*      */   }
/*      */ 
/*      */   public E getFirst()
/*      */   {
/* 1390 */     checkForComod();
/* 1391 */     return super.getFirst();
/*      */   }
/*      */ 
/*      */   public E getLast()
/*      */   {
/* 1396 */     checkForComod();
/* 1397 */     return super.getLast();
/*      */   }
/*      */ 
/*      */   public void add(int index, E element)
/*      */   {
/* 1402 */     checkForComod();
/* 1403 */     super.add(index, element);
/*      */   }
/*      */ 
/*      */   public ListIterator<E> listIterator(int index)
/*      */   {
/* 1408 */     checkForComod();
/* 1409 */     return super.listIterator(index);
/*      */   }
/*      */ 
/*      */   public E remove(int index)
/*      */   {
/* 1414 */     checkForComod();
/* 1415 */     return super.remove(index);
/*      */   }
/*      */ 
/*      */   public int indexOf(Object o)
/*      */   {
/* 1420 */     checkForComod();
/* 1421 */     return super.indexOf(o);
/*      */   }
/*      */ 
/*      */   public int lastIndexOf(Object o)
/*      */   {
/* 1426 */     checkForComod();
/* 1427 */     return super.lastIndexOf(o);
/*      */   }
/*      */ 
/*      */   public ListIterator<E> listIterator()
/*      */   {
/* 1432 */     checkForComod();
/* 1433 */     return super.listIterator();
/*      */   }
/*      */ 
/*      */   public List<E> subList(int fromIndex, int toIndex)
/*      */   {
/* 1438 */     checkForComod();
/* 1439 */     return super.subList(fromIndex, toIndex);
/*      */   }
/*      */ 
/*      */   protected CursorableLinkedList.Listable<E> insertListable(CursorableLinkedList.Listable<E> before, CursorableLinkedList.Listable<E> after, E value)
/*      */   {
/* 1453 */     this._modCount += 1;
/* 1454 */     this._size += 1;
/* 1455 */     CursorableLinkedList.Listable elt = this._list.insertListable(null == before ? this._pre : before, null == after ? this._post : after, value);
/* 1456 */     if (null == this._head.next()) {
/* 1457 */       this._head.setNext(elt);
/* 1458 */       this._head.setPrev(elt);
/*      */     }
/* 1460 */     if (before == this._head.prev()) {
/* 1461 */       this._head.setPrev(elt);
/*      */     }
/* 1463 */     if (after == this._head.next()) {
/* 1464 */       this._head.setNext(elt);
/*      */     }
/* 1466 */     broadcastListableInserted(elt);
/* 1467 */     return elt;
/*      */   }
/*      */ 
/*      */   protected void removeListable(CursorableLinkedList.Listable<E> elt)
/*      */   {
/* 1475 */     this._modCount += 1;
/* 1476 */     this._size -= 1;
/* 1477 */     if ((this._head.next() == elt) && (this._head.prev() == elt)) {
/* 1478 */       this._head.setNext(null);
/* 1479 */       this._head.setPrev(null);
/*      */     }
/* 1481 */     if (this._head.next() == elt) {
/* 1482 */       this._head.setNext(elt.next());
/*      */     }
/* 1484 */     if (this._head.prev() == elt) {
/* 1485 */       this._head.setPrev(elt.prev());
/*      */     }
/* 1487 */     this._list.removeListable(elt);
/* 1488 */     broadcastListableRemoved(elt);
/*      */   }
/*      */ 
/*      */   protected void checkForComod()
/*      */     throws ConcurrentModificationException
/*      */   {
/* 1500 */     if (this._modCount != this._list._modCount)
/* 1501 */       throw new ConcurrentModificationException();
/*      */   }
/*      */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.pool.impl.CursorableSubList
 * JD-Core Version:    0.6.2
 */