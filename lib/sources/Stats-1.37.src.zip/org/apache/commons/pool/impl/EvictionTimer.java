/*     */ package org.apache.commons.pool.impl;
/*     */ 
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ 
/*     */ class EvictionTimer
/*     */ {
/*     */   private static Timer _timer;
/*     */   private static int _usageCount;
/*     */ 
/*     */   static synchronized void schedule(TimerTask task, long delay, long period)
/*     */   {
/*  62 */     if (null == _timer)
/*     */     {
/*  65 */       ClassLoader ccl = (ClassLoader)AccessController.doPrivileged(new PrivilegedGetTccl(null));
/*     */       try
/*     */       {
/*  68 */         AccessController.doPrivileged(new PrivilegedSetTccl(EvictionTimer.class.getClassLoader()));
/*     */ 
/*  70 */         _timer = new Timer(true);
/*     */       } finally {
/*  72 */         AccessController.doPrivileged(new PrivilegedSetTccl(ccl));
/*     */       }
/*     */     }
/*  75 */     _usageCount += 1;
/*  76 */     _timer.schedule(task, delay, period);
/*     */   }
/*     */ 
/*     */   static synchronized void cancel(TimerTask task)
/*     */   {
/*  84 */     task.cancel();
/*  85 */     _usageCount -= 1;
/*  86 */     if (_usageCount == 0) {
/*  87 */       _timer.cancel();
/*  88 */       _timer = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class PrivilegedSetTccl
/*     */     implements PrivilegedAction<ClassLoader>
/*     */   {
/*     */     private final ClassLoader cl;
/*     */ 
/*     */     PrivilegedSetTccl(ClassLoader cl)
/*     */     {
/* 118 */       this.cl = cl;
/*     */     }
/*     */ 
/*     */     public ClassLoader run()
/*     */     {
/* 125 */       Thread.currentThread().setContextClassLoader(this.cl);
/* 126 */       return null;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class PrivilegedGetTccl
/*     */     implements PrivilegedAction<ClassLoader>
/*     */   {
/*     */     public ClassLoader run()
/*     */     {
/* 101 */       return Thread.currentThread().getContextClassLoader();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.pool.impl.EvictionTimer
 * JD-Core Version:    0.6.2
 */