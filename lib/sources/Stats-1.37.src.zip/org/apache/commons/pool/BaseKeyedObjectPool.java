/*     */ package org.apache.commons.pool;
/*     */ 
/*     */ public abstract class BaseKeyedObjectPool<K, V>
/*     */   implements KeyedObjectPool<K, V>
/*     */ {
/* 165 */   private volatile boolean closed = false;
/*     */ 
/*     */   public abstract V borrowObject(K paramK)
/*     */     throws Exception;
/*     */ 
/*     */   public abstract void returnObject(K paramK, V paramV)
/*     */     throws Exception;
/*     */ 
/*     */   public abstract void invalidateObject(K paramK, V paramV)
/*     */     throws Exception;
/*     */ 
/*     */   public void addObject(K key)
/*     */     throws Exception, UnsupportedOperationException
/*     */   {
/*  69 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public int getNumIdle(K key)
/*     */     throws UnsupportedOperationException
/*     */   {
/*  78 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getNumActive(K key)
/*     */     throws UnsupportedOperationException
/*     */   {
/*  87 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getNumIdle()
/*     */     throws UnsupportedOperationException
/*     */   {
/*  95 */     return -1;
/*     */   }
/*     */ 
/*     */   public int getNumActive()
/*     */     throws UnsupportedOperationException
/*     */   {
/* 103 */     return -1;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */     throws Exception, UnsupportedOperationException
/*     */   {
/* 111 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void clear(K key)
/*     */     throws Exception, UnsupportedOperationException
/*     */   {
/* 120 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws Exception
/*     */   {
/* 128 */     this.closed = true;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setFactory(KeyedPoolableObjectFactory<K, V> factory)
/*     */     throws IllegalStateException, UnsupportedOperationException
/*     */   {
/* 140 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   protected final boolean isClosed()
/*     */   {
/* 149 */     return this.closed;
/*     */   }
/*     */ 
/*     */   protected final void assertOpen()
/*     */     throws IllegalStateException
/*     */   {
/* 159 */     if (isClosed())
/* 160 */       throw new IllegalStateException("Pool not open");
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.pool.BaseKeyedObjectPool
 * JD-Core Version:    0.6.2
 */