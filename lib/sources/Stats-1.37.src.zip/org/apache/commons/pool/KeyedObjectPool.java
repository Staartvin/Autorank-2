package org.apache.commons.pool;

import java.util.NoSuchElementException;

public abstract interface KeyedObjectPool<K, V>
{
  public abstract V borrowObject(K paramK)
    throws Exception, NoSuchElementException, IllegalStateException;

  public abstract void returnObject(K paramK, V paramV)
    throws Exception;

  public abstract void invalidateObject(K paramK, V paramV)
    throws Exception;

  public abstract void addObject(K paramK)
    throws Exception, IllegalStateException, UnsupportedOperationException;

  public abstract int getNumIdle(K paramK)
    throws UnsupportedOperationException;

  public abstract int getNumActive(K paramK)
    throws UnsupportedOperationException;

  public abstract int getNumIdle()
    throws UnsupportedOperationException;

  public abstract int getNumActive()
    throws UnsupportedOperationException;

  public abstract void clear()
    throws Exception, UnsupportedOperationException;

  public abstract void clear(K paramK)
    throws Exception, UnsupportedOperationException;

  public abstract void close()
    throws Exception;

  @Deprecated
  public abstract void setFactory(KeyedPoolableObjectFactory<K, V> paramKeyedPoolableObjectFactory)
    throws IllegalStateException, UnsupportedOperationException;
}

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.pool.KeyedObjectPool
 * JD-Core Version:    0.6.2
 */