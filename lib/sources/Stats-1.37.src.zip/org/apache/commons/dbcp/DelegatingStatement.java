/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Statement;
/*     */ import java.util.List;
/*     */ 
/*     */ public class DelegatingStatement extends AbandonedTrace
/*     */   implements Statement
/*     */ {
/*  48 */   protected Statement _stmt = null;
/*     */ 
/*  50 */   protected DelegatingConnection _conn = null;
/*     */ 
/* 129 */   protected boolean _closed = false;
/*     */ 
/*     */   public DelegatingStatement(DelegatingConnection c, Statement s)
/*     */   {
/*  61 */     super(c);
/*  62 */     this._stmt = s;
/*  63 */     this._conn = c;
/*     */   }
/*     */ 
/*     */   public Statement getDelegate()
/*     */   {
/*  72 */     return this._stmt;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj) {
/*  76 */     Statement delegate = getInnermostDelegate();
/*  77 */     if (delegate == null) {
/*  78 */       return false;
/*     */     }
/*  80 */     if ((obj instanceof DelegatingStatement)) {
/*  81 */       DelegatingStatement s = (DelegatingStatement)obj;
/*  82 */       return delegate.equals(s.getInnermostDelegate());
/*     */     }
/*     */ 
/*  85 */     return delegate.equals(obj);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/*  90 */     Object obj = getInnermostDelegate();
/*  91 */     if (obj == null) {
/*  92 */       return 0;
/*     */     }
/*  94 */     return obj.hashCode();
/*     */   }
/*     */ 
/*     */   public Statement getInnermostDelegate()
/*     */   {
/* 114 */     Statement s = this._stmt;
/* 115 */     while ((s != null) && ((s instanceof DelegatingStatement))) {
/* 116 */       s = ((DelegatingStatement)s).getDelegate();
/* 117 */       if (this == s) {
/* 118 */         return null;
/*     */       }
/*     */     }
/* 121 */     return s;
/*     */   }
/*     */ 
/*     */   public void setDelegate(Statement s)
/*     */   {
/* 126 */     this._stmt = s;
/*     */   }
/*     */ 
/*     */   protected boolean isClosed()
/*     */   {
/* 132 */     return this._closed;
/*     */   }
/*     */ 
/*     */   protected void checkOpen() throws SQLException {
/* 136 */     if (isClosed())
/* 137 */       throw new SQLException(getClass().getName() + " with address: \"" + toString() + "\" is closed.");
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/*     */       try
/*     */       {
/* 150 */         if (this._conn != null) {
/* 151 */           this._conn.removeTrace(this);
/* 152 */           this._conn = null;
/*     */         }
/*     */ 
/* 159 */         List resultSets = getTrace();
/* 160 */         if (resultSets != null) {
/* 161 */           ResultSet[] set = (ResultSet[])resultSets.toArray(new ResultSet[resultSets.size()]);
/* 162 */           for (int i = 0; i < set.length; i++) {
/* 163 */             set[i].close();
/*     */           }
/* 165 */           clearTrace();
/*     */         }
/*     */ 
/* 168 */         this._stmt.close();
/*     */       }
/*     */       catch (SQLException e) {
/* 171 */         handleException(e);
/*     */       }
/*     */     }
/*     */     finally {
/* 175 */       this._closed = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void handleException(SQLException e) throws SQLException {
/* 180 */     if (this._conn != null) {
/* 181 */       this._conn.handleException(e);
/*     */     }
/*     */     else
/* 184 */       throw e;
/*     */   }
/*     */ 
/*     */   protected void activate() throws SQLException
/*     */   {
/* 189 */     if ((this._stmt instanceof DelegatingStatement))
/* 190 */       ((DelegatingStatement)this._stmt).activate();
/*     */   }
/*     */ 
/*     */   protected void passivate() throws SQLException
/*     */   {
/* 195 */     if ((this._stmt instanceof DelegatingStatement))
/* 196 */       ((DelegatingStatement)this._stmt).passivate();
/*     */   }
/*     */ 
/*     */   public Connection getConnection() throws SQLException
/*     */   {
/* 201 */     checkOpen();
/* 202 */     return this._conn;
/*     */   }
/*     */ 
/*     */   public ResultSet executeQuery(String sql) throws SQLException {
/* 206 */     checkOpen();
/*     */     try {
/* 208 */       return DelegatingResultSet.wrapResultSet(this, this._stmt.executeQuery(sql));
/*     */     }
/*     */     catch (SQLException e) {
/* 211 */       handleException(e);
/* 212 */     }return null;
/*     */   }
/*     */ 
/*     */   public ResultSet getResultSet() throws SQLException
/*     */   {
/* 217 */     checkOpen();
/*     */     try {
/* 219 */       return DelegatingResultSet.wrapResultSet(this, this._stmt.getResultSet());
/*     */     }
/*     */     catch (SQLException e) {
/* 222 */       handleException(e);
/* 223 */     }return null;
/*     */   }
/*     */ 
/*     */   public int executeUpdate(String sql) throws SQLException
/*     */   {
/* 228 */     checkOpen();
/*     */     try { return this._stmt.executeUpdate(sql); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public int getMaxFieldSize() throws SQLException {
/* 231 */     checkOpen();
/*     */     try { return this._stmt.getMaxFieldSize(); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public void setMaxFieldSize(int max) throws SQLException {
/* 234 */     checkOpen();
/*     */     try { this._stmt.setMaxFieldSize(max); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 237 */   public int getMaxRows() throws SQLException { checkOpen();
/*     */     try { return this._stmt.getMaxRows(); } catch (SQLException e) { handleException(e); } return 0; }
/*     */ 
/*     */   public void setMaxRows(int max) throws SQLException {
/* 240 */     checkOpen();
/*     */     try { this._stmt.setMaxRows(max); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 243 */   public void setEscapeProcessing(boolean enable) throws SQLException { checkOpen();
/*     */     try { this._stmt.setEscapeProcessing(enable); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public int getQueryTimeout() throws SQLException {
/* 246 */     checkOpen();
/*     */     try { return this._stmt.getQueryTimeout(); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public void setQueryTimeout(int seconds) throws SQLException {
/* 249 */     checkOpen();
/*     */     try { this._stmt.setQueryTimeout(seconds); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 252 */   public void cancel() throws SQLException { checkOpen();
/*     */     try { this._stmt.cancel(); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public SQLWarning getWarnings() throws SQLException {
/* 255 */     checkOpen();
/*     */     try { return this._stmt.getWarnings(); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public void clearWarnings() throws SQLException {
/* 258 */     checkOpen();
/*     */     try { this._stmt.clearWarnings(); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 261 */   public void setCursorName(String name) throws SQLException { checkOpen();
/*     */     try { this._stmt.setCursorName(name); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public boolean execute(String sql) throws SQLException {
/* 264 */     checkOpen();
/*     */     try { return this._stmt.execute(sql); } catch (SQLException e) { handleException(e); } return false;
/*     */   }
/*     */   public int getUpdateCount() throws SQLException {
/* 267 */     checkOpen();
/*     */     try { return this._stmt.getUpdateCount(); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public boolean getMoreResults() throws SQLException {
/* 270 */     checkOpen();
/*     */     try { return this._stmt.getMoreResults(); } catch (SQLException e) { handleException(e); } return false;
/*     */   }
/*     */   public void setFetchDirection(int direction) throws SQLException {
/* 273 */     checkOpen();
/*     */     try { this._stmt.setFetchDirection(direction); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 276 */   public int getFetchDirection() throws SQLException { checkOpen();
/*     */     try { return this._stmt.getFetchDirection(); } catch (SQLException e) { handleException(e); } return 0; }
/*     */ 
/*     */   public void setFetchSize(int rows) throws SQLException {
/* 279 */     checkOpen();
/*     */     try { this._stmt.setFetchSize(rows); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 282 */   public int getFetchSize() throws SQLException { checkOpen();
/*     */     try { return this._stmt.getFetchSize(); } catch (SQLException e) { handleException(e); } return 0; }
/*     */ 
/*     */   public int getResultSetConcurrency() throws SQLException {
/* 285 */     checkOpen();
/*     */     try { return this._stmt.getResultSetConcurrency(); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public int getResultSetType() throws SQLException {
/* 288 */     checkOpen();
/*     */     try { return this._stmt.getResultSetType(); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public void addBatch(String sql) throws SQLException {
/* 291 */     checkOpen();
/*     */     try { this._stmt.addBatch(sql); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 294 */   public void clearBatch() throws SQLException { checkOpen();
/*     */     try { this._stmt.clearBatch(); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public int[] executeBatch() throws SQLException {
/* 297 */     checkOpen();
/*     */     try { return this._stmt.executeBatch(); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 306 */     return this._stmt.toString();
/*     */   }
/*     */ 
/*     */   public boolean getMoreResults(int current)
/*     */     throws SQLException
/*     */   {
/* 315 */     checkOpen();
/*     */     try { return this._stmt.getMoreResults(current); } catch (SQLException e) { handleException(e); } return false;
/*     */   }
/*     */   public ResultSet getGeneratedKeys() throws SQLException {
/* 318 */     checkOpen();
/*     */     try { return this._stmt.getGeneratedKeys(); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public int executeUpdate(String sql, int autoGeneratedKeys) throws SQLException {
/* 321 */     checkOpen();
/*     */     try { return this._stmt.executeUpdate(sql, autoGeneratedKeys); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public int executeUpdate(String sql, int[] columnIndexes) throws SQLException {
/* 324 */     checkOpen();
/*     */     try { return this._stmt.executeUpdate(sql, columnIndexes); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public int executeUpdate(String sql, String[] columnNames) throws SQLException {
/* 327 */     checkOpen();
/*     */     try { return this._stmt.executeUpdate(sql, columnNames); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public boolean execute(String sql, int autoGeneratedKeys) throws SQLException {
/* 330 */     checkOpen();
/*     */     try { return this._stmt.execute(sql, autoGeneratedKeys); } catch (SQLException e) { handleException(e); } return false;
/*     */   }
/*     */   public boolean execute(String sql, int[] columnIndexes) throws SQLException {
/* 333 */     checkOpen();
/*     */     try { return this._stmt.execute(sql, columnIndexes); } catch (SQLException e) { handleException(e); } return false;
/*     */   }
/*     */   public boolean execute(String sql, String[] columnNames) throws SQLException {
/* 336 */     checkOpen();
/*     */     try { return this._stmt.execute(sql, columnNames); } catch (SQLException e) { handleException(e); } return false;
/*     */   }
/*     */   public int getResultSetHoldability() throws SQLException {
/* 339 */     checkOpen();
/*     */     try { return this._stmt.getResultSetHoldability(); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.dbcp.DelegatingStatement
 * JD-Core Version:    0.6.2
 */