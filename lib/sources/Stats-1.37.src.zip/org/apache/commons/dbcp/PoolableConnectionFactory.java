/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import org.apache.commons.pool.KeyedObjectPool;
/*     */ import org.apache.commons.pool.KeyedObjectPoolFactory;
/*     */ import org.apache.commons.pool.ObjectPool;
/*     */ import org.apache.commons.pool.PoolableObjectFactory;
/*     */ 
/*     */ public class PoolableConnectionFactory
/*     */   implements PoolableObjectFactory
/*     */ {
/* 396 */   protected ConnectionFactory _connFactory = null;
/* 397 */   protected String _validationQuery = null;
/* 398 */   protected ObjectPool _pool = null;
/* 399 */   protected KeyedObjectPoolFactory _stmtPoolFactory = null;
/* 400 */   protected Boolean _defaultReadOnly = null;
/* 401 */   protected boolean _defaultAutoCommit = true;
/* 402 */   protected int _defaultTransactionIsolation = -1;
/*     */   protected String _defaultCatalog;
/*     */ 
/*     */   /** @deprecated */
/* 408 */   protected AbandonedConfig _config = null;
/*     */   static final int UNKNOWN_TRANSACTIONISOLATION = -1;
/*     */ 
/*     */   public PoolableConnectionFactory(ConnectionFactory connFactory, ObjectPool pool, KeyedObjectPoolFactory stmtPoolFactory, String validationQuery, boolean defaultReadOnly, boolean defaultAutoCommit)
/*     */   {
/*  50 */     this._connFactory = connFactory;
/*  51 */     this._pool = pool;
/*  52 */     this._pool.setFactory(this);
/*  53 */     this._stmtPoolFactory = stmtPoolFactory;
/*  54 */     this._validationQuery = validationQuery;
/*  55 */     this._defaultReadOnly = (defaultReadOnly ? Boolean.TRUE : Boolean.FALSE);
/*  56 */     this._defaultAutoCommit = defaultAutoCommit;
/*     */   }
/*     */ 
/*     */   public PoolableConnectionFactory(ConnectionFactory connFactory, ObjectPool pool, KeyedObjectPoolFactory stmtPoolFactory, String validationQuery, boolean defaultReadOnly, boolean defaultAutoCommit, int defaultTransactionIsolation)
/*     */   {
/*  70 */     this._connFactory = connFactory;
/*  71 */     this._pool = pool;
/*  72 */     this._pool.setFactory(this);
/*  73 */     this._stmtPoolFactory = stmtPoolFactory;
/*  74 */     this._validationQuery = validationQuery;
/*  75 */     this._defaultReadOnly = (defaultReadOnly ? Boolean.TRUE : Boolean.FALSE);
/*  76 */     this._defaultAutoCommit = defaultAutoCommit;
/*  77 */     this._defaultTransactionIsolation = defaultTransactionIsolation;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public PoolableConnectionFactory(ConnectionFactory connFactory, ObjectPool pool, KeyedObjectPoolFactory stmtPoolFactory, String validationQuery, boolean defaultReadOnly, boolean defaultAutoCommit, AbandonedConfig config)
/*     */   {
/* 100 */     this._connFactory = connFactory;
/* 101 */     this._pool = pool;
/* 102 */     this._config = config;
/* 103 */     this._pool.setFactory(this);
/* 104 */     this._stmtPoolFactory = stmtPoolFactory;
/* 105 */     this._validationQuery = validationQuery;
/* 106 */     this._defaultReadOnly = (defaultReadOnly ? Boolean.TRUE : Boolean.FALSE);
/* 107 */     this._defaultAutoCommit = defaultAutoCommit;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public PoolableConnectionFactory(ConnectionFactory connFactory, ObjectPool pool, KeyedObjectPoolFactory stmtPoolFactory, String validationQuery, boolean defaultReadOnly, boolean defaultAutoCommit, int defaultTransactionIsolation, AbandonedConfig config)
/*     */   {
/* 132 */     this._connFactory = connFactory;
/* 133 */     this._pool = pool;
/* 134 */     this._config = config;
/* 135 */     this._pool.setFactory(this);
/* 136 */     this._stmtPoolFactory = stmtPoolFactory;
/* 137 */     this._validationQuery = validationQuery;
/* 138 */     this._defaultReadOnly = (defaultReadOnly ? Boolean.TRUE : Boolean.FALSE);
/* 139 */     this._defaultAutoCommit = defaultAutoCommit;
/* 140 */     this._defaultTransactionIsolation = defaultTransactionIsolation;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public PoolableConnectionFactory(ConnectionFactory connFactory, ObjectPool pool, KeyedObjectPoolFactory stmtPoolFactory, String validationQuery, boolean defaultReadOnly, boolean defaultAutoCommit, int defaultTransactionIsolation, String defaultCatalog, AbandonedConfig config)
/*     */   {
/* 167 */     this._connFactory = connFactory;
/* 168 */     this._pool = pool;
/* 169 */     this._config = config;
/* 170 */     this._pool.setFactory(this);
/* 171 */     this._stmtPoolFactory = stmtPoolFactory;
/* 172 */     this._validationQuery = validationQuery;
/* 173 */     this._defaultReadOnly = (defaultReadOnly ? Boolean.TRUE : Boolean.FALSE);
/* 174 */     this._defaultAutoCommit = defaultAutoCommit;
/* 175 */     this._defaultTransactionIsolation = defaultTransactionIsolation;
/* 176 */     this._defaultCatalog = defaultCatalog;
/*     */   }
/*     */ 
/*     */   public PoolableConnectionFactory(ConnectionFactory connFactory, ObjectPool pool, KeyedObjectPoolFactory stmtPoolFactory, String validationQuery, Boolean defaultReadOnly, boolean defaultAutoCommit, int defaultTransactionIsolation, String defaultCatalog, AbandonedConfig config)
/*     */   {
/* 202 */     this._connFactory = connFactory;
/* 203 */     this._pool = pool;
/* 204 */     this._config = config;
/* 205 */     this._pool.setFactory(this);
/* 206 */     this._stmtPoolFactory = stmtPoolFactory;
/* 207 */     this._validationQuery = validationQuery;
/* 208 */     this._defaultReadOnly = defaultReadOnly;
/* 209 */     this._defaultAutoCommit = defaultAutoCommit;
/* 210 */     this._defaultTransactionIsolation = defaultTransactionIsolation;
/* 211 */     this._defaultCatalog = defaultCatalog;
/*     */   }
/*     */ 
/*     */   public synchronized void setConnectionFactory(ConnectionFactory connFactory)
/*     */   {
/* 219 */     this._connFactory = connFactory;
/*     */   }
/*     */ 
/*     */   public synchronized void setValidationQuery(String validationQuery)
/*     */   {
/* 229 */     this._validationQuery = validationQuery;
/*     */   }
/*     */ 
/*     */   public synchronized void setPool(ObjectPool pool)
/*     */   {
/* 237 */     if ((null != this._pool) && (pool != this._pool))
/*     */       try {
/* 239 */         this._pool.close();
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/*     */       }
/* 244 */     this._pool = pool;
/*     */   }
/*     */ 
/*     */   public ObjectPool getPool() {
/* 248 */     return this._pool;
/*     */   }
/*     */ 
/*     */   public synchronized void setStatementPoolFactory(KeyedObjectPoolFactory stmtPoolFactory)
/*     */   {
/* 258 */     this._stmtPoolFactory = stmtPoolFactory;
/*     */   }
/*     */ 
/*     */   public void setDefaultReadOnly(boolean defaultReadOnly)
/*     */   {
/* 266 */     this._defaultReadOnly = (defaultReadOnly ? Boolean.TRUE : Boolean.FALSE);
/*     */   }
/*     */ 
/*     */   public void setDefaultAutoCommit(boolean defaultAutoCommit)
/*     */   {
/* 274 */     this._defaultAutoCommit = defaultAutoCommit;
/*     */   }
/*     */ 
/*     */   public void setDefaultTransactionIsolation(int defaultTransactionIsolation)
/*     */   {
/* 282 */     this._defaultTransactionIsolation = defaultTransactionIsolation;
/*     */   }
/*     */ 
/*     */   public void setDefaultCatalog(String defaultCatalog)
/*     */   {
/* 290 */     this._defaultCatalog = defaultCatalog;
/*     */   }
/*     */ 
/*     */   public synchronized Object makeObject() throws Exception {
/* 294 */     Connection conn = this._connFactory.createConnection();
/* 295 */     if (null != this._stmtPoolFactory) {
/* 296 */       KeyedObjectPool stmtpool = this._stmtPoolFactory.createPool();
/* 297 */       conn = new PoolingConnection(conn, stmtpool);
/* 298 */       stmtpool.setFactory((PoolingConnection)conn);
/*     */     }
/* 300 */     return new PoolableConnection(conn, this._pool, this._config);
/*     */   }
/*     */ 
/*     */   public void destroyObject(Object obj) throws Exception {
/* 304 */     if ((obj instanceof PoolableConnection))
/* 305 */       ((PoolableConnection)obj).reallyClose();
/*     */   }
/*     */ 
/*     */   public boolean validateObject(Object obj)
/*     */   {
/* 310 */     if ((obj instanceof Connection)) {
/*     */       try {
/* 312 */         validateConnection((Connection)obj);
/* 313 */         return true;
/*     */       } catch (Exception e) {
/* 315 */         return false;
/*     */       }
/*     */     }
/* 318 */     return false;
/*     */   }
/*     */ 
/*     */   public void validateConnection(Connection conn) throws SQLException
/*     */   {
/* 323 */     String query = this._validationQuery;
/* 324 */     if (conn.isClosed()) {
/* 325 */       throw new SQLException("validateConnection: connection closed");
/*     */     }
/* 327 */     if (null != query) {
/* 328 */       Statement stmt = null;
/* 329 */       ResultSet rset = null;
/*     */       try {
/* 331 */         stmt = conn.createStatement();
/* 332 */         rset = stmt.executeQuery(query);
/* 333 */         if (!rset.next())
/* 334 */           throw new SQLException("validationQuery didn't return a row");
/*     */       }
/*     */       finally {
/* 337 */         if (rset != null)
/*     */           try {
/* 339 */             rset.close();
/*     */           }
/*     */           catch (Exception t)
/*     */           {
/*     */           }
/* 344 */         if (stmt != null)
/*     */           try {
/* 346 */             stmt.close();
/*     */           }
/*     */           catch (Exception t)
/*     */           {
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void passivateObject(Object obj) throws Exception {
/* 356 */     if ((obj instanceof Connection)) {
/* 357 */       Connection conn = (Connection)obj;
/* 358 */       if ((!conn.getAutoCommit()) && (!conn.isReadOnly())) {
/* 359 */         conn.rollback();
/*     */       }
/* 361 */       conn.clearWarnings();
/* 362 */       if (!conn.getAutoCommit()) {
/* 363 */         conn.setAutoCommit(true);
/*     */       }
/*     */     }
/* 366 */     if ((obj instanceof DelegatingConnection))
/* 367 */       ((DelegatingConnection)obj).passivate();
/*     */   }
/*     */ 
/*     */   public void activateObject(Object obj) throws Exception
/*     */   {
/* 372 */     if ((obj instanceof DelegatingConnection)) {
/* 373 */       ((DelegatingConnection)obj).activate();
/*     */     }
/* 375 */     if ((obj instanceof Connection)) {
/* 376 */       Connection conn = (Connection)obj;
/* 377 */       if (conn.getAutoCommit() != this._defaultAutoCommit) {
/* 378 */         conn.setAutoCommit(this._defaultAutoCommit);
/*     */       }
/* 380 */       if ((this._defaultTransactionIsolation != -1) && (conn.getTransactionIsolation() != this._defaultTransactionIsolation))
/*     */       {
/* 383 */         conn.setTransactionIsolation(this._defaultTransactionIsolation);
/*     */       }
/* 385 */       if ((this._defaultReadOnly != null) && (conn.isReadOnly() != this._defaultReadOnly.booleanValue()))
/*     */       {
/* 387 */         conn.setReadOnly(this._defaultReadOnly.booleanValue());
/*     */       }
/* 389 */       if ((this._defaultCatalog != null) && (!this._defaultCatalog.equals(conn.getCatalog())))
/*     */       {
/* 391 */         conn.setCatalog(this._defaultCatalog);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.dbcp.PoolableConnectionFactory
 * JD-Core Version:    0.6.2
 */