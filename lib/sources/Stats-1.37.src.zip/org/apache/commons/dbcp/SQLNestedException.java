/*    */ package org.apache.commons.dbcp;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.io.PrintWriter;
/*    */ import java.lang.reflect.Method;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class SQLNestedException extends SQLException
/*    */ {
/* 43 */   private static final Method THROWABLE_CAUSE_METHOD = getCauseMethod;
/*    */ 
/* 54 */   private Throwable cause = null;
/*    */ 
/*    */   private static boolean hasThrowableCauseMethod()
/*    */   {
/* 47 */     return THROWABLE_CAUSE_METHOD != null;
/*    */   }
/*    */ 
/*    */   public SQLNestedException(String msg, Throwable cause)
/*    */   {
/* 65 */     super(msg);
/* 66 */     this.cause = cause;
/* 67 */     if ((cause != null) && (DriverManager.getLogWriter() != null)) {
/* 68 */       DriverManager.getLogWriter().print("Caused by: ");
/* 69 */       cause.printStackTrace(DriverManager.getLogWriter());
/*    */     }
/*    */   }
/*    */ 
/*    */   public Throwable getCause() {
/* 74 */     return this.cause;
/*    */   }
/*    */ 
/*    */   public void printStackTrace(PrintStream s) {
/* 78 */     super.printStackTrace(s);
/* 79 */     if ((this.cause != null) && (!hasThrowableCauseMethod())) {
/* 80 */       s.print("Caused by: ");
/* 81 */       this.cause.printStackTrace(s);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void printStackTrace(PrintWriter s) {
/* 86 */     super.printStackTrace(s);
/* 87 */     if ((this.cause != null) && (!hasThrowableCauseMethod())) {
/* 88 */       s.print("Caused by: ");
/* 89 */       this.cause.printStackTrace(s);
/*    */     }
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     Method getCauseMethod;
/*    */     try
/*    */     {
/* 39 */       getCauseMethod = Throwable.class.getMethod("getCause", (Class[])null);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/*    */       Method getCauseMethod;
/* 41 */       getCauseMethod = null;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.dbcp.SQLNestedException
 * JD-Core Version:    0.6.2
 */