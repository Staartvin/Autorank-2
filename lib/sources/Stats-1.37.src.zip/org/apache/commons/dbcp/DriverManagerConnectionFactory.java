/*    */ package org.apache.commons.dbcp;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.SQLException;
/*    */ import java.util.Properties;
/*    */ 
/*    */ public class DriverManagerConnectionFactory
/*    */   implements ConnectionFactory
/*    */ {
/* 72 */   protected String _connectUri = null;
/* 73 */   protected String _uname = null;
/* 74 */   protected String _passwd = null;
/* 75 */   protected Properties _props = null;
/*    */ 
/*    */   public DriverManagerConnectionFactory(String connectUri, Properties props)
/*    */   {
/* 43 */     this._connectUri = connectUri;
/* 44 */     this._props = props;
/*    */   }
/*    */ 
/*    */   public DriverManagerConnectionFactory(String connectUri, String uname, String passwd)
/*    */   {
/* 55 */     this._connectUri = connectUri;
/* 56 */     this._uname = uname;
/* 57 */     this._passwd = passwd;
/*    */   }
/*    */ 
/*    */   public Connection createConnection() throws SQLException {
/* 61 */     if (null == this._props) {
/* 62 */       if ((this._uname == null) && (this._passwd == null)) {
/* 63 */         return DriverManager.getConnection(this._connectUri);
/*    */       }
/* 65 */       return DriverManager.getConnection(this._connectUri, this._uname, this._passwd);
/*    */     }
/*    */ 
/* 68 */     return DriverManager.getConnection(this._connectUri, this._props);
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.dbcp.DriverManagerConnectionFactory
 * JD-Core Version:    0.6.2
 */