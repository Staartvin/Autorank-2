/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ /** @deprecated */
/*     */ public class AbandonedConfig
/*     */ {
/*  33 */   private boolean removeAbandoned = false;
/*     */ 
/*  71 */   private int removeAbandonedTimeout = 300;
/*     */ 
/*  99 */   private boolean logAbandoned = false;
/*     */ 
/*     */   public boolean getRemoveAbandoned()
/*     */   {
/*  48 */     return this.removeAbandoned;
/*     */   }
/*     */ 
/*     */   public void setRemoveAbandoned(boolean removeAbandoned)
/*     */   {
/*  65 */     this.removeAbandoned = removeAbandoned;
/*     */   }
/*     */ 
/*     */   public int getRemoveAbandonedTimeout()
/*     */   {
/*  81 */     return this.removeAbandonedTimeout;
/*     */   }
/*     */ 
/*     */   public void setRemoveAbandonedTimeout(int removeAbandonedTimeout)
/*     */   {
/*  92 */     this.removeAbandonedTimeout = removeAbandonedTimeout;
/*     */   }
/*     */ 
/*     */   public boolean getLogAbandoned()
/*     */   {
/* 115 */     return this.logAbandoned;
/*     */   }
/*     */ 
/*     */   public void setLogAbandoned(boolean logAbandoned)
/*     */   {
/* 130 */     this.logAbandoned = logAbandoned;
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.dbcp.AbandonedConfig
 * JD-Core Version:    0.6.2
 */