/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.NoSuchElementException;
/*     */ import org.apache.commons.pool.KeyedObjectPool;
/*     */ import org.apache.commons.pool.KeyedPoolableObjectFactory;
/*     */ 
/*     */ public class PoolingConnection extends DelegatingConnection
/*     */   implements Connection, KeyedPoolableObjectFactory
/*     */ {
/*  44 */   protected KeyedObjectPool _pstmtPool = null;
/*     */ 
/*     */   public PoolingConnection(Connection c)
/*     */   {
/*  51 */     super(c);
/*     */   }
/*     */ 
/*     */   public PoolingConnection(Connection c, KeyedObjectPool pool)
/*     */   {
/*  60 */     super(c);
/*  61 */     this._pstmtPool = pool;
/*     */   }
/*     */ 
/*     */   public synchronized void close()
/*     */     throws SQLException
/*     */   {
/*  70 */     if (null != this._pstmtPool) {
/*  71 */       KeyedObjectPool oldpool = this._pstmtPool;
/*  72 */       this._pstmtPool = null;
/*     */       try {
/*  74 */         oldpool.close();
/*     */       } catch (RuntimeException e) {
/*  76 */         throw e;
/*     */       } catch (SQLException e) {
/*  78 */         throw e;
/*     */       } catch (Exception e) {
/*  80 */         throw new SQLNestedException("Cannot close connection", e);
/*     */       }
/*     */     }
/*  83 */     getInnermostDelegate().close();
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/*  92 */       return (PreparedStatement)this._pstmtPool.borrowObject(createKey(sql));
/*     */     } catch (NoSuchElementException e) {
/*  94 */       throw new SQLNestedException("MaxOpenPreparedStatements limit reached", e);
/*     */     } catch (RuntimeException e) {
/*  96 */       throw e;
/*     */     } catch (Exception e) {
/*  98 */       throw new SQLNestedException("Borrow prepareStatement from pool failed", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 108 */       return (PreparedStatement)this._pstmtPool.borrowObject(createKey(sql, resultSetType, resultSetConcurrency));
/*     */     } catch (NoSuchElementException e) {
/* 110 */       throw new SQLNestedException("MaxOpenPreparedStatements limit reached", e);
/*     */     } catch (RuntimeException e) {
/* 112 */       throw e;
/*     */     } catch (Exception e) {
/* 114 */       throw new SQLNestedException("Borrow prepareStatement from pool failed", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object createKey(String sql, int resultSetType, int resultSetConcurrency)
/*     */   {
/* 155 */     String catalog = null;
/*     */     try {
/* 157 */       catalog = getCatalog(); } catch (Exception e) {
/*     */     }
/* 159 */     return new PStmtKey(normalizeSQL(sql), catalog, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   protected Object createKey(String sql)
/*     */   {
/* 166 */     String catalog = null;
/*     */     try {
/* 168 */       catalog = getCatalog(); } catch (Exception e) {
/*     */     }
/* 170 */     return new PStmtKey(normalizeSQL(sql), catalog);
/*     */   }
/*     */ 
/*     */   protected String normalizeSQL(String sql)
/*     */   {
/* 178 */     return sql.trim();
/*     */   }
/*     */ 
/*     */   public Object makeObject(Object obj)
/*     */     throws Exception
/*     */   {
/* 187 */     if ((null == obj) || (!(obj instanceof PStmtKey))) {
/* 188 */       throw new IllegalArgumentException();
/*     */     }
/*     */ 
/* 191 */     PStmtKey key = (PStmtKey)obj;
/* 192 */     if ((null == key._resultSetType) && (null == key._resultSetConcurrency)) {
/* 193 */       return new PoolablePreparedStatement(getDelegate().prepareStatement(key._sql), key, this._pstmtPool, this);
/*     */     }
/* 195 */     return new PoolablePreparedStatement(getDelegate().prepareStatement(key._sql, key._resultSetType.intValue(), key._resultSetConcurrency.intValue()), key, this._pstmtPool, this);
/*     */   }
/*     */ 
/*     */   public void destroyObject(Object key, Object obj)
/*     */     throws Exception
/*     */   {
/* 208 */     if ((obj instanceof DelegatingPreparedStatement))
/* 209 */       ((DelegatingPreparedStatement)obj).getInnermostDelegate().close();
/*     */     else
/* 211 */       ((PreparedStatement)obj).close();
/*     */   }
/*     */ 
/*     */   public boolean validateObject(Object key, Object obj)
/*     */   {
/* 223 */     return true;
/*     */   }
/*     */ 
/*     */   public void activateObject(Object key, Object obj)
/*     */     throws Exception
/*     */   {
/* 233 */     ((DelegatingPreparedStatement)obj).activate();
/*     */   }
/*     */ 
/*     */   public void passivateObject(Object key, Object obj)
/*     */     throws Exception
/*     */   {
/* 243 */     ((PreparedStatement)obj).clearParameters();
/* 244 */     ((DelegatingPreparedStatement)obj).passivate();
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 248 */     return "PoolingConnection: " + this._pstmtPool.toString();
/*     */   }
/*     */ 
/*     */   class PStmtKey
/*     */   {
/* 255 */     protected String _sql = null;
/* 256 */     protected Integer _resultSetType = null;
/* 257 */     protected Integer _resultSetConcurrency = null;
/* 258 */     protected String _catalog = null;
/*     */ 
/*     */     PStmtKey(String sql) {
/* 261 */       this._sql = sql;
/*     */     }
/*     */ 
/*     */     PStmtKey(String sql, String catalog) {
/* 265 */       this._sql = sql;
/* 266 */       this._catalog = catalog;
/*     */     }
/*     */ 
/*     */     PStmtKey(String sql, int resultSetType, int resultSetConcurrency) {
/* 270 */       this._sql = sql;
/* 271 */       this._resultSetType = new Integer(resultSetType);
/* 272 */       this._resultSetConcurrency = new Integer(resultSetConcurrency);
/*     */     }
/*     */ 
/*     */     PStmtKey(String sql, String catalog, int resultSetType, int resultSetConcurrency) {
/* 276 */       this._sql = sql;
/* 277 */       this._catalog = catalog;
/* 278 */       this._resultSetType = new Integer(resultSetType);
/* 279 */       this._resultSetConcurrency = new Integer(resultSetConcurrency);
/*     */     }
/*     */ 
/*     */     public boolean equals(Object that) {
/*     */       try {
/* 284 */         PStmtKey key = (PStmtKey)that;
/* 285 */         return ((null == this._sql) && (null == key._sql)) || ((this._sql.equals(key._sql)) && (((null == this._catalog) && (null == key._catalog)) || ((this._catalog.equals(key._catalog)) && (((null == this._resultSetType) && (null == key._resultSetType)) || ((this._resultSetType.equals(key._resultSetType)) && (((null == this._resultSetConcurrency) && (null == key._resultSetConcurrency)) || (this._resultSetConcurrency.equals(key._resultSetConcurrency))))))));
/*     */       }
/*     */       catch (ClassCastException e)
/*     */       {
/* 291 */         return false; } catch (NullPointerException e) {
/*     */       }
/* 293 */       return false;
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 298 */       if (this._catalog == null) {
/* 299 */         return null == this._sql ? 0 : this._sql.hashCode();
/*     */       }
/* 301 */       return null == this._sql ? this._catalog.hashCode() : (this._catalog + this._sql).hashCode();
/*     */     }
/*     */ 
/*     */     public String toString() {
/* 305 */       StringBuffer buf = new StringBuffer();
/* 306 */       buf.append("PStmtKey: sql=");
/* 307 */       buf.append(this._sql);
/* 308 */       buf.append(", catalog=");
/* 309 */       buf.append(this._catalog);
/* 310 */       buf.append(", resultSetType=");
/* 311 */       buf.append(this._resultSetType);
/* 312 */       buf.append(", resultSetConcurrency=");
/* 313 */       buf.append(this._resultSetConcurrency);
/* 314 */       return buf.toString();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.dbcp.PoolingConnection
 * JD-Core Version:    0.6.2
 */