package org.apache.commons.dbcp;

import java.sql.Connection;
import java.sql.SQLException;

public abstract interface ConnectionFactory
{
  public abstract Connection createConnection()
    throws SQLException;
}

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.dbcp.ConnectionFactory
 * JD-Core Version:    0.6.2
 */