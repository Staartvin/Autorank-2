/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ import org.apache.commons.pool.KeyedObjectPool;
/*     */ 
/*     */ public class PoolablePreparedStatement extends DelegatingPreparedStatement
/*     */   implements PreparedStatement
/*     */ {
/*  45 */   protected KeyedObjectPool _pool = null;
/*     */ 
/*  50 */   protected Object _key = null;
/*     */ 
/*     */   public PoolablePreparedStatement(PreparedStatement stmt, Object key, KeyedObjectPool pool, Connection conn)
/*     */   {
/*  60 */     super((DelegatingConnection)conn, stmt);
/*  61 */     this._pool = pool;
/*  62 */     this._key = key;
/*     */ 
/*  66 */     if (this._conn != null)
/*  67 */       this._conn.removeTrace(this);
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/*  75 */     if (isClosed())
/*  76 */       throw new SQLException("Already closed");
/*     */     try
/*     */     {
/*  79 */       this._pool.returnObject(this._key, this);
/*     */     } catch (SQLException e) {
/*  81 */       throw e;
/*     */     } catch (RuntimeException e) {
/*  83 */       throw e;
/*     */     } catch (Exception e) {
/*  85 */       throw new SQLNestedException("Cannot close preparedstatement (return to pool failed)", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void activate() throws SQLException
/*     */   {
/*  91 */     this._closed = false;
/*  92 */     if (this._conn != null) {
/*  93 */       this._conn.addTrace(this);
/*     */     }
/*  95 */     super.activate();
/*     */   }
/*     */ 
/*     */   protected void passivate() throws SQLException {
/*  99 */     this._closed = true;
/* 100 */     if (this._conn != null) {
/* 101 */       this._conn.removeTrace(this);
/*     */     }
/*     */ 
/* 108 */     List resultSets = getTrace();
/* 109 */     if (resultSets != null) {
/* 110 */       ResultSet[] set = (ResultSet[])resultSets.toArray(new ResultSet[resultSets.size()]);
/* 111 */       for (int i = 0; i < set.length; i++) {
/* 112 */         set[i].close();
/*     */       }
/* 114 */       clearTrace();
/*     */     }
/*     */ 
/* 117 */     super.passivate();
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.dbcp.PoolablePreparedStatement
 * JD-Core Version:    0.6.2
 */