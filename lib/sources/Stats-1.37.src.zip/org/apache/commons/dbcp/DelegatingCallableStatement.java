/*     */ package org.apache.commons.dbcp;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.math.BigDecimal;
/*     */ import java.net.URL;
/*     */ import java.sql.Array;
/*     */ import java.sql.Blob;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.Clob;
/*     */ import java.sql.Date;
/*     */ import java.sql.Ref;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class DelegatingCallableStatement extends DelegatingPreparedStatement
/*     */   implements CallableStatement
/*     */ {
/*  57 */   protected CallableStatement _stmt = null;
/*     */ 
/*     */   public DelegatingCallableStatement(DelegatingConnection c, CallableStatement s)
/*     */   {
/*  69 */     super(c, s);
/*  70 */     this._stmt = s;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj) {
/*  74 */     CallableStatement delegate = (CallableStatement)getInnermostDelegate();
/*  75 */     if (delegate == null) {
/*  76 */       return false;
/*     */     }
/*  78 */     if ((obj instanceof DelegatingCallableStatement)) {
/*  79 */       DelegatingCallableStatement s = (DelegatingCallableStatement)obj;
/*  80 */       return delegate.equals(s.getInnermostDelegate());
/*     */     }
/*     */ 
/*  83 */     return delegate.equals(obj);
/*     */   }
/*     */ 
/*     */   public void setDelegate(CallableStatement s)
/*     */   {
/*  89 */     super.setDelegate(s);
/*  90 */     this._stmt = s;
/*     */   }
/*     */ 
/*     */   public void registerOutParameter(int parameterIndex, int sqlType) throws SQLException {
/*  94 */     checkOpen();
/*     */     try { this._stmt.registerOutParameter(parameterIndex, sqlType); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/*  97 */   public void registerOutParameter(int parameterIndex, int sqlType, int scale) throws SQLException { checkOpen();
/*     */     try { this._stmt.registerOutParameter(parameterIndex, sqlType, scale); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public boolean wasNull() throws SQLException {
/* 100 */     checkOpen();
/*     */     try { return this._stmt.wasNull(); } catch (SQLException e) { handleException(e); } return false;
/*     */   }
/*     */   public String getString(int parameterIndex) throws SQLException {
/* 103 */     checkOpen();
/*     */     try { return this._stmt.getString(parameterIndex); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public boolean getBoolean(int parameterIndex) throws SQLException {
/* 106 */     checkOpen();
/*     */     try { return this._stmt.getBoolean(parameterIndex); } catch (SQLException e) { handleException(e); } return false;
/*     */   }
/*     */   public byte getByte(int parameterIndex) throws SQLException {
/* 109 */     checkOpen();
/*     */     try { return this._stmt.getByte(parameterIndex); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public short getShort(int parameterIndex) throws SQLException {
/* 112 */     checkOpen();
/*     */     try { return this._stmt.getShort(parameterIndex); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public int getInt(int parameterIndex) throws SQLException {
/* 115 */     checkOpen();
/*     */     try { return this._stmt.getInt(parameterIndex); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public long getLong(int parameterIndex) throws SQLException {
/* 118 */     checkOpen();
/*     */     try { return this._stmt.getLong(parameterIndex); } catch (SQLException e) { handleException(e); } return 0L;
/*     */   }
/*     */   public float getFloat(int parameterIndex) throws SQLException {
/* 121 */     checkOpen();
/*     */     try { return this._stmt.getFloat(parameterIndex); } catch (SQLException e) { handleException(e); } return 0.0F;
/*     */   }
/*     */   public double getDouble(int parameterIndex) throws SQLException {
/* 124 */     checkOpen();
/*     */     try { return this._stmt.getDouble(parameterIndex); } catch (SQLException e) { handleException(e); } return 0.0D;
/*     */   }
/*     */   /** @deprecated */
/*     */   public BigDecimal getBigDecimal(int parameterIndex, int scale) throws SQLException {
/* 128 */     checkOpen();
/*     */     try { return this._stmt.getBigDecimal(parameterIndex, scale); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public byte[] getBytes(int parameterIndex) throws SQLException {
/* 131 */     checkOpen();
/*     */     try { return this._stmt.getBytes(parameterIndex); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Date getDate(int parameterIndex) throws SQLException {
/* 134 */     checkOpen();
/*     */     try { return this._stmt.getDate(parameterIndex); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Time getTime(int parameterIndex) throws SQLException {
/* 137 */     checkOpen();
/*     */     try { return this._stmt.getTime(parameterIndex); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Timestamp getTimestamp(int parameterIndex) throws SQLException {
/* 140 */     checkOpen();
/*     */     try { return this._stmt.getTimestamp(parameterIndex); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Object getObject(int parameterIndex) throws SQLException {
/* 143 */     checkOpen();
/*     */     try { return this._stmt.getObject(parameterIndex); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public BigDecimal getBigDecimal(int parameterIndex) throws SQLException {
/* 146 */     checkOpen();
/*     */     try { return this._stmt.getBigDecimal(parameterIndex); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Object getObject(int i, Map map) throws SQLException {
/* 149 */     checkOpen();
/*     */     try { return this._stmt.getObject(i, map); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Ref getRef(int i) throws SQLException {
/* 152 */     checkOpen();
/*     */     try { return this._stmt.getRef(i); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Blob getBlob(int i) throws SQLException {
/* 155 */     checkOpen();
/*     */     try { return this._stmt.getBlob(i); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Clob getClob(int i) throws SQLException {
/* 158 */     checkOpen();
/*     */     try { return this._stmt.getClob(i); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Array getArray(int i) throws SQLException {
/* 161 */     checkOpen();
/*     */     try { return this._stmt.getArray(i); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Date getDate(int parameterIndex, Calendar cal) throws SQLException {
/* 164 */     checkOpen();
/*     */     try { return this._stmt.getDate(parameterIndex, cal); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Time getTime(int parameterIndex, Calendar cal) throws SQLException {
/* 167 */     checkOpen();
/*     */     try { return this._stmt.getTime(parameterIndex, cal); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Timestamp getTimestamp(int parameterIndex, Calendar cal) throws SQLException {
/* 170 */     checkOpen();
/*     */     try { return this._stmt.getTimestamp(parameterIndex, cal); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public void registerOutParameter(int paramIndex, int sqlType, String typeName) throws SQLException {
/* 173 */     checkOpen();
/*     */     try { this._stmt.registerOutParameter(paramIndex, sqlType, typeName); } catch (SQLException e) { handleException(e); }
/*     */ 
/*     */   }
/*     */ 
/*     */   public void registerOutParameter(String parameterName, int sqlType)
/*     */     throws SQLException
/*     */   {
/* 181 */     checkOpen();
/*     */     try { this._stmt.registerOutParameter(parameterName, sqlType); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 184 */   public void registerOutParameter(String parameterName, int sqlType, int scale) throws SQLException { checkOpen();
/*     */     try { this._stmt.registerOutParameter(parameterName, sqlType, scale); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public void registerOutParameter(String parameterName, int sqlType, String typeName) throws SQLException {
/* 187 */     checkOpen();
/*     */     try { this._stmt.registerOutParameter(parameterName, sqlType, typeName); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 190 */   public URL getURL(int parameterIndex) throws SQLException { checkOpen();
/*     */     try { return this._stmt.getURL(parameterIndex); } catch (SQLException e) { handleException(e); } return null; }
/*     */ 
/*     */   public void setURL(String parameterName, URL val) throws SQLException {
/* 193 */     checkOpen();
/*     */     try { this._stmt.setURL(parameterName, val); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 196 */   public void setNull(String parameterName, int sqlType) throws SQLException { checkOpen();
/*     */     try { this._stmt.setNull(parameterName, sqlType); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public void setBoolean(String parameterName, boolean x) throws SQLException {
/* 199 */     checkOpen();
/*     */     try { this._stmt.setBoolean(parameterName, x); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 202 */   public void setByte(String parameterName, byte x) throws SQLException { checkOpen();
/*     */     try { this._stmt.setByte(parameterName, x); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public void setShort(String parameterName, short x) throws SQLException {
/* 205 */     checkOpen();
/*     */     try { this._stmt.setShort(parameterName, x); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 208 */   public void setInt(String parameterName, int x) throws SQLException { checkOpen();
/*     */     try { this._stmt.setInt(parameterName, x); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public void setLong(String parameterName, long x) throws SQLException {
/* 211 */     checkOpen();
/*     */     try { this._stmt.setLong(parameterName, x); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 214 */   public void setFloat(String parameterName, float x) throws SQLException { checkOpen();
/*     */     try { this._stmt.setFloat(parameterName, x); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public void setDouble(String parameterName, double x) throws SQLException {
/* 217 */     checkOpen();
/*     */     try { this._stmt.setDouble(parameterName, x); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 220 */   public void setBigDecimal(String parameterName, BigDecimal x) throws SQLException { checkOpen();
/*     */     try { this._stmt.setBigDecimal(parameterName, x); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public void setString(String parameterName, String x) throws SQLException {
/* 223 */     checkOpen();
/*     */     try { this._stmt.setString(parameterName, x); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 226 */   public void setBytes(String parameterName, byte[] x) throws SQLException { checkOpen();
/*     */     try { this._stmt.setBytes(parameterName, x); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public void setDate(String parameterName, Date x) throws SQLException {
/* 229 */     checkOpen();
/*     */     try { this._stmt.setDate(parameterName, x); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 232 */   public void setTime(String parameterName, Time x) throws SQLException { checkOpen();
/*     */     try { this._stmt.setTime(parameterName, x); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public void setTimestamp(String parameterName, Timestamp x) throws SQLException {
/* 235 */     checkOpen();
/*     */     try { this._stmt.setTimestamp(parameterName, x); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 238 */   public void setAsciiStream(String parameterName, InputStream x, int length) throws SQLException { checkOpen();
/*     */     try { this._stmt.setAsciiStream(parameterName, x, length); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public void setBinaryStream(String parameterName, InputStream x, int length) throws SQLException {
/* 241 */     checkOpen();
/*     */     try { this._stmt.setBinaryStream(parameterName, x, length); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 244 */   public void setObject(String parameterName, Object x, int targetSqlType, int scale) throws SQLException { checkOpen();
/*     */     try { this._stmt.setObject(parameterName, x, targetSqlType, scale); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public void setObject(String parameterName, Object x, int targetSqlType) throws SQLException {
/* 247 */     checkOpen();
/*     */     try { this._stmt.setObject(parameterName, x, targetSqlType); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 250 */   public void setObject(String parameterName, Object x) throws SQLException { checkOpen();
/*     */     try { this._stmt.setObject(parameterName, x); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public void setCharacterStream(String parameterName, Reader reader, int length) throws SQLException {
/* 253 */     checkOpen(); this._stmt.setCharacterStream(parameterName, reader, length);
/*     */   }
/*     */   public void setDate(String parameterName, Date x, Calendar cal) throws SQLException {
/* 256 */     checkOpen();
/*     */     try { this._stmt.setDate(parameterName, x, cal); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 259 */   public void setTime(String parameterName, Time x, Calendar cal) throws SQLException { checkOpen();
/*     */     try { this._stmt.setTime(parameterName, x, cal); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public void setTimestamp(String parameterName, Timestamp x, Calendar cal) throws SQLException {
/* 262 */     checkOpen();
/*     */     try { this._stmt.setTimestamp(parameterName, x, cal); } catch (SQLException e) { handleException(e); } 
/*     */   }
/*     */ 
/* 265 */   public void setNull(String parameterName, int sqlType, String typeName) throws SQLException { checkOpen();
/*     */     try { this._stmt.setNull(parameterName, sqlType, typeName); } catch (SQLException e) { handleException(e); } }
/*     */ 
/*     */   public String getString(String parameterName) throws SQLException {
/* 268 */     checkOpen();
/*     */     try { return this._stmt.getString(parameterName); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public boolean getBoolean(String parameterName) throws SQLException {
/* 271 */     checkOpen();
/*     */     try { return this._stmt.getBoolean(parameterName); } catch (SQLException e) { handleException(e); } return false;
/*     */   }
/*     */   public byte getByte(String parameterName) throws SQLException {
/* 274 */     checkOpen();
/*     */     try { return this._stmt.getByte(parameterName); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public short getShort(String parameterName) throws SQLException {
/* 277 */     checkOpen();
/*     */     try { return this._stmt.getShort(parameterName); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public int getInt(String parameterName) throws SQLException {
/* 280 */     checkOpen();
/*     */     try { return this._stmt.getInt(parameterName); } catch (SQLException e) { handleException(e); } return 0;
/*     */   }
/*     */   public long getLong(String parameterName) throws SQLException {
/* 283 */     checkOpen();
/*     */     try { return this._stmt.getLong(parameterName); } catch (SQLException e) { handleException(e); } return 0L;
/*     */   }
/*     */   public float getFloat(String parameterName) throws SQLException {
/* 286 */     checkOpen();
/*     */     try { return this._stmt.getFloat(parameterName); } catch (SQLException e) { handleException(e); } return 0.0F;
/*     */   }
/*     */   public double getDouble(String parameterName) throws SQLException {
/* 289 */     checkOpen();
/*     */     try { return this._stmt.getDouble(parameterName); } catch (SQLException e) { handleException(e); } return 0.0D;
/*     */   }
/*     */   public byte[] getBytes(String parameterName) throws SQLException {
/* 292 */     checkOpen();
/*     */     try { return this._stmt.getBytes(parameterName); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Date getDate(String parameterName) throws SQLException {
/* 295 */     checkOpen();
/*     */     try { return this._stmt.getDate(parameterName); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Time getTime(String parameterName) throws SQLException {
/* 298 */     checkOpen();
/*     */     try { return this._stmt.getTime(parameterName); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Timestamp getTimestamp(String parameterName) throws SQLException {
/* 301 */     checkOpen();
/*     */     try { return this._stmt.getTimestamp(parameterName); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Object getObject(String parameterName) throws SQLException {
/* 304 */     checkOpen();
/*     */     try { return this._stmt.getObject(parameterName); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public BigDecimal getBigDecimal(String parameterName) throws SQLException {
/* 307 */     checkOpen();
/*     */     try { return this._stmt.getBigDecimal(parameterName); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Object getObject(String parameterName, Map map) throws SQLException {
/* 310 */     checkOpen();
/*     */     try { return this._stmt.getObject(parameterName, map); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Ref getRef(String parameterName) throws SQLException {
/* 313 */     checkOpen();
/*     */     try { return this._stmt.getRef(parameterName); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Blob getBlob(String parameterName) throws SQLException {
/* 316 */     checkOpen();
/*     */     try { return this._stmt.getBlob(parameterName); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Clob getClob(String parameterName) throws SQLException {
/* 319 */     checkOpen();
/*     */     try { return this._stmt.getClob(parameterName); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Array getArray(String parameterName) throws SQLException {
/* 322 */     checkOpen();
/*     */     try { return this._stmt.getArray(parameterName); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Date getDate(String parameterName, Calendar cal) throws SQLException {
/* 325 */     checkOpen();
/*     */     try { return this._stmt.getDate(parameterName, cal); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Time getTime(String parameterName, Calendar cal) throws SQLException {
/* 328 */     checkOpen();
/*     */     try { return this._stmt.getTime(parameterName, cal); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public Timestamp getTimestamp(String parameterName, Calendar cal) throws SQLException {
/* 331 */     checkOpen();
/*     */     try { return this._stmt.getTimestamp(parameterName, cal); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */   public URL getURL(String parameterName) throws SQLException {
/* 334 */     checkOpen();
/*     */     try { return this._stmt.getURL(parameterName); } catch (SQLException e) { handleException(e); } return null;
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     org.apache.commons.dbcp.DelegatingCallableStatement
 * JD-Core Version:    0.6.2
 */