/*     */ package nl.lolmewn.stats;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import nl.lolmewn.stats.api.StatsAPI;
/*     */ 
/*     */ @Deprecated
/*     */ public enum StatType
/*     */ {
/*  11 */   BLOCK_BREAK("UPDATE PREFIXblock SET amount=amount+? WHERE player=? AND blockID=? AND blockData=? AND break=?", "INSERT INTO PREFIXblock (player, blockID, blockData, break, amount) VALUES (?, ?, ?, ?, ?)", 5), 
/*     */ 
/*  13 */   BLOCK_PLACE("UPDATE PREFIXblock SET amount=amount+? WHERE player=? AND blockID=? AND blockData=? AND break=?", "INSERT INTO PREFIXblock (player, blockID, blockData, break, amount) VALUES (?, ?, ?, ?, ?)", 5), 
/*     */ 
/*  15 */   MOVE("UPDATE PREFIXmove SET distance=distance+? WHERE player=? AND type=?", "INSERT INTO PREFIXmove (player, type, distance) VALUES (?, ?, ?)", 3), 
/*     */ 
/*  17 */   KILL("UPDATE PREFIXkill SET amount=amount+? WHERE player=? AND type=?", "INSERT INTO PREFIXkill (player, type, amount) VALUES (?, ?, ?)", 3), 
/*     */ 
/*  19 */   DEATH("UPDATE PREFIXdeath SET amount=amount+? WHERE player=? AND cause=? AND entity=?", "INSERT INTO PREFIXdeath (player, cause, entity, amount) VALUES (?, ?, ?, ?)", 4), 
/*     */ 
/*  21 */   PLAYTIME("UPDATE PREFIXplayer SET playtime=playtime+? WHERE player=?", "INSERT INTO PREFIXplayer (player, playtime) VALUES (?, ?)", 2), 
/*     */ 
/*  23 */   ARROWS("UPDATE PREFIXplayer SET arrows=arrows+? WHERE player=?", "INSERT INTO PREFIXplayer (player, arrows) VALUES (?, ?)", 2), 
/*     */ 
/*  25 */   XP_GAINED("UPDATE PREFIXplayer SET xpgained=xpgained+? WHERE player=?", "INSERT INTO PREFIXplayer (player, xpgained) VALUES (?, ?)", 2), 
/*     */ 
/*  27 */   JOINS("UPDATE PREFIXplayer SET joins=joins+? WHERE player=?", "INSERT INTO PREFIXplayer (player, joins) VALUES (?, ?)", 2), 
/*     */ 
/*  29 */   FISH_CATCHED("UPDATE PREFIXplayer SET fishcatch=fishcatch+? WHERE player=?", "INSERT INTO PREFIXplayer (player, fishcatch) VALUES (?, ?)", 2), 
/*     */ 
/*  31 */   DAMAGE_TAKEN("UPDATE PREFIXplayer SET damagetaken=damagetaken+? WHERE player=?", "INSERT INTO PREFIXplayer (player, damagetaken) VALUES (?, ?)", 2), 
/*     */ 
/*  33 */   TIMES_KICKED("UPDATE PREFIXplayer SET timeskicked=timeskicked+? WHERE player=?", "INSERT INTO PREFIXplayer (player, timeskicked) VALUES (?, ?)", 2), 
/*     */ 
/*  35 */   TOOLS_BROKEN("UPDATE PREFIXplayer SET toolsbroken=toolsbroken+? WHERE player=?", "INSERT INTO PREFIXplayer (player, toolsbroken) VALUES (?, ?)", 2), 
/*     */ 
/*  37 */   EGGS_THROWN("UPDATE PREFIXplayer SET eggsthrown=eggsthrown+? WHERE player=?", "INSERT INTO PREFIXplayer (player, eggsthrown) VALUES (?, ?)", 2), 
/*     */ 
/*  39 */   ITEMS_CRAFTED("UPDATE PREFIXplayer SET itemscrafted=itemscrafted+? WHERE player=?", "INSERT INTO PREFIXplayer (player, itemscrafted) VALUES (?, ?)", 2), 
/*     */ 
/*  41 */   OMNOMNOM("UPDATE PREFIXplayer SET omnomnom=omnomnom+? WHERE player=?", "INSERT INTO PREFIXplayer (player, omnomnom) VALUES (?, ?)", 2), 
/*     */ 
/*  43 */   ON_FIRE("UPDATE PREFIXplayer SET onfire=onfire+? WHERE player=?", "INSERT INTO PREFIXplayer (player, onfire) VALUES (?, ?)", 2), 
/*     */ 
/*  45 */   WORDS_SAID("UPDATE PREFIXplayer SET wordssaid=wordssaid+? WHERE player=?", "INSERT INTO PREFIXplayer (player, wordssaid) VALUES (?, ?)", 2), 
/*     */ 
/*  47 */   COMMANDS_DONE("UPDATE PREFIXplayer SET commandsdone=commandsdone+? WHERE player=?", "INSERT INTO PREFIXplayer (player, commandsdone) VALUES (?, ?)", 2), 
/*     */ 
/*  49 */   VOTES("UPDATE PREFIXplayer SET votes=votes+? WHERE player=?", "INSERT INTO PREFIXplayer (player, votes) VALUES (?, ?)", 2), 
/*     */ 
/*  51 */   LASTJOIN("UPDATE PREFIXplayer SET lastjoin=? WHERE player=?", "INSERT INTO PREFIXplayer (player, lastjoin) VALUES (?, ?)", 2), 
/*     */ 
/*  53 */   LASTLEAVE("UPDATE PREFIXplayer SET lastleave=? WHERE player=?", "INSERT INTO PREFIXplayer (player, lastleave) VALUES (?, ?)", 2), 
/*     */ 
/*  55 */   TELEPORTS("UPDATE PREFIXplayer SET teleports=teleports+? WHERE player=?", "INSERT INTO PREFIXplayer (player, teleports) VALUES (?, ?)", 2), 
/*     */ 
/*  57 */   ITEMPICKUPS("UPDATE PREFIXplayer SET itempickups=itempickups+? WHERE player=?", "INSERT INTO PREFIXplayer (player, itempickups) VALUES (?, ?)", 2), 
/*     */ 
/*  59 */   BEDENTER("UPDATE PREFIXplayer SET bedenter=bedenter+? WHERE player=?", "INSERT INTO PREFIXplayer (player, bedenter) VALUES (?, ?)", 2), 
/*     */ 
/*  61 */   BUCKETFILL("UPDATE PREFIXplayer SET bucketfill=bucketfill+? WHERE player=?", "INSERT INTO PREFIXplayer (player, bucketfill) VALUES (?, ?)", 2), 
/*     */ 
/*  63 */   BUCKETEMPTY("UPDATE PREFIXplayer SET bucketempty=bucketempty+? WHERE player=?", "INSERT INTO PREFIXplayer (player, bucketempty) VALUES (?, ?)", 2), 
/*     */ 
/*  65 */   WORLDCHANGE("UPDATE PREFIXplayer SET worldchange=worldchange+? WHERE player=?", "INSERT INTO PREFIXplayer (player, worldchange) VALUES (?, ?)", 2), 
/*     */ 
/*  67 */   ITEMDROPS("UPDATE PREFIXplayer SET itemdrops=itemdrops+? WHERE player=?", "INSERT INTO PREFIXplayer (player, itemdrops) VALUES (?, ?)", 2), 
/*     */ 
/*  69 */   SHEAR("UPDATE PREFIXplayer SET shear=shear+? WHERE player=?", "INSERT INTO PREFIXplayer (player, shear) VALUES (?, ?)", 2);
/*     */ 
/*     */   private final String update;
/*     */   private final String insert;
/*     */   private final int variableCount;
/*     */ 
/*  75 */   private StatType(String query, String insert, int variableCount) { this.update = query;
/*  76 */     this.insert = insert;
/*  77 */     this.variableCount = variableCount; }
/*     */ 
/*     */   protected static void registerTypes(StatsAPI api)
/*     */   {
/*  81 */     for (StatType type : values())
/*  82 */       api.addStat(type.makeMePretty(), type.update, type.insert);
/*     */   }
/*     */ 
/*     */   public String getUpdateStatement(String dbPrefix)
/*     */   {
/*  92 */     return this.update.replaceFirst("PREFIX", dbPrefix);
/*     */   }
/*     */ 
/*     */   public String getInsertStatement(String dbPrefix)
/*     */   {
/* 101 */     return this.insert.replaceFirst("PREFIX", dbPrefix);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public int getVariableCount()
/*     */   {
/* 111 */     return this.variableCount;
/*     */   }
/*     */ 
/*     */   public String getSelectStatement(String dbPrefix, boolean allRows) {
/* 115 */     StringBuilder sb = new StringBuilder();
/* 116 */     sb.append("SELECT * FROM ").append(this.update.split(" ")[1].replace("PREFIX", dbPrefix)).append(" ");
/* 117 */     sb.append("WHERE player=?");
/* 118 */     if (this.update.contains("PREFIXplayer")) {
/* 119 */       sb.append(" AND ").append(toString().replace("_", "")).append("=?");
/* 120 */       return sb.toString();
/*     */     }
/* 122 */     if (allRows) {
/* 123 */       return sb.toString();
/*     */     }
/* 125 */     switch (1.$SwitchMap$nl$lolmewn$stats$StatType[ordinal()]) {
/*     */     case 1:
/*     */     case 2:
/* 128 */       sb.append("AND blockID=? AND blockData=? AND breaking=?");
/* 129 */       return sb.toString();
/*     */     case 3:
/*     */     case 4:
/* 132 */       sb.append("AND type=?");
/* 133 */       return sb.toString();
/*     */     case 5:
/* 135 */       sb.append("AND cause=? AND entity=?");
/* 136 */       return sb.toString();
/*     */     }
/* 138 */     System.out.println(new StringBuilder().append("Unknown StatType called! ").append(name()).toString());
/* 139 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public boolean isPlayerTableData()
/*     */   {
/* 144 */     return this.update.contains("PREFIXplayer");
/*     */   }
/*     */ 
/*     */   public String getPlayerTableRow() {
/* 148 */     if (!isPlayerTableData()) {
/* 149 */       return "notInPlayerTable";
/*     */     }
/* 151 */     return toString().replace("_", "");
/*     */   }
/*     */ 
/*     */   public static StatType getFromDatabaseColumn(String column) {
/* 155 */     for (StatType type : values()) {
/* 156 */       if (column.toUpperCase().startsWith(type.toString().contains("_") ? type.toString().split("_")[0] : type.toString())) {
/* 157 */         return type;
/*     */       }
/*     */     }
/* 160 */     System.out.println(new StringBuilder().append("[Stats]Column not found: ").append(column).toString());
/* 161 */     return null;
/*     */   }
/*     */ 
/*     */   public String makeMePretty()
/*     */   {
/* 168 */     String begin = toString().toLowerCase();
/* 169 */     begin = begin.replace("_", " ");
/* 170 */     return new StringBuilder().append(begin.substring(0, 1).toUpperCase()).append(begin.substring(1)).toString();
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.StatType
 * JD-Core Version:    0.6.2
 */