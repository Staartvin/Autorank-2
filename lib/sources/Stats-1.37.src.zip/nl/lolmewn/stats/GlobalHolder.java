/*    */ package nl.lolmewn.stats;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class GlobalHolder
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 13379001L;
/*    */   private final String update;
/*    */   private final String insert;
/*    */   private final Object[] updateObj;
/*    */   private final Object[] insertObj;
/*    */ 
/*    */   public GlobalHolder(String update, String insert, Object[] updateParam, Object[] insertParam)
/*    */   {
/* 21 */     this.update = update;
/* 22 */     this.insert = insert;
/* 23 */     this.updateObj = updateParam;
/* 24 */     this.insertObj = insertParam;
/*    */   }
/*    */ 
/*    */   public String getInsert() {
/* 28 */     return this.insert;
/*    */   }
/*    */ 
/*    */   public Object[] getInsertObj() {
/* 32 */     return this.insertObj;
/*    */   }
/*    */ 
/*    */   public String getUpdate() {
/* 36 */     return this.update;
/*    */   }
/*    */ 
/*    */   public Object[] getUpdateObj() {
/* 40 */     return this.updateObj;
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.GlobalHolder
 * JD-Core Version:    0.6.2
 */