/*    */ package nl.lolmewn.stats.compat;
/*    */ 
/*    */ import com.vexsoftware.votifier.model.Vote;
/*    */ import com.vexsoftware.votifier.model.VotifierEvent;
/*    */ import java.util.List;
/*    */ import nl.lolmewn.stats.Main;
/*    */ import nl.lolmewn.stats.Settings;
/*    */ import nl.lolmewn.stats.StatTypes;
/*    */ import nl.lolmewn.stats.api.Stat;
/*    */ import nl.lolmewn.stats.player.PlayerManager;
/*    */ import nl.lolmewn.stats.player.StatData;
/*    */ import nl.lolmewn.stats.player.StatsPlayer;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.World;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.EventHandler;
/*    */ import org.bukkit.event.EventPriority;
/*    */ import org.bukkit.event.Listener;
/*    */ 
/*    */ public class VotifierListener
/*    */   implements Listener
/*    */ {
/*    */   private final Main plugin;
/*    */ 
/*    */   public VotifierListener(Main plugin)
/*    */   {
/* 23 */     this.plugin = plugin;
/*    */   }
/*    */ 
/*    */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*    */   public void vote(VotifierEvent event) {
/* 28 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 29 */       Player player = this.plugin.getServer().getPlayer(event.getVote().getUsername());
/*    */       String world;
/*    */       String world;
/* 31 */       if (player == null)
/* 32 */         world = ((World)this.plugin.getServer().getWorlds().get(0)).getName();
/*    */       else {
/* 34 */         world = player.getWorld().getName();
/*    */       }
/* 36 */       this.plugin.getPlayerManager().getPlayer(event.getVote().getUsername()).getStatData((Stat)this.plugin.getStatTypes().get("Votes"), world, true).addUpdate(new Object[0], 1.0D);
/*    */     } else {
/* 38 */       this.plugin.getPlayerManager().getPlayer(event.getVote().getUsername()).getStatData((Stat)this.plugin.getStatTypes().get("Votes"), true).addUpdate(new Object[0], 1.0D);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.compat.VotifierListener
 * JD-Core Version:    0.6.2
 */