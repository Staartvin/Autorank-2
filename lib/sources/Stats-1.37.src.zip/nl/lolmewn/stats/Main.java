/*      */ package nl.lolmewn.stats;
/*      */ 
/*      */ import java.io.BufferedReader;
/*      */ import java.io.File;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStreamReader;
/*      */ import java.io.PrintStream;
/*      */ import java.io.PrintWriter;
/*      */ import java.net.ConnectException;
/*      */ import java.net.Socket;
/*      */ import java.net.UnknownHostException;
/*      */ import java.sql.Connection;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Arrays;
/*      */ import java.util.Calendar;
/*      */ import java.util.Date;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Queue;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ConcurrentLinkedQueue;
/*      */ import java.util.concurrent.TimeUnit;
/*      */ import java.util.logging.Level;
/*      */ import java.util.logging.Logger;
/*      */ import nl.lolmewn.stats.api.Stat;
/*      */ import nl.lolmewn.stats.api.StatUpdateEvent;
/*      */ import nl.lolmewn.stats.api.StatsAPI;
/*      */ import nl.lolmewn.stats.api.StatsPlayerLoadedEvent;
/*      */ import nl.lolmewn.stats.compat.VotifierListener;
/*      */ import nl.lolmewn.stats.player.PlayerManager;
/*      */ import nl.lolmewn.stats.player.StatData;
/*      */ import nl.lolmewn.stats.player.StatsPlayer;
/*      */ import nl.lolmewn.stats.signs.SignCommands;
/*      */ import nl.lolmewn.stats.signs.SignDataGetter;
/*      */ import nl.lolmewn.stats.signs.SignListener;
/*      */ import nl.lolmewn.stats.signs.SignManager;
/*      */ import nl.lolmewn.stats.snapshot.SnapshotManager;
/*      */ import org.bukkit.ChatColor;
/*      */ import org.bukkit.Location;
/*      */ import org.bukkit.OfflinePlayer;
/*      */ import org.bukkit.Server;
/*      */ import org.bukkit.World;
/*      */ import org.bukkit.command.Command;
/*      */ import org.bukkit.command.CommandSender;
/*      */ import org.bukkit.command.ConsoleCommandSender;
/*      */ import org.bukkit.configuration.file.FileConfiguration;
/*      */ import org.bukkit.configuration.file.FileConfigurationOptions;
/*      */ import org.bukkit.conversations.ConversationContext;
/*      */ import org.bukkit.craftbukkit.libs.com.google.gson.Gson;
/*      */ import org.bukkit.craftbukkit.libs.com.google.gson.GsonBuilder;
/*      */ import org.bukkit.entity.Player;
/*      */ import org.bukkit.event.EventHandler;
/*      */ import org.bukkit.event.HandlerList;
/*      */ import org.bukkit.event.Listener;
/*      */ import org.bukkit.event.player.PlayerJoinEvent;
/*      */ import org.bukkit.plugin.PluginDescriptionFile;
/*      */ import org.bukkit.plugin.PluginManager;
/*      */ import org.bukkit.plugin.ServicePriority;
/*      */ import org.bukkit.plugin.ServicesManager;
/*      */ import org.bukkit.plugin.java.JavaPlugin;
/*      */ import org.bukkit.scheduler.BukkitScheduler;
/*      */ import org.mcstats.Metrics;
/*      */ import org.mcstats.Metrics.Graph;
/*      */ import org.mcstats.Metrics.Plotter;
/*      */ 
/*      */ public class Main extends JavaPlugin
/*      */   implements Listener
/*      */ {
/*      */   private Settings settings;
/*      */   public boolean newConfig;
/*   49 */   private boolean query = false;
/*      */   private MySQL mysql;
/*      */   private StatsAPI api;
/*      */   private SignManager signManager;
/*      */   private SignDataGetter signDataGetter;
/*      */   private PlayerManager playerManager;
/*      */   private SnapshotManager snapshotManager;
/*   56 */   private String server = "stats.lolmewn.nl";
/*   57 */   private int unableToConnectToGlobal = 0;
/*   58 */   protected boolean beingConfigged = false;
/*   59 */   protected Queue<GlobalHolder> globalQueue = new ConcurrentLinkedQueue();
/*   60 */   private int queriesExecuted = 0;
/*      */   protected double newVersion;
/*   62 */   private final HashSet<String> confirm = new HashSet();
/*      */   private StatTypes statTypes;
/*   64 */   private final HashMap<String, String> awaitingPlayerLoad = new HashMap();
/*      */ 
/*  494 */   private boolean sendingStatsGlobal = false;
/*      */   private boolean working;
/*      */ 
/*      */   public void onDisable()
/*      */   {
/*   68 */     if (this.signManager != null) {
/*   69 */       this.signManager.save();
/*      */     }
/*   71 */     if ((this.mysql != null) && (!this.mysql.isFault())) {
/*   72 */       runTableUpdates();
/*   73 */       this.mysql.exit();
/*      */     }
/*   75 */     if (canSendToGlobal()) {
/*   76 */       sendStats(this.server);
/*      */     }
/*   78 */     getServer().getScheduler().cancelTasks(this);
/*      */   }
/*      */ 
/*      */   public void onEnable()
/*      */   {
/*   83 */     this.settings = new Settings(this);
/*   84 */     this.newConfig = setupConfig();
/*   85 */     checkSettings();
/*   86 */     this.settings.loadSettings();
/*   87 */     if (getServer().getPluginManager().getPlugin("Votifier") != null) {
/*   88 */       getServer().getPluginManager().registerEvents(new VotifierListener(this), this);
/*      */     }
/*   90 */     if (!this.newConfig) {
/*   91 */       this.mysql = new MySQL(this, getSettings().getDbHost(), getSettings().getDbPort(), getSettings().getDbUser(), getSettings().getDbPass(), getSettings().getDbName(), getSettings().getDbPrefix());
/*      */ 
/*   94 */       if (this.mysql.isFault()) {
/*   95 */         getLogger().severe("MySQL connection failed, disabling plugin!");
/*   96 */         getServer().getPluginManager().disablePlugin(this);
/*   97 */         return;
/*      */       }
/*      */     }
/*  100 */     getServer().getPluginManager().registerEvents(new EventListener(this), this);
/*      */ 
/*  102 */     if (!getSettings().getDisabledStats().contains("Playtime")) {
/*  103 */       schedulePlaytimeRecording();
/*      */     }
/*      */ 
/*  106 */     scheduleTableUpdates();
/*      */ 
/*  108 */     if (getSettings().isSendToGlobal()) {
/*  109 */       if (canSendToGlobal()) {
/*  110 */         debug("Setting up globalserver sending every 600 ticks.");
/*  111 */         scheduleGlobalStatsSending();
/*      */       } else {
/*  113 */         getLogger().warning("Not sending to global server due to online-mode=false");
/*  114 */         getLogger().warning("To fully use all of this plugins capabilities, please use online-mode=true");
/*      */       }
/*      */     }
/*  117 */     if (this.newConfig) {
/*  118 */       getServer().getPluginManager().registerEvents(new Listener() {
/*      */         @EventHandler
/*      */         public void join(PlayerJoinEvent e) {
/*  121 */           if (!Main.this.newConfig) {
/*  122 */             return;
/*      */           }
/*  124 */           if ((e.getPlayer().hasPermission("stats.config")) || ((e.getPlayer().isOp()) && (!Main.this.beingConfigged))) {
/*  125 */             Main.this.beingConfigged = true;
/*  126 */             Main.this.startConfigurator(e.getPlayer());
/*      */           }
/*      */         }
/*      */       }
/*      */       , this);
/*      */     }
/*      */ 
/*  131 */     startMetrics();
/*  132 */     registerAPI();
/*  133 */     this.statTypes = new StatTypes();
/*  134 */     StatType.registerTypes(this.api);
/*  135 */     this.signManager = new SignManager(this);
/*  136 */     getServer().getScheduler().runTaskLater(this, new Runnable()
/*      */     {
/*      */       public void run() {
/*  139 */         Main.this.signManager.load();
/*      */       }
/*      */     }
/*      */     , 200L);
/*      */ 
/*  142 */     this.signDataGetter = new SignDataGetter(this);
/*  143 */     this.playerManager = new PlayerManager(this);
/*  144 */     SignListener signListener = new SignListener(this);
/*  145 */     getServer().getPluginManager().registerEvents(signListener, this);
/*  146 */     if (!getSettings().isInstaUpdateSigns()) {
/*  147 */       StatUpdateEvent.getHandlerList().unregister(signListener);
/*      */     }
/*  149 */     getServer().getScheduler().runTaskTimerAsynchronously(this, this.signDataGetter, getSettings().getSignsUpdateInterval() * 20, getSettings().getSignsUpdateInterval() * 20);
/*  150 */     scheduleUpdater();
/*  151 */     if (getConfig().contains("lastJoin-lastLeaveFix")) {
/*  152 */       getConfig().set("lastJoin-lastLeaveFix", null);
/*  153 */       saveConfig();
/*      */     }
/*  155 */     if ((getSettings().isUsingBetaFunctions()) && (getSettings().createSnapshots())) {
/*  156 */       this.snapshotManager = new SnapshotManager(this, getTimeUntilNextSnapshot() / 50L, convertIntervalToLong(getSettings().getSnapshotInterval()) / 50L, convertIntervalToLong(getSettings().getSnapshotTTL()));
/*      */     }
/*      */ 
/*  161 */     getLogger().info("Version " + getDescription().getVersion() + " enabled!");
/*      */   }
/*      */ 
/*      */   protected String getBlockTable() {
/*  165 */     return getSettings().getDbPrefix() + "block";
/*      */   }
/*      */ 
/*      */   protected String getMoveTable() {
/*  169 */     return getSettings().getDbPrefix() + "move";
/*      */   }
/*      */ 
/*      */   protected String getKillTable() {
/*  173 */     return getSettings().getDbPrefix() + "kill";
/*      */   }
/*      */ 
/*      */   protected String getDeathTable() {
/*  177 */     return getSettings().getDbPrefix() + "death";
/*      */   }
/*      */ 
/*      */   protected String getPlayerTable() {
/*  181 */     return getSettings().getDbPrefix() + "player";
/*      */   }
/*      */ 
/*      */   public MySQL getMySQL() {
/*  185 */     return this.mysql;
/*      */   }
/*      */ 
/*      */   public SignManager getSignManager() {
/*  189 */     return this.signManager;
/*      */   }
/*      */ 
/*      */   public Settings getSettings() {
/*  193 */     return this.settings;
/*      */   }
/*      */ 
/*      */   public PlayerManager getPlayerManager() {
/*  197 */     return this.playerManager;
/*      */   }
/*      */ 
/*      */   private boolean setupConfig() {
/*  201 */     if (!new File(getDataFolder(), "config.yml").exists()) {
/*  202 */       saveResource("config.yml", false);
/*  203 */       return true;
/*      */     }
/*  205 */     return false;
/*      */   }
/*      */ 
/*      */   private void checkSettings() {
/*  209 */     getConfig().options().copyDefaults(true);
/*  210 */     getConfig().set("snapshots.cross-server", null);
/*  211 */     saveConfig();
/*      */   }
/*      */ 
/*      */   public void debug(String message) {
/*  215 */     if (getSettings().isDebugging())
/*  216 */       getServer().getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', "[Debug] " + message));
/*      */   }
/*      */ 
/*      */   public void debugQuery(String message)
/*      */   {
/*  221 */     if (this.query)
/*  222 */       getLogger().info("[Debug][Q] " + message);
/*      */   }
/*      */ 
/*      */   @EventHandler
/*      */   public void onPlayerLoad(StatsPlayerLoadedEvent event)
/*      */   {
/*  228 */     if (this.awaitingPlayerLoad.containsValue(event.getStatsPlayer().getPlayername()))
/*  229 */       for (String player : this.awaitingPlayerLoad.keySet()) {
/*  230 */         Player p = getServer().getPlayerExact(player);
/*  231 */         if (p == null) {
/*  232 */           this.awaitingPlayerLoad.remove(player);
/*      */         }
/*  235 */         else if (((String)this.awaitingPlayerLoad.get(player)).equalsIgnoreCase(event.getStatsPlayer().getPlayername())) {
/*  236 */           sendSomeCoolStats(p, event.getStatsPlayer().getPlayername());
/*  237 */           this.awaitingPlayerLoad.remove(player);
/*      */         }
/*      */       }
/*      */   }
/*      */ 
/*      */   public boolean onCommand(CommandSender sender, Command cmd, String arg, String[] args)
/*      */   {
/*  246 */     if (args.length == 0) {
/*  247 */       if (!(sender instanceof Player)) {
/*  248 */         sender.sendMessage("Console cannot perform this command.");
/*  249 */         return true;
/*      */       }
/*  251 */       sendSomeCoolStats(sender, sender.getName());
/*  252 */       return true;
/*      */     }
/*  254 */     if (args[0].equals("toggle")) {
/*  255 */       if (!sender.hasPermission("stats.toggle")) {
/*  256 */         sender.sendMessage(ChatColor.RED + "You do not have permissions to do this!");
/*  257 */         return true;
/*      */       }
/*  259 */       if (args.length == 1) {
/*  260 */         sender.sendMessage("USAGE: /stats toggle <debug|query>");
/*  261 */         return true;
/*      */       }
/*  263 */       if (args[1].equals("debug")) {
/*  264 */         getSettings().setDebugging(!getSettings().isDebugging());
/*  265 */         sender.sendMessage("Debug value set to: " + getSettings().isDebugging());
/*  266 */         return true;
/*      */       }
/*  268 */       if (args[1].equals("query")) {
/*  269 */         this.query = (!this.query);
/*  270 */         sender.sendMessage("Query debug value set to: " + this.query);
/*  271 */         return true;
/*      */       }
/*      */     }
/*  274 */     if (args[0].equalsIgnoreCase("sign")) {
/*  275 */       return new SignCommands().onCommand(this, sender, args);
/*      */     }
/*  277 */     if (args[0].equalsIgnoreCase("sendStats")) {
/*  278 */       if (!sender.hasPermission("stats.sendGlobal")) {
/*  279 */         sender.sendMessage(ChatColor.RED + "You do not have permissions to do this!");
/*  280 */         return true;
/*      */       }
/*  282 */       sender.sendMessage(sendStats(this.server));
/*  283 */       return true;
/*      */     }
/*  285 */     if (args[0].equals("reload")) {
/*  286 */       if (!sender.hasPermission("stats.reload")) {
/*  287 */         sender.sendMessage(ChatColor.RED + "You do not have permissions to do this!");
/*  288 */         return true;
/*      */       }
/*      */ 
/*  291 */       sender.sendMessage(ChatColor.BLUE + "Sending all remaining stats...");
/*  292 */       runTableUpdates();
/*  293 */       if (canSendToGlobal()) {
/*  294 */         sender.sendMessage(ChatColor.BLUE + "Sending remaining data to global server...");
/*  295 */         sender.sendMessage(ChatColor.GREEN + sendStats(this.server));
/*      */       }
/*  297 */       sender.sendMessage(ChatColor.BLUE + "Reloading plugin...");
/*  298 */       Settings set = new Settings(this);
/*  299 */       set.loadSettings();
/*  300 */       this.settings = set;
/*  301 */       this.mysql.exit();
/*  302 */       this.mysql = new MySQL(this, set.getDbHost(), set.getDbPort(), set.getDbUser(), set.getDbPass(), set.getDbName(), set.getDbPrefix());
/*      */ 
/*  305 */       if (this.mysql.isFault()) {
/*  306 */         getLogger().severe("MySQL connection failed, disabling plugin!");
/*  307 */         sender.sendMessage(ChatColor.RED + "MySQL connection failed, disabling plugin!");
/*  308 */         getServer().getPluginManager().disablePlugin(this);
/*  309 */         return true;
/*      */       }
/*  311 */       sender.sendMessage(ChatColor.GREEN + "Plugin reloaded succesfully!");
/*  312 */       return true;
/*      */     }
/*  314 */     if (args[0].equalsIgnoreCase("debug")) {
/*  315 */       if (!sender.hasPermission("stats.debug")) {
/*  316 */         sender.sendMessage(ChatColor.RED + "You do not have permissions to do this!");
/*  317 */         return true;
/*      */       }
/*  319 */       if (args.length == 1) {
/*  320 */         sender.sendMessage("Correct usage: /stats debug global");
/*  321 */         return true;
/*      */       }
/*  323 */       if (args[1].equalsIgnoreCase("me")) {
/*  324 */         sender.sendMessage("Your data has been print in the console.");
/*  325 */         StatsPlayer p = getPlayerManager().getPlayer(sender.getName());
/*  326 */         getLogger().info("[Debug] hasPlayerRow: " + p.hasPlayerDatabaseRow());
/*  327 */         getLogger().info("[Debug] Stats ------------");
/*      */         Iterator i$;
/*      */         StatData statData;
/*      */         Iterator i$;
/*  328 */         if (getSettings().isUsingBetaFunctions()) {
/*  329 */           for (String world : p.getWorlds()) {
/*  330 */             getLogger().info("[Debug]  world: " + world);
/*  331 */             for (i$ = p.getStatsForWorld(world).iterator(); i$.hasNext(); ) { statData = (StatData)i$.next();
/*  332 */               getLogger().info("[Debug]    type: " + statData.getStat().getName());
/*  333 */               getLogger().info("[Debug]      data: ");
/*  334 */               for (Object[] vars : statData.getAllVariables()) {
/*  335 */                 getLogger().info("[Debug]        vars: " + Arrays.toString(vars) + " UpdateValue: " + statData.getUpdateValue(vars, false));
/*  336 */                 getLogger().info("[Debug]        vars: " + Arrays.toString(vars) + " CurrentValue: " + statData.getValue(vars));
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */         else
/*  342 */           for (i$ = p.getStats().iterator(); i$.hasNext(); ) { statData = (StatData)i$.next();
/*  343 */             getLogger().info("[Debug]  type: " + statData.getStat().getName());
/*  344 */             getLogger().info("[Debug]    data: ");
/*  345 */             for (Object[] vars : statData.getAllVariables()) {
/*  346 */               getLogger().info("[Debug]      vars: " + Arrays.toString(vars) + " UpdateValue: " + statData.getUpdateValue(vars, false));
/*  347 */               getLogger().info("[Debug]      vars: " + Arrays.toString(vars) + " CurrentValue: " + statData.getValue(vars));
/*      */             }
/*      */           }
/*      */         StatData statData;
/*  353 */         return true;
/*      */       }
/*  355 */       this.server = args[1];
/*  356 */       sender.sendMessage("Global server set to " + this.server);
/*  357 */       return true;
/*      */     }
/*  359 */     if (args[0].equalsIgnoreCase("reset")) {
/*  360 */       if (args.length == 1) {
/*  361 */         if (!sender.hasPermission("stats.reset.self")) {
/*  362 */           sender.sendMessage(ChatColor.RED + "You do not have permissions to do this!");
/*  363 */           return true;
/*      */         }
/*  365 */         if (!this.confirm.contains(sender.getName())) {
/*  366 */           this.confirm.add(sender.getName());
/*  367 */           sender.sendMessage(ChatColor.BLUE + "Please confirm you really want to do this by performing the command again");
/*  368 */           final String name = sender.getName();
/*  369 */           getServer().getScheduler().runTaskLater(this, new Runnable()
/*      */           {
/*      */             public void run() {
/*  372 */               if (Main.this.confirm.contains(name)) {
/*  373 */                 Main.this.confirm.remove(name);
/*  374 */                 Player p = Main.this.getServer().getPlayer(name);
/*  375 */                 if (p != null)
/*  376 */                   p.sendMessage(ChatColor.RED + "Stats reset command expired.");
/*      */               }
/*      */             }
/*      */           }
/*      */           , 200L);
/*      */ 
/*  381 */           return true;
/*      */         }
/*  383 */         StatsPlayer player = getPlayerManager().getPlayer(sender.getName());
/*  384 */         for (Iterator i$ = player.getStats().iterator(); i$.hasNext(); ) { statData = (StatData)i$.next();
/*  385 */           for (Object[] vars : statData.getAllVariables()) {
/*  386 */             if (statData.getStat().equals(getStatTypes().get("Lastjoin")))
/*  387 */               statData.setCurrentValue(vars, System.currentTimeMillis());
/*      */             else {
/*  389 */               statData.setCurrentValue(vars, 0.0D);
/*      */             }
/*  391 */             statData.forceUpdate(vars);
/*      */           }
/*      */         }
/*      */         StatData statData;
/*  394 */         Connection con = getMySQL().getConnection();
/*  395 */         String[] tables = { "player", "death", "kill", "move", "block" };
/*  396 */         for (String table : tables)
/*      */           try {
/*  398 */             PreparedStatement st = con.prepareStatement("DELETE FROM " + getSettings().getDbPrefix() + table + " WHERE player=?");
/*  399 */             st.setString(1, player.getPlayername());
/*  400 */             st.executeUpdate();
/*  401 */             st.close();
/*      */           } catch (SQLException ex) {
/*  403 */             Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
/*      */           }
/*      */         try
/*      */         {
/*  407 */           con.close();
/*      */         } catch (SQLException ex) {
/*  409 */           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
/*      */         }
/*  411 */         player.setHasPlayerDatabaseRow(false);
/*  412 */         sender.sendMessage(ChatColor.GREEN + "Your stats have been reset!");
/*  413 */         this.confirm.remove(sender.getName());
/*  414 */         return true;
/*      */       }
/*  416 */       if (!sender.hasPermission("stats.reset.other")) {
/*  417 */         sender.sendMessage(ChatColor.RED + "You do not have permissions to do this!");
/*  418 */         return true;
/*      */       }
/*  420 */       Player find = getServer().getPlayer(args[1]);
/*  421 */       if (find == null) {
/*  422 */         sender.sendMessage(ChatColor.RED + "I'm sorry, but that player is offline!");
/*  423 */         return true;
/*      */       }
/*  425 */       if (!this.confirm.contains(sender.getName())) {
/*  426 */         this.confirm.add(sender.getName());
/*  427 */         sender.sendMessage(ChatColor.BLUE + "Please confirm you really want to do this by performing the command again");
/*  428 */         final String name = sender.getName();
/*  429 */         getServer().getScheduler().runTaskLater(this, new Runnable()
/*      */         {
/*      */           public void run() {
/*  432 */             if (Main.this.confirm.contains(name)) {
/*  433 */               Main.this.confirm.remove(name);
/*  434 */               Player p = Main.this.getServer().getPlayer(name);
/*  435 */               if (p != null)
/*  436 */                 p.sendMessage(ChatColor.RED + "Stats reset command expired.");
/*      */             }
/*      */           }
/*      */         }
/*      */         , 200L);
/*      */ 
/*  441 */         return true;
/*      */       }
/*  443 */       StatsPlayer player = getPlayerManager().hasPlayer(find.getName()) ? getPlayerManager().getPlayer(find.getName()) : null;
/*  444 */       if (player == null) {
/*  445 */         sender.sendMessage("Sorry, but this player doesn't seem to have any stats.");
/*  446 */         return true;
/*      */       }
/*  448 */       for (Iterator i$ = player.getStats().iterator(); i$.hasNext(); ) { statData = (StatData)i$.next();
/*  449 */         for (Object[] vars : statData.getAllVariables()) {
/*  450 */           if (statData.getStat().equals(getStatTypes().get("Lastjoin")))
/*  451 */             statData.setCurrentValue(vars, System.currentTimeMillis());
/*      */           else {
/*  453 */             statData.setCurrentValue(vars, 0.0D);
/*      */           }
/*  455 */           statData.forceUpdate(vars);
/*      */         }
/*      */       }
/*      */       StatData statData;
/*  458 */       Connection con = getMySQL().getConnection();
/*  459 */       String[] tables = { "player", "death", "kill", "move", "block" };
/*  460 */       for (String table : tables)
/*      */         try {
/*  462 */           PreparedStatement st = con.prepareStatement("DELETE FROM " + getSettings().getDbPrefix() + table + " WHERE player=?");
/*  463 */           st.setString(1, player.getPlayername());
/*  464 */           st.executeUpdate();
/*  465 */           st.close();
/*      */         } catch (SQLException ex) {
/*  467 */           Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
/*      */         }
/*      */       try
/*      */       {
/*  471 */         con.close();
/*      */       } catch (SQLException ex) {
/*  473 */         Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
/*      */       }
/*  475 */       player.setHasPlayerDatabaseRow(false);
/*  476 */       sender.sendMessage(ChatColor.GREEN + find.getName() + " has been reset!");
/*  477 */       this.confirm.remove(sender.getName());
/*  478 */       return true;
/*      */     }
/*  480 */     if (sender.hasPermission("stats.view.others")) {
/*  481 */       Player find = getServer().getPlayer(args[0]);
/*  482 */       if (find == null) {
/*  483 */         this.awaitingPlayerLoad.put(sender.getName(), args[0]);
/*  484 */         getPlayerManager().loadPlayerAsync(args[0]);
/*  485 */         return true;
/*      */       }
/*  487 */       sendSomeCoolStats(sender, find.getName());
/*  488 */       return true;
/*      */     }
/*  490 */     sender.sendMessage(ChatColor.RED + "Sorry, you do not have permissions to view someone elses stats!");
/*  491 */     return true;
/*      */   }
/*      */ 
/*      */   private String sendStats(String server)
/*      */   {
/*  497 */     if (this.sendingStatsGlobal) {
/*  498 */       return "Stats already sending, cancelling.";
/*      */     }
/*  500 */     Socket soc = null;
/*      */     try {
/*  502 */       debug("Connecting to global server...");
/*  503 */       soc = new Socket(server, 1888);
/*  504 */       this.sendingStatsGlobal = true;
/*  505 */       debug("Connected to global server.");
/*  506 */       PrintWriter out = new PrintWriter(soc.getOutputStream(), true);
/*  507 */       BufferedReader in = new BufferedReader(new InputStreamReader(soc.getInputStream()));
/*  508 */       out.println("CPV4");
/*  509 */       if (!in.readLine().equalsIgnoreCase("ready for servername")) {
/*  510 */         debug("Global server didn't want servername :'(");
/*      */       }
/*  512 */       out.println(getServer().getServerName());
/*  513 */       if (!in.readLine().equalsIgnoreCase("ready for serverport")) {
/*  514 */         debug("Global server didn't want serverport :'(");
/*      */       }
/*  516 */       out.println(getServer().getPort());
/*  517 */       if (this.globalQueue.isEmpty()) {
/*  518 */         out.println("ping");
/*  519 */         in.close();
/*  520 */         out.flush();
/*  521 */         out.close();
/*  522 */         soc.close();
/*  523 */         this.sendingStatsGlobal = false;
/*  524 */         return "Just pinged.";
/*      */       }
/*      */       Gson g;
/*  526 */       while (!this.globalQueue.isEmpty()) {
/*  527 */         GlobalHolder h = (GlobalHolder)this.globalQueue.poll();
/*  528 */         g = new GsonBuilder().setDateFormat("yyy-MM-dd hh:mm:ss.S").create();
/*  529 */         String send = g.toJson(h);
/*  530 */         out.println(send);
/*      */       }
/*  532 */       out.println("end");
/*  533 */       String read = in.readLine();
/*  534 */       this.unableToConnectToGlobal = 0;
/*  535 */       in.close();
/*  536 */       out.flush();
/*  537 */       out.close();
/*  538 */       this.sendingStatsGlobal = false;
/*  539 */       return read;
/*      */     }
/*      */     catch (UnknownHostException ex)
/*      */     {
/*  543 */       getLogger().warning("Couldn't connect to global server! Your DNS lookup might be broken or inactive!");
/*      */     } catch (ConnectException ex) {
/*  545 */       if ((this.unableToConnectToGlobal == 0) || (this.unableToConnectToGlobal % 60 == 0)) {
/*  546 */         getLogger().warning("Couldn't connect to global server! Maybe it's offline...");
/*      */       }
/*  548 */       this.unableToConnectToGlobal += 1;
/*      */     } catch (IOException ex) {
/*  550 */       if ((this.unableToConnectToGlobal == 0) || (this.unableToConnectToGlobal % 60 == 0)) {
/*  551 */         getLogger().warning("Couldn't connect to global server! Maybe it's offline...");
/*      */       }
/*  553 */       this.unableToConnectToGlobal += 1;
/*      */     } catch (NullPointerException ex) {
/*  555 */       if ((this.unableToConnectToGlobal == 0) || (this.unableToConnectToGlobal % 60 == 0)) {
/*  556 */         getLogger().warning("Couldn't connect to global server! Maybe it's offline...");
/*      */       }
/*  558 */       this.unableToConnectToGlobal += 1;
/*      */     } finally {
/*  560 */       this.sendingStatsGlobal = false;
/*      */       try {
/*  562 */         if (soc != null)
/*  563 */           soc.close();
/*      */       }
/*      */       catch (IOException ex) {
/*      */       }
/*      */     }
/*  568 */     return "Something failed while trying to send stats to global server!";
/*      */   }
/*      */ 
/*      */   private void runTableUpdates()
/*      */   {
/*  573 */     if (this.working) {
/*  574 */       debug("stats were still sending, postphoning.");
/*  575 */       return;
/*      */     }
/*  577 */     this.working = true;
/*  578 */     long start = System.nanoTime();
/*  579 */     Connection con = getMySQL().getConnection();
/*      */     try {
/*  581 */       executeNewQueue(con);
/*      */     } catch (Exception e) {
/*  583 */       System.out.println("Exception happened: " + e.getMessage());
/*  584 */       e.printStackTrace();
/*  585 */       this.working = false;
/*      */     }
/*  587 */     this.working = false;
/*  588 */     if (!canSendToGlobal())
/*  589 */       this.globalQueue.clear();
/*      */     try
/*      */     {
/*  592 */       if (con != null)
/*  593 */         con.close();
/*      */     }
/*      */     catch (SQLException ex) {
/*  596 */       Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
/*      */     }
/*  598 */     double taken = (System.nanoTime() - start) / 1000000L;
/*  599 */     if (taken != 0.0D)
/*  600 */       debug("Time taken sending table updates: " + taken);
/*      */   }
/*      */ 
/*      */   private void executeNewQueue(Connection con)
/*      */   {
/*  605 */     boolean globalServer = canSendToGlobal();
/*      */     try {
/*  607 */       con.setAutoCommit(false);
/*  608 */       for (StatsPlayer player : getPlayerManager().getPlayers())
/*  609 */         if (!player.isTemp())
/*      */         {
/*      */           ConcurrentHashMap stats;
/*      */           Iterator i$;
/*      */           String world;
/*  612 */           if (getSettings().isUsingBetaFunctions())
/*      */           {
/*      */             try {
/*  615 */               PreparedStatement select = con.prepareStatement("SELECT counter FROM " + getSettings().getDbPrefix() + "player WHERE player=? AND world=?");
/*  616 */               PreparedStatement insert = con.prepareStatement("INSERT INTO " + getSettings().getDbPrefix() + "player (player, world) VALUES (?, ?)");
/*  617 */               insert.setString(1, player.getPlayername());
/*  618 */               for (String world : player.getWorldStats().keySet()) {
/*  619 */                 select.setString(1, player.getPlayername());
/*  620 */                 select.setString(2, world);
/*  621 */                 ResultSet set = select.executeQuery();
/*  622 */                 if ((set != null) && (set.next())) {
/*  623 */                   set.close();
/*      */                 }
/*      */                 else {
/*  626 */                   if (set != null) {
/*  627 */                     set.close();
/*      */                   }
/*  629 */                   insert.setString(2, world);
/*  630 */                   insert.addBatch();
/*      */                 }
/*      */               }
/*  632 */               insert.executeBatch();
/*  633 */               con.commit();
/*  634 */               insert.close();
/*      */             } catch (Exception e) {
/*  636 */               if (!e.getMessage().contains("Duplicate entry"))
/*  637 */                 Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, e);
/*      */               else {
/*  639 */                 debug("Attempted to make duplicate entry, might want to investigate - Player: " + player.getPlayername());
/*      */               }
/*      */             }
/*  642 */             stats = player.getWorldStats();
/*  643 */             for (i$ = stats.keySet().iterator(); i$.hasNext(); ) { world = (String)i$.next();
/*  644 */               for (StatData statData : ((ConcurrentHashMap)stats.get(world)).values())
/*      */                 try {
/*  646 */                   PreparedStatement st = null;
/*  647 */                   List updateVars = new ArrayList(statData.getUpdateVariables());
/*  648 */                   for (Object[] updateVar : updateVars) {
/*  649 */                     debug("Updating " + player.getPlayername() + " world " + world + " stat " + statData.getStat().getName() + " vars " + Arrays.toString(updateVar));
/*  650 */                     if (st == null) {
/*  651 */                       String updateQuery = statData.getStat().getUpdate();
/*  652 */                       updateQuery = updateQuery.replace("PREFIX", getSettings().getDbPrefix());
/*  653 */                       if (updateQuery.contains(getSettings().getDbPrefix() + "player")) {
/*  654 */                         updateQuery = updateQuery + " AND world=?";
/*  655 */                         if (getSettings().createSnapshots()) {
/*  656 */                           updateQuery = updateQuery + "AND snapshot_name=?";
/*      */                         }
/*      */                       }
/*  659 */                       st = con.prepareStatement(updateQuery);
/*      */                     }
/*      */                     Object updateValue;
/*  662 */                     if ((statData.getStat().equals(getStatTypes().get("Lastjoin"))) || (statData.getStat().equals(getStatTypes().get("Lastleave")))) {
/*  663 */                       Object updateValue = new Timestamp(()statData.getValue(updateVar));
/*  664 */                       st.setObject(1, updateValue);
/*  665 */                       statData.removeHasUpdate(new Object[0]);
/*      */                     } else {
/*  667 */                       updateValue = Double.valueOf(statData.getUpdateValue(updateVar, true));
/*  668 */                       st.setObject(1, updateValue);
/*      */                     }
/*  670 */                     st.setObject(2, player.getPlayername());
/*  671 */                     for (int i = 0; i < updateVar.length; i++) {
/*  672 */                       Object o = updateVar[i];
/*  673 */                       st.setObject(i + 3, o);
/*      */                     }
/*  675 */                     if (statData.getStat().getUpdate().contains("PREFIXplayer")) {
/*  676 */                       st.setString(updateVar.length + 3, world);
/*  677 */                       if (getSettings().createSnapshots()) {
/*  678 */                         st.setString(updateVar.length + 4, "main_snapshot");
/*      */                       }
/*      */                     }
/*  681 */                     if (globalServer) {
/*  682 */                       String updateQuery = statData.getStat().getUpdate().replaceFirst("PREFIX", "\\$\\$PREFIX");
/*  683 */                       String insertQuery = statData.getStat().getInsert().replaceFirst("PREFIX", "\\$\\$PREFIX");
/*  684 */                       Object[] updateParameters = new Object[st.getParameterMetaData().getParameterCount()];
/*  685 */                       updateParameters[0] = updateValue;
/*  686 */                       updateParameters[1] = player.getPlayername();
/*  687 */                       System.arraycopy(updateVar, 0, updateParameters, 2, updateVar.length);
/*  688 */                       Object[] insertParameters = new Object[st.getParameterMetaData().getParameterCount()];
/*  689 */                       insertParameters[0] = player.getPlayername();
/*  690 */                       System.arraycopy(updateVar, 0, insertParameters, 1, updateVar.length);
/*  691 */                       insertParameters[(updateVar.length + 1)] = updateValue;
/*  692 */                       this.globalQueue.add(new GlobalHolder(updateQuery, insertQuery, updateParameters, insertParameters));
/*      */                     }
/*  694 */                     debugQuery("Adding " + st.toString());
/*  695 */                     st.addBatch();
/*      */                   }
/*  697 */                   if (st != null) {
/*  698 */                     int[] updated = st.executeBatch();
/*  699 */                     st.close();
/*  700 */                     for (int i = 0; i < updated.length; i++)
/*  701 */                       if (updated[i] != -2)
/*      */                       {
/*  704 */                         if (updated[i] == 0)
/*      */                         {
/*  707 */                           if (statData.getStat().getUpdate().contains("PREFIXplayer")) {
/*  708 */                             getLogger().warning("Attempted to insert player into table while one should already exist!");
/*      */                           }
/*      */                           else {
/*  711 */                             String insertQuery = statData.getStat().getInsert().replaceFirst("PREFIX", getSettings().getDbPrefix());
/*  712 */                             if (getSettings().isUsingBetaFunctions()) {
/*  713 */                               String[] split = insertQuery.split("\\)");
/*  714 */                               if (getSettings().createSnapshots())
/*  715 */                                 insertQuery = split[0] + ", world, snapshot_name, snapshot_time)" + split[1] + ", ?, ?, ?)";
/*      */                               else {
/*  717 */                                 insertQuery = split[0] + ", world)" + split[1] + ", ?)";
/*      */                               }
/*      */                             }
/*      */ 
/*  721 */                             st = con.prepareStatement(insertQuery);
/*  722 */                             Object[] vars = (Object[])updateVars.get(i);
/*  723 */                             st.setObject(1, player.getPlayername());
/*  724 */                             for (int j = 0; j < vars.length; j++) {
/*  725 */                               st.setObject(j + 2, vars[j]);
/*      */                             }
/*  727 */                             st.setObject(vars.length + 2, Double.valueOf(statData.getValue(vars)));
/*  728 */                             if (getSettings().isUsingBetaFunctions()) {
/*  729 */                               st.setObject(vars.length + 3, world);
/*  730 */                               if (getSettings().createSnapshots()) {
/*  731 */                                 st.setObject(vars.length + 4, "main_snapshot");
/*  732 */                                 st.setObject(vars.length + 5, new Timestamp(System.currentTimeMillis()));
/*      */                               }
/*      */                             }
/*  735 */                             debug("Inserting " + st.toString());
/*  736 */                             st.executeUpdate();
/*  737 */                             st.close();
/*      */                           }
/*      */                         }
/*      */                       }
/*      */                   }
/*      */                 } catch (Exception e) {
/*      */                 } }
/*      */           } else {
/*  745 */             if (!player.hasPlayerDatabaseRow()) {
/*  746 */               player.setHasPlayerDatabaseRow(true);
/*      */               try {
/*  748 */                 PreparedStatement st = con.prepareStatement("INSERT INTO " + getSettings().getDbPrefix() + "player (player) VALUES (?)");
/*  749 */                 st.setObject(1, player.getPlayername());
/*  750 */                 st.executeUpdate();
/*  751 */                 con.commit();
/*  752 */                 st.close();
/*      */               } catch (Exception e) {
/*  754 */                 if (!e.getMessage().contains("Duplicate entry"))
/*  755 */                   Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, e);
/*      */                 else {
/*  757 */                   debug("Attempted to make duplicate entry, might want to investigate - Player: " + player.getPlayername());
/*      */                 }
/*      */               }
/*      */             }
/*  761 */             for (StatData statData : player.getStats())
/*      */               try {
/*  763 */                 PreparedStatement st = null;
/*  764 */                 List updateVars = new ArrayList(statData.getUpdateVariables());
/*  765 */                 for (Object[] updateVar : updateVars) {
/*  766 */                   if (st == null) {
/*  767 */                     String updateQuery = statData.getStat().getUpdate();
/*  768 */                     updateQuery = updateQuery.replace("PREFIX", getSettings().getDbPrefix());
/*  769 */                     st = con.prepareStatement(updateQuery);
/*      */                   }
/*      */                   Object updateValue;
/*  772 */                   if ((statData.getStat().equals(getStatTypes().get("Lastjoin"))) || (statData.getStat().equals(getStatTypes().get("Lastleave")))) {
/*  773 */                     Object updateValue = new Timestamp(()statData.getValue(updateVar));
/*  774 */                     st.setObject(1, updateValue);
/*  775 */                     statData.removeHasUpdate(new Object[0]);
/*      */                   } else {
/*  777 */                     updateValue = Double.valueOf(statData.getUpdateValue(updateVar, true));
/*  778 */                     st.setObject(1, updateValue);
/*      */                   }
/*  780 */                   st.setObject(2, player.getPlayername());
/*  781 */                   for (int i = 0; i < updateVar.length; i++) {
/*  782 */                     Object o = updateVar[i];
/*  783 */                     st.setObject(i + 3, o);
/*      */                   }
/*  785 */                   if (globalServer) {
/*  786 */                     String updateQuery = statData.getStat().getUpdate().replaceFirst("PREFIX", "\\$\\$PREFIX");
/*  787 */                     String insertQuery = statData.getStat().getInsert().replaceFirst("PREFIX", "\\$\\$PREFIX");
/*  788 */                     Object[] updateParameters = new Object[st.getParameterMetaData().getParameterCount()];
/*  789 */                     updateParameters[0] = updateValue;
/*  790 */                     updateParameters[1] = player.getPlayername();
/*  791 */                     System.arraycopy(updateVar, 0, updateParameters, 2, updateVar.length);
/*  792 */                     Object[] insertParameters = new Object[st.getParameterMetaData().getParameterCount()];
/*  793 */                     insertParameters[0] = player.getPlayername();
/*  794 */                     System.arraycopy(updateVar, 0, insertParameters, 1, updateVar.length);
/*  795 */                     insertParameters[(updateVar.length + 1)] = updateValue;
/*  796 */                     this.globalQueue.add(new GlobalHolder(updateQuery, insertQuery, updateParameters, insertParameters));
/*      */                   }
/*  798 */                   debug("Adding " + st.toString());
/*  799 */                   st.addBatch();
/*      */                 }
/*  801 */                 if (st != null) {
/*  802 */                   int[] updated = st.executeBatch();
/*  803 */                   st.close();
/*  804 */                   for (int i = 0; i < updated.length; i++)
/*  805 */                     if (updated[i] != -2)
/*      */                     {
/*  808 */                       if (updated[i] == 0)
/*      */                       {
/*  811 */                         if (statData.getStat().getUpdate().contains("PREFIXplayer")) {
/*  812 */                           getLogger().warning("Attempted to insert player into table while one should already exist!");
/*      */                         }
/*      */                         else {
/*  815 */                           st = con.prepareStatement(statData.getStat().getInsert().replaceFirst("PREFIX", getSettings().getDbPrefix()));
/*  816 */                           Object[] vars = (Object[])updateVars.get(i);
/*  817 */                           st.setObject(1, player.getPlayername());
/*  818 */                           for (int j = 0; j < vars.length; j++) {
/*  819 */                             st.setObject(j + 2, vars[j]);
/*      */                           }
/*  821 */                           st.setObject(vars.length + 2, Double.valueOf(statData.getValue(vars)));
/*  822 */                           debug("Inserting " + st.toString());
/*  823 */                           st.executeUpdate();
/*  824 */                           st.close();
/*      */                         }
/*      */                       }
/*      */                     }
/*      */                 }
/*      */               } catch (Exception e) {  }
/*      */ 
/*      */           }
/*  831 */           if (getServer().getPlayerExact(player.getPlayername()) == null)
/*  832 */             getPlayerManager().unloadPlayer(player.getPlayername());
/*      */         }
/*      */     }
/*      */     catch (SQLException ex) {
/*  836 */       Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
/*      */     } finally {
/*      */       try {
/*  839 */         if ((con != null) && (!con.getAutoCommit()))
/*  840 */           con.commit();
/*      */       }
/*      */       catch (SQLException ex) {
/*  843 */         Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected boolean setupMySQL(ConversationContext cc) {
/*  849 */     this.mysql = new MySQL(this, (String)cc.getSessionData("MySQL-Host"), Integer.parseInt((String)cc.getSessionData("MySQL-Port")), (String)cc.getSessionData("MySQL-User"), (String)cc.getSessionData("MySQL-Pass"), (String)cc.getSessionData("MySQL-Database"), "Stats_");
/*      */ 
/*  856 */     return !this.mysql.isFault();
/*      */   }
/*      */ 
/*      */   protected void startConfigurator(Player p) {
/*  860 */     new Configurator(this, p);
/*      */   }
/*      */ 
/*      */   protected void saveValues(ConversationContext cc) {
/*  864 */     getConfig().set("MySQL-Host", (String)cc.getSessionData("MySQL-Host"));
/*  865 */     getConfig().set("MySQL-Port", cc.getSessionData("MySQL-Port"));
/*  866 */     getConfig().set("MySQL-User", (String)cc.getSessionData("MySQL-User"));
/*  867 */     getConfig().set("MySQL-Pass", (String)cc.getSessionData("MySQL-Pass"));
/*  868 */     getConfig().set("MySQL-Database", (String)cc.getSessionData("MySQL-Database"));
/*  869 */     saveConfig();
/*      */   }
/*      */ 
/*      */   private void sendSomeCoolStats(CommandSender sender, String from) {
/*  873 */     StatsPlayer lookup = getPlayerManager().getPlayer(from);
/*      */     String world;
/*      */     String world;
/*  875 */     if ((sender instanceof Player)) {
/*  876 */       world = ((Player)sender).getWorld().getName();
/*      */     }
/*      */     else
/*      */     {
/*      */       String world;
/*  877 */       if (getServer().getOfflinePlayer(lookup.getPlayername()).isOnline())
/*  878 */         world = getServer().getPlayerExact(lookup.getPlayername()).getWorld().getName();
/*      */       else
/*  880 */         world = ((World)getServer().getWorlds().get(0)).getName();
/*      */     }
/*  882 */     for (String type : getSettings().getCommand()) {
/*  883 */       Stat stat = (Stat)getStatTypes().get(type);
/*  884 */       if (stat == null) {
/*  885 */         stat = (Stat)getStatTypes().get((type.substring(0, 1).toUpperCase() + type.substring(1).toLowerCase()).replace("_", " "));
/*  886 */         if (stat == null)
/*  887 */           getLogger().warning("Wrongly configured, looking for Stat " + type + ", but it doesn't exist.");
/*      */       }
/*      */       else
/*      */       {
/*  891 */         String prettyName = (type.substring(0, 1).toUpperCase() + type.substring(1).toLowerCase()).replace("_", " ");
/*  892 */         if (((getSettings().isUsingBetaFunctions()) && (!lookup.hasStat(stat, world))) || ((!getSettings().isUsingBetaFunctions()) && (!lookup.hasStat(stat)))) {
/*  893 */           debug("Couldn't find StatData for " + type);
/*      */         }
/*      */         else {
/*  896 */           StatData statData = getSettings().isUsingBetaFunctions() ? lookup.getStatData(stat, world, true) : lookup.getStatData(stat, true);
/*  897 */           if (stat.getName().equals("Move")) {
/*  898 */             double value = 0.0D;
/*  899 */             for (Object[] vars : statData.getAllVariables()) {
/*  900 */               value += statData.getValue(vars);
/*      */             }
/*  902 */             sender.sendMessage(ChatColor.LIGHT_PURPLE + prettyName + ": " + ChatColor.GREEN + value);
/*      */           }
/*  904 */           else if ((stat.getName().equals("Lastjoin")) || (stat.getName().equals("Lastleave"))) {
/*  905 */             SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss,SSS", Locale.ENGLISH);
/*  906 */             sender.sendMessage(ChatColor.LIGHT_PURPLE + prettyName + ": " + ChatColor.GREEN + sdf.format(new Date(()statData.getValue(new Object[0]))));
/*      */           }
/*  908 */           else if (stat.getName().equals("Playtime")) {
/*  909 */             int playTimeSeconds = (int)statData.getValue(new Object[0]);
/*  910 */             String playtime = String.format("%d days, %02d hours, %02d mins, %02d secs", new Object[] { Long.valueOf(TimeUnit.SECONDS.toDays(playTimeSeconds)), Long.valueOf(TimeUnit.SECONDS.toHours(playTimeSeconds) - TimeUnit.SECONDS.toDays(playTimeSeconds) * 24L), Long.valueOf(TimeUnit.SECONDS.toMinutes(playTimeSeconds) - TimeUnit.SECONDS.toHours(playTimeSeconds) * 60L), Long.valueOf(TimeUnit.SECONDS.toSeconds(playTimeSeconds) - TimeUnit.SECONDS.toMinutes(playTimeSeconds) * 60L) });
/*      */ 
/*  915 */             sender.sendMessage(ChatColor.LIGHT_PURPLE + "Playtime: " + ChatColor.GREEN + playtime);
/*      */           }
/*      */           else {
/*  918 */             long v = 0L;
/*  919 */             for (Object[] vars : statData.getAllVariables()) {
/*  920 */               v = ()(v + statData.getValue(vars));
/*      */             }
/*  922 */             sender.sendMessage(ChatColor.LIGHT_PURPLE + prettyName + ": " + ChatColor.GREEN + v); } 
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*  928 */   private void registerAPI() { this.api = new StatsAPI(this);
/*  929 */     getServer().getServicesManager().register(StatsAPI.class, this.api, this, ServicePriority.Low); }
/*      */ 
/*      */   public StatsAPI getAPI()
/*      */   {
/*  933 */     return this.api;
/*      */   }
/*      */ 
/*      */   protected boolean canSendToGlobal() {
/*  937 */     return (getSettings().isSendToGlobal()) && ((getServer().getOnlineMode()) || (getServer().getIp().equals("127.0.0.1")) || (getServer().getIp().equals("localhost")));
/*      */   }
/*      */ 
/*      */   public void configComplete() {
/*  941 */     for (Player p : getServer().getOnlinePlayers()) {
/*  942 */       getPlayerManager().addPlayer(p.getName(), new StatsPlayer(this, p.getName(), true));
/*  943 */       getPlayerManager().loadPlayerAsync(p.getName());
/*      */     }
/*      */   }
/*      */ 
/*      */   private void scheduleUpdater()
/*      */   {
/*  951 */     final Main plugin = this;
/*  952 */     if (!getSettings().isUpdating()) {
/*  953 */       return;
/*      */     }
/*  955 */     getServer().getScheduler().runTaskTimerAsynchronously(this, new Runnable()
/*      */     {
/*      */       public void run() {
/*  958 */         new Updater(plugin, 43564, plugin.getFile(), Updater.UpdateType.DEFAULT, false);
/*      */       }
/*      */     }
/*      */     , 0L, 72000L);
/*      */   }
/*      */ 
/*      */   private void schedulePlaytimeRecording()
/*      */   {
/*  964 */     getServer().getScheduler().scheduleSyncRepeatingTask(this, new Runnable()
/*      */     {
/*      */       public void run() {
/*  967 */         for (Player p : Main.this.getServer().getOnlinePlayers())
/*  968 */           if (p.hasPermission("stats.track"))
/*      */           {
/*  971 */             if (Main.this.getSettings().isUsingBetaFunctions())
/*  972 */               Main.this.getPlayerManager().getPlayer(p.getName()).getStatData((Stat)Main.this.getStatTypes().get("Playtime"), p.getLocation().getWorld().getName(), true).addUpdate(new Object[0], 1.0D);
/*      */             else
/*  974 */               Main.this.getPlayerManager().getPlayer(p.getName()).getStatData((Stat)Main.this.getStatTypes().get("Playtime"), true).addUpdate(new Object[0], 1.0D);
/*      */           }
/*      */       }
/*      */     }
/*      */     , 20L, 20L);
/*      */   }
/*      */ 
/*      */   private void scheduleTableUpdates()
/*      */   {
/*  982 */     getServer().getScheduler().runTaskTimerAsynchronously(this, new Runnable()
/*      */     {
/*      */       public void run() {
/*  985 */         if (!Main.this.newConfig)
/*  986 */           Main.this.runTableUpdates();
/*      */       }
/*      */     }
/*      */     , 200L, 200L);
/*      */   }
/*      */ 
/*      */   private void scheduleGlobalStatsSending()
/*      */   {
/*  993 */     getServer().getScheduler().runTaskTimerAsynchronously(this, new Runnable()
/*      */     {
/*      */       public void run() {
/*  996 */         String re = Main.this.sendStats(Main.this.server);
/*  997 */         if (!re.equals(""))
/*  998 */           Main.this.debug(re);
/*      */       }
/*      */     }
/*      */     , 700L, 600L);
/*      */   }
/*      */ 
/*      */   private void startMetrics()
/*      */   {
/*      */     try
/*      */     {
/* 1006 */       Metrics m = new Metrics(this);
/* 1007 */       Metrics.Graph g = m.createGraph("Sending Data to Global Server");
/* 1008 */       g.addPlotter(new Metrics.Plotter()
/*      */       {
/*      */         public String getColumnName() {
/* 1011 */           return "Enabled in config";
/*      */         }
/*      */ 
/*      */         public int getValue()
/*      */         {
/* 1016 */           return Main.this.getSettings().isSendToGlobal() ? 1 : 0;
/*      */         }
/*      */       });
/* 1019 */       g.addPlotter(new Metrics.Plotter()
/*      */       {
/*      */         public String getColumnName() {
/* 1022 */           return "Allowed to send";
/*      */         }
/*      */ 
/*      */         public int getValue()
/*      */         {
/* 1027 */           return Main.this.canSendToGlobal() ? 1 : 0;
/*      */         }
/*      */       });
/* 1030 */       Metrics.Graph d = m.createGraph("Queries executed");
/* 1031 */       d.addPlotter(new Metrics.Plotter()
/*      */       {
/*      */         public int getValue() {
/* 1034 */           if (Main.this.mysql == null) {
/* 1035 */             return 0;
/*      */           }
/* 1037 */           int done = Main.this.queriesExecuted;
/* 1038 */           Main.this.queriesExecuted = 0;
/* 1039 */           return done;
/*      */         }
/*      */       });
/* 1042 */       m.addGraph(g);
/* 1043 */       m.addGraph(d);
/* 1044 */       m.start();
/*      */     } catch (IOException ex) {
/* 1046 */       Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
/*      */     }
/*      */   }
/*      */ 
/*      */   private long getTimeUntilNextSnapshot() {
/* 1051 */     if (System.currentTimeMillis() > getSettings().getPreviousSnapshot() + convertIntervalToLong(getSettings().getSnapshotInterval())) {
/* 1052 */       return 0L;
/*      */     }
/* 1054 */     return convertIntervalToLong(getSettings().getSnapshotInterval()) - (System.currentTimeMillis() - getSettings().getPreviousSnapshot());
/*      */   }
/*      */ 
/*      */   private long convertIntervalToLong(String interval) {
/* 1058 */     String[] split = interval.split(",");
/* 1059 */     Calendar cal = new GregorianCalendar();
/* 1060 */     cal.setTimeInMillis(0L);
/* 1061 */     for (String str : split)
/*      */     {
/*      */       int type;
/* 1063 */       switch (str.charAt(str.length() - 1)) {
/*      */       case 'm':
/* 1065 */         type = 12;
/* 1066 */         break;
/*      */       case 'H':
/*      */       case 'h':
/* 1069 */         type = 10;
/* 1070 */         break;
/*      */       case 'D':
/*      */       case 'd':
/* 1073 */         type = 5;
/* 1074 */         break;
/*      */       case 'W':
/*      */       case 'w':
/* 1077 */         cal.add(5, 7 * Integer.valueOf(str.substring(0, str.length() - 1)).intValue());
/* 1078 */         break;
/*      */       case 'M':
/* 1080 */         type = 2;
/* 1081 */         break;
/*      */       case 'Y':
/*      */       case 'y':
/* 1084 */         type = 1;
/* 1085 */         break;
/*      */       default:
/* 1087 */         break;
/*      */       }
/* 1089 */       cal.add(type, Integer.valueOf(str.substring(0, str.length() - 1)).intValue());
/*      */     }
/* 1091 */     return cal.getTimeInMillis();
/*      */   }
/*      */ 
/*      */   public StatTypes getStatTypes() {
/* 1095 */     return this.statTypes;
/*      */   }
/*      */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.Main
 * JD-Core Version:    0.6.2
 */