/*     */ package nl.lolmewn.stats;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import nl.lolmewn.stats.mysql.MySQLLib;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ 
/*     */ public class MySQL
/*     */ {
/*     */   private final String prefix;
/*     */   private boolean fault;
/*     */   private final Main plugin;
/*     */   private final MySQLLib mysql;
/*     */ 
/*     */   public MySQL(Main main, String host, int port, String username, String password, String database, String prefix)
/*     */   {
/*  18 */     this.plugin = main;
/*  19 */     this.prefix = prefix;
/*  20 */     this.mysql = new MySQLLib(main.getLogger(), prefix, host, Integer.toString(port), database, username, password);
/*     */     Connection con;
/*  22 */     if ((con = this.mysql.open()) != null) {
/*     */       try {
/*  24 */         con.close();
/*     */       } catch (SQLException ex) {
/*  26 */         Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
/*     */       }
/*  28 */       setupTables();
/*  29 */       checkColumns();
/*  30 */       if (main.getSettings().isUsingBetaFunctions()) {
/*  31 */         createTimeColumn();
/*     */       }
/*  33 */       checkIndexes();
/*     */     } else {
/*  35 */       setFault(true);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void setupTables() {
/*  40 */     if (isFault()) {
/*  41 */       return;
/*     */     }
/*  43 */     executeStatement(new StringBuilder().append("CREATE TABLE IF NOT EXISTS ").append(this.prefix).append("block").append("(counter int PRIMARY KEY NOT NULL AUTO_INCREMENT, ").append("player varchar(255) NOT NULL, ").append("blockID int NOT NULL, ").append("blockData BLOB NOT NULL, ").append("amount int NOT NULL, ").append("break boolean NOT NULL)").toString());
/*     */ 
/*  51 */     executeStatement(new StringBuilder().append("CREATE TABLE IF NOT EXISTS ").append(this.prefix).append("move").append("(counter int PRIMARY KEY NOT NULL AUTO_INCREMENT, ").append("player varchar(255) NOT NULL, ").append("type tinyint NOT NULL,").append("distance double NOT NULL)").toString());
/*     */ 
/*  56 */     executeStatement(new StringBuilder().append("CREATE TABLE IF NOT EXISTS ").append(this.prefix).append("kill").append("(counter int PRIMARY KEY NOT NULL AUTO_INCREMENT, ").append("player varchar(255) NOT NULL, ").append("type varchar(32) NOT NULL , ").append("amount int NOT NULL)").toString());
/*     */ 
/*  61 */     executeStatement(new StringBuilder().append("CREATE TABLE IF NOT EXISTS ").append(this.prefix).append("death").append("(counter int PRIMARY KEY NOT NULL AUTO_INCREMENT, ").append("player varchar(255) NOT NULL, ").append("cause varchar(32) NOT NULL , ").append("amount int NOT NULL,").append("entity boolean NOT NULL)").toString());
/*     */ 
/*  67 */     executeStatement(new StringBuilder().append("CREATE TABLE IF NOT EXISTS ").append(this.prefix).append("player").append("(counter int PRIMARY KEY NOT NULL AUTO_INCREMENT, ").append("player varchar(255) NOT NULL, ").append("playtime int NOT NULL DEFAULT 0, ").append("arrows int DEFAULT 0,").append("xpgained int DEFAULT 0,").append("joins int DEFAULT 0,").append("fishcatch int DEFAULT 0,").append("damagetaken int DEFAULT 0,").append("timeskicked int DEFAULT 0,").append("toolsbroken int DEFAULT 0,").append("eggsthrown int DEFAULT 0,").append("itemscrafted int DEFAULT 0,").append("omnomnom int DEFAULT 0,").append("onfire int DEFAULT 0,").append("wordssaid int DEFAULT 0,").append("commandsdone int DEFAULT 0,").append("votes int DEFAULT 0,").append("teleports int DEFAULT 0,").append("itempickups int DEFAULT 0,").append("bedenter int DEFAULT 0,").append("bucketfill int DEFAULT 0,").append("bucketempty int DEFAULT 0,").append("worldchange int DEFAULT 0,").append("itemdrops int DEFAULT 0,").append("shear int DEFAULT 0,").append("lastjoin TIMESTAMP DEFAULT NOW(),").append("lastleave TIMESTAMP DEFAULT 0)").toString());
/*     */   }
/*     */ 
/*     */   public boolean isFault()
/*     */   {
/*  98 */     return this.fault;
/*     */   }
/*     */ 
/*     */   private void setFault(boolean fault) {
/* 102 */     this.fault = fault;
/*     */   }
/*     */ 
/*     */   public int executeStatement(String statement) {
/* 106 */     if (isFault()) {
/* 107 */       System.out.println("[Stats] Can't execute statement, something wrong with connection");
/* 108 */       return 0;
/*     */     }
/* 110 */     this.plugin.debugQuery(new StringBuilder().append("Executing Statement: ").append(statement).toString());
/*     */     try {
/* 112 */       Connection con = this.mysql.getConnection();
/* 113 */       con.setAutoCommit(true);
/* 114 */       Statement state = con.createStatement();
/* 115 */       int re = state.executeUpdate(statement);
/* 116 */       state.close();
/* 117 */       con.close();
/* 118 */       return re;
/*     */     } catch (SQLException e) {
/* 120 */       if (e.getMessage().contains("Unknown column 'blockData'")) {
/* 121 */         this.plugin.getLogger().warning("Found faulty blocks table, fixing...");
/* 122 */         executeStatement(new StringBuilder().append("DROP TABLE ").append(this.prefix).append("block").toString());
/* 123 */         executeStatement(new StringBuilder().append("CREATE TABLE IF NOT EXISTS ").append(this.prefix).append("block").append("(counter int PRIMARY KEY NOT NULL AUTO_INCREMENT, ").append("player varchar(255) NOT NULL, ").append("blockID int NOT NULL, ").append("blockData BLOB NOT NULL, ").append("amount int NOT NULL, ").append("break boolean NOT NULL)").toString());
/*     */ 
/* 130 */         this.plugin.getLogger().warning("Faulty blocks table fixed.");
/*     */       } else {
/* 132 */         Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, e);
/*     */       }
/*     */     }
/* 135 */     return 0;
/*     */   }
/*     */ 
/*     */   private void checkColumns() {
/* 139 */     Connection con = getConnection();
/* 140 */     checkColumn(con, new StringBuilder().append(this.prefix).append("death").toString(), "entity", "boolean", null);
/* 141 */     checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "lastjoin", "TIMESTAMP", "0");
/* 142 */     checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "lastleave", "TIMESTAMP", "0");
/* 143 */     checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "teleports", "int", "0");
/* 144 */     checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "itempickups", "int", "0");
/* 145 */     checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "bedenter", "int", "0");
/* 146 */     checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "bucketfill", "int", "0");
/* 147 */     checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "bucketempty", "int", "0");
/* 148 */     checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "worldchange", "int", "0");
/* 149 */     checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "itemdrops", "int", "0");
/* 150 */     checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "shear", "int", "0");
/* 151 */     checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "votes", "int", "0");
/* 152 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 153 */       checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "world", "VARCHAR(255)", new StringBuilder().append("'").append(((World)this.plugin.getServer().getWorlds().get(0)).getName()).append("'").toString());
/* 154 */       checkColumn(con, new StringBuilder().append(this.prefix).append("kill").toString(), "world", "VARCHAR(255)", new StringBuilder().append("'").append(((World)this.plugin.getServer().getWorlds().get(0)).getName()).append("'").toString());
/* 155 */       checkColumn(con, new StringBuilder().append(this.prefix).append("death").toString(), "world", "VARCHAR(255)", new StringBuilder().append("'").append(((World)this.plugin.getServer().getWorlds().get(0)).getName()).append("'").toString());
/* 156 */       checkColumn(con, new StringBuilder().append(this.prefix).append("move").toString(), "world", "VARCHAR(255)", new StringBuilder().append("'").append(((World)this.plugin.getServer().getWorlds().get(0)).getName()).append("'").toString());
/* 157 */       checkColumn(con, new StringBuilder().append(this.prefix).append("block").toString(), "world", "VARCHAR(255)", new StringBuilder().append("'").append(((World)this.plugin.getServer().getWorlds().get(0)).getName()).append("'").toString());
/*     */     }
/*     */ 
/* 160 */     executeStatement(new StringBuilder().append("ALTER TABLE ").append(this.prefix).append("block CHANGE COLUMN blockData blockData BLOB NOT NULL").toString());
/*     */     try {
/* 162 */       con.close();
/*     */     } catch (SQLException ex) {
/* 164 */       Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkColumn(Connection con, String table, String column, String type, String def) {
/* 169 */     this.plugin.debug(new StringBuilder().append("Checking Column for ").append(table).append(", ").append(column).append(" as ").append(type).toString());
/*     */     try {
/* 171 */       DatabaseMetaData md = con.getMetaData();
/* 172 */       ResultSet rs = md.getColumns(null, null, table, column);
/* 173 */       if (rs.next()) {
/* 174 */         this.plugin.debug(new StringBuilder().append(column).append(" was already in the table!").toString());
/* 175 */         return;
/*     */       }
/* 177 */       executeStatement(new StringBuilder().append("ALTER TABLE ").append(table).append(" ADD COLUMN ").append(column).append(" ").append(type).append(def == null ? "" : new StringBuilder().append(" DEFAULT ").append(def).toString()).toString());
/* 178 */       rs.close();
/*     */     } catch (SQLException ex) {
/* 180 */       Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Connection getConnection() {
/* 186 */     int tries = 0;
/*     */     Connection con;
/*     */     do { con = this.mysql.getConnection();
/* 189 */       tries++; }
/* 190 */     while ((con == null) && (tries < 10));
/* 191 */     return con;
/*     */   }
/*     */ 
/*     */   private void checkIndexes() {
/*     */     try {
/* 196 */       Connection con = this.mysql.getConnection();
/* 197 */       con.setAutoCommit(true);
/* 198 */       Statement st = con.createStatement();
/*     */       ResultSet set;
/* 200 */       if (((set = st.executeQuery(new StringBuilder().append("SELECT ENGINE FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME LIKE '").append(this.prefix).append("%'").toString())).next()) && 
/* 201 */         (set.getString("ENGINE").equalsIgnoreCase("InnoDB"))) {
/* 202 */         set.close();
/* 203 */         st.execute("SET SESSION old_alter_table=1");
/*     */       }
/*     */ 
/* 207 */       if ((this.plugin.getSettings().isUsingBetaFunctions()) && (this.plugin.getSettings().createSnapshots())) {
/* 208 */         if (st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("block WHERE Key_name='no_duplicates'").toString()).next()) {
/* 209 */           st.execute(new StringBuilder().append("DROP INDEX no_duplicates ON ").append(this.prefix).append("block").toString());
/*     */         }
/* 211 */         if (st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("move WHERE Key_name='no_duplicates'").toString()).next()) {
/* 212 */           st.execute(new StringBuilder().append("DROP INDEX no_duplicates ON ").append(this.prefix).append("move").toString());
/*     */         }
/* 214 */         if (st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("kill WHERE Key_name='no_duplicates'").toString()).next()) {
/* 215 */           st.execute(new StringBuilder().append("DROP INDEX no_duplicates ON ").append(this.prefix).append("kill").toString());
/*     */         }
/* 217 */         if (st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("player WHERE Key_name='no_duplicates'").toString()).next()) {
/* 218 */           st.execute(new StringBuilder().append("DROP INDEX no_duplicates ON ").append(this.prefix).append("player").toString());
/*     */         }
/* 220 */         if (st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("death WHERE Key_name='no_duplicates'").toString()).next())
/* 221 */           st.execute(new StringBuilder().append("DROP INDEX no_duplicates ON ").append(this.prefix).append("death").toString());
/*     */       }
/* 223 */       else if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 224 */         if (!st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("block WHERE Key_name='no_duplicates'").toString()).next()) {
/* 225 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("block ADD UNIQUE INDEX no_duplicates (player, blockID, blockData(4), break, world)").toString());
/*     */         } else {
/* 227 */           st.execute(new StringBuilder().append("DROP INDEX no_duplicates ON ").append(this.prefix).append("block").toString());
/* 228 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("block ADD UNIQUE INDEX no_duplicates (player, blockID, blockData(4), break, world)").toString());
/*     */         }
/* 230 */         if (!st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("move WHERE Key_name='no_duplicates'").toString()).next()) {
/* 231 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("move ADD UNIQUE INDEX no_duplicates (player, type, world)").toString());
/*     */         } else {
/* 233 */           st.execute(new StringBuilder().append("DROP INDEX no_duplicates ON ").append(this.prefix).append("move").toString());
/* 234 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("move ADD UNIQUE INDEX no_duplicates (player, type, world)").toString());
/*     */         }
/* 236 */         if (!st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("kill WHERE Key_name='no_duplicates'").toString()).next()) {
/* 237 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("kill ADD UNIQUE INDEX no_duplicates (player, type, world)").toString());
/*     */         } else {
/* 239 */           st.execute(new StringBuilder().append("DROP INDEX no_duplicates ON ").append(this.prefix).append("kill").toString());
/* 240 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("kill ADD UNIQUE INDEX no_duplicates (player, type, world)").toString());
/*     */         }
/* 242 */         if (!st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("player WHERE Key_name='no_duplicates'").toString()).next()) {
/* 243 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("player ADD UNIQUE INDEX no_duplicates (player, world)").toString());
/*     */         } else {
/* 245 */           st.execute(new StringBuilder().append("DROP INDEX no_duplicates ON ").append(this.prefix).append("player").toString());
/* 246 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("player ADD UNIQUE INDEX no_duplicates (player, world)").toString());
/*     */         }
/* 248 */         if (!st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("death WHERE Key_name='no_duplicates'").toString()).next()) {
/* 249 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("death ADD UNIQUE INDEX no_duplicates (player, cause, entity, world)").toString());
/*     */         } else {
/* 251 */           st.execute(new StringBuilder().append("DROP INDEX no_duplicates ON ").append(this.prefix).append("death").toString());
/* 252 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("death ADD UNIQUE INDEX no_duplicates (player, cause, entity, world)").toString());
/*     */         }
/*     */       } else {
/* 255 */         if (!st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("block WHERE Key_name='no_duplicates'").toString()).next()) {
/* 256 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("block ADD UNIQUE INDEX no_duplicates (player, blockID, blockData(4), break)").toString());
/*     */         }
/* 258 */         if (!st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("move WHERE Key_name='no_duplicates'").toString()).next()) {
/* 259 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("move ADD UNIQUE INDEX no_duplicates (player, type)").toString());
/*     */         }
/* 261 */         if (!st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("kill WHERE Key_name='no_duplicates'").toString()).next()) {
/* 262 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("kill ADD UNIQUE INDEX no_duplicates (player, type)").toString());
/*     */         }
/* 264 */         if (!st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("player WHERE Key_name='no_duplicates'").toString()).next()) {
/* 265 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("player ADD UNIQUE INDEX no_duplicates (player)").toString());
/*     */         }
/* 267 */         if (!st.executeQuery(new StringBuilder().append("SHOW INDEXES FROM ").append(this.prefix).append("death WHERE Key_name='no_duplicates'").toString()).next()) {
/* 268 */           st.execute(new StringBuilder().append("ALTER IGNORE TABLE ").append(this.prefix).append("death ADD UNIQUE INDEX no_duplicates (player, cause, entity)").toString());
/*     */         }
/*     */       }
/* 271 */       st.close();
/* 272 */       con.close();
/*     */     } catch (SQLException ex) {
/* 274 */       Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   void exit() {
/* 279 */     this.mysql.exit();
/*     */   }
/*     */ 
/*     */   private void createTimeColumn() {
/* 283 */     Connection con = getConnection();
/* 284 */     checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "snapshot_time", "TIMESTAMP", null);
/* 285 */     checkColumn(con, new StringBuilder().append(this.prefix).append("player").toString(), "snapshot_name", "VARCHAR(64)", "'main_snapshot'");
/* 286 */     checkColumn(con, new StringBuilder().append(this.prefix).append("kill").toString(), "snapshot_time", "TIMESTAMP", null);
/* 287 */     checkColumn(con, new StringBuilder().append(this.prefix).append("kill").toString(), "snapshot_name", "VARCHAR(64)", "'main_snapshot'");
/* 288 */     checkColumn(con, new StringBuilder().append(this.prefix).append("death").toString(), "snapshot_time", "TIMESTAMP", null);
/* 289 */     checkColumn(con, new StringBuilder().append(this.prefix).append("death").toString(), "snapshot_name", "VARCHAR(64)", "'main_snapshot'");
/* 290 */     checkColumn(con, new StringBuilder().append(this.prefix).append("move").toString(), "snapshot_time", "TIMESTAMP", null);
/* 291 */     checkColumn(con, new StringBuilder().append(this.prefix).append("move").toString(), "snapshot_name", "VARCHAR(64)", "'main_snapshot'");
/* 292 */     checkColumn(con, new StringBuilder().append(this.prefix).append("block").toString(), "snapshot_time", "TIMESTAMP", null);
/* 293 */     checkColumn(con, new StringBuilder().append(this.prefix).append("block").toString(), "snapshot_name", "VARCHAR(64)", "'main_snapshot'");
/*     */     try {
/* 295 */       con.close();
/*     */     } catch (SQLException ex) {
/* 297 */       Logger.getLogger(MySQL.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.MySQL
 * JD-Core Version:    0.6.2
 */