/*     */ package nl.lolmewn.stats;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.util.Enumeration;
/*     */ import java.util.List;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.zip.ZipEntry;
/*     */ import java.util.zip.ZipFile;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.configuration.file.YamlConfigurationOptions;
/*     */ import org.bukkit.plugin.Plugin;
/*     */ import org.bukkit.plugin.PluginDescriptionFile;
/*     */ import org.json.simple.JSONArray;
/*     */ import org.json.simple.JSONObject;
/*     */ import org.json.simple.JSONValue;
/*     */ 
/*     */ public class Updater
/*     */ {
/*     */   private final Plugin plugin;
/*     */   private final UpdateType type;
/*     */   private String versionName;
/*     */   private String versionLink;
/*     */   private String versionType;
/*     */   private String versionGameVersion;
/*     */   private final boolean announce;
/*     */   private URL url;
/*     */   private final File file;
/*     */   private Thread thread;
/*  55 */   private int id = -1;
/*  56 */   private String apiKey = null;
/*     */   private static final String TITLE_VALUE = "name";
/*     */   private static final String LINK_VALUE = "downloadUrl";
/*     */   private static final String TYPE_VALUE = "releaseType";
/*     */   private static final String VERSION_VALUE = "gameVersion";
/*     */   private static final String QUERY = "/servermods/files?projectIds=";
/*     */   private static final String HOST = "https://api.curseforge.com";
/*  64 */   private static final String[] NO_UPDATE_TAG = { "-DEV", "-PRE", "-SNAPSHOT" };
/*     */   private static final int BYTE_SIZE = 1024;
/*     */   private final YamlConfiguration config;
/*     */   private final String updateFolder;
/*  68 */   private UpdateResult result = UpdateResult.SUCCESS;
/*     */ 
/*     */   public Updater(Plugin plugin, int id, File file, UpdateType type, boolean announce)
/*     */   {
/* 140 */     this.plugin = plugin;
/* 141 */     this.type = type;
/* 142 */     this.announce = announce;
/* 143 */     this.file = file;
/* 144 */     this.id = id;
/* 145 */     this.updateFolder = plugin.getServer().getUpdateFolder();
/*     */ 
/* 147 */     File pluginFile = plugin.getDataFolder().getParentFile();
/* 148 */     File updaterFile = new File(pluginFile, "Updater");
/* 149 */     File updaterConfigFile = new File(updaterFile, "config.yml");
/*     */ 
/* 151 */     if (!updaterFile.exists()) {
/* 152 */       updaterFile.mkdir();
/*     */     }
/* 154 */     if (!updaterConfigFile.exists()) {
/*     */       try {
/* 156 */         updaterConfigFile.createNewFile();
/*     */       } catch (IOException e) {
/* 158 */         plugin.getLogger().severe(new StringBuilder().append("The updater could not create a configuration in ").append(updaterFile.getAbsolutePath()).toString());
/* 159 */         e.printStackTrace();
/*     */       }
/*     */     }
/* 162 */     this.config = YamlConfiguration.loadConfiguration(updaterConfigFile);
/*     */ 
/* 164 */     this.config.options().header("This configuration file affects all plugins using the Updater system (version 2+ - http://forums.bukkit.org/threads/96681/ )\nIf you wish to use your API key, read http://wiki.bukkit.org/ServerMods_API and place it below.\nSome updating systems will not adhere to the disabled value, but these may be turned off in their plugin's configuration.");
/*     */ 
/* 167 */     this.config.addDefault("api-key", "PUT_API_KEY_HERE");
/* 168 */     this.config.addDefault("disable", Boolean.valueOf(false));
/*     */ 
/* 170 */     if (this.config.get("api-key", null) == null) {
/* 171 */       this.config.options().copyDefaults(true);
/*     */       try {
/* 173 */         this.config.save(updaterConfigFile);
/*     */       } catch (IOException e) {
/* 175 */         plugin.getLogger().severe(new StringBuilder().append("The updater could not save the configuration in ").append(updaterFile.getAbsolutePath()).toString());
/* 176 */         e.printStackTrace();
/*     */       }
/*     */     }
/*     */ 
/* 180 */     if (this.config.getBoolean("disable")) {
/* 181 */       this.result = UpdateResult.DISABLED;
/* 182 */       return;
/*     */     }
/*     */ 
/* 185 */     String key = this.config.getString("api-key");
/* 186 */     if ((key.equalsIgnoreCase("PUT_API_KEY_HERE")) || (key.equals(""))) {
/* 187 */       key = null;
/*     */     }
/*     */ 
/* 190 */     this.apiKey = key;
/*     */     try
/*     */     {
/* 193 */       this.url = new URL(new StringBuilder().append("https://api.curseforge.com/servermods/files?projectIds=").append(id).toString());
/*     */     } catch (MalformedURLException e) {
/* 195 */       plugin.getLogger().severe(new StringBuilder().append("The project ID provided for updating, ").append(id).append(" is invalid.").toString());
/* 196 */       this.result = UpdateResult.FAIL_BADID;
/* 197 */       e.printStackTrace();
/*     */     }
/*     */ 
/* 200 */     this.thread = new Thread(new UpdateRunnable(null));
/* 201 */     this.thread.start();
/*     */   }
/*     */ 
/*     */   public UpdateResult getResult()
/*     */   {
/* 208 */     waitForThread();
/* 209 */     return this.result;
/*     */   }
/*     */ 
/*     */   public String getLatestType()
/*     */   {
/* 216 */     waitForThread();
/* 217 */     return this.versionType;
/*     */   }
/*     */ 
/*     */   public String getLatestGameVersion()
/*     */   {
/* 224 */     waitForThread();
/* 225 */     return this.versionGameVersion;
/*     */   }
/*     */ 
/*     */   public String getLatestName()
/*     */   {
/* 232 */     waitForThread();
/* 233 */     return this.versionName;
/*     */   }
/*     */ 
/*     */   public String getLatestFileLink()
/*     */   {
/* 240 */     waitForThread();
/* 241 */     return this.versionLink;
/*     */   }
/*     */ 
/*     */   private void waitForThread()
/*     */   {
/* 249 */     if ((this.thread != null) && (this.thread.isAlive()))
/*     */       try {
/* 251 */         this.thread.join();
/*     */       } catch (InterruptedException e) {
/* 253 */         e.printStackTrace();
/*     */       }
/*     */   }
/*     */ 
/*     */   private void saveFile(File folder, String file, String u)
/*     */   {
/* 262 */     if (!folder.exists()) {
/* 263 */       folder.mkdir();
/*     */     }
/* 265 */     BufferedInputStream in = null;
/* 266 */     FileOutputStream fout = null;
/*     */     try
/*     */     {
/* 269 */       URL url = new URL(u);
/* 270 */       int fileLength = url.openConnection().getContentLength();
/* 271 */       in = new BufferedInputStream(url.openStream());
/* 272 */       fout = new FileOutputStream(new StringBuilder().append(folder.getAbsolutePath()).append("/").append(file).toString());
/*     */ 
/* 274 */       byte[] data = new byte[1024];
/*     */ 
/* 276 */       if (this.announce) {
/* 277 */         this.plugin.getLogger().info(new StringBuilder().append("About to download a new update: ").append(this.versionName).toString());
/*     */       }
/* 279 */       long downloaded = 0L;
/*     */       int count;
/* 280 */       while ((count = in.read(data, 0, 1024)) != -1) {
/* 281 */         downloaded += count;
/* 282 */         fout.write(data, 0, count);
/* 283 */         int percent = (int)(downloaded * 100L / fileLength);
/* 284 */         if ((this.announce) && (percent % 10 == 0)) {
/* 285 */           this.plugin.getLogger().info(new StringBuilder().append("Downloading update: ").append(percent).append("% of ").append(fileLength).append(" bytes.").toString());
/*     */         }
/*     */       }
/*     */ 
/* 289 */       for (File xFile : new File(this.plugin.getDataFolder().getParent(), this.updateFolder).listFiles()) {
/* 290 */         if (xFile.getName().endsWith(".zip")) {
/* 291 */           xFile.delete();
/*     */         }
/*     */       }
/*     */ 
/* 295 */       File dFile = new File(new StringBuilder().append(folder.getAbsolutePath()).append("/").append(file).toString());
/* 296 */       if (dFile.getName().endsWith(".zip"))
/*     */       {
/* 298 */         unzip(dFile.getCanonicalPath());
/*     */       }
/* 300 */       if (this.announce)
/* 301 */         this.plugin.getLogger().info("Finished updating.");
/*     */     }
/*     */     catch (Exception ex) {
/* 304 */       this.plugin.getLogger().warning("The auto-updater tried to download a new update, but was unsuccessful.");
/* 305 */       this.result = UpdateResult.FAIL_DOWNLOAD;
/*     */     } finally {
/*     */       try {
/* 308 */         if (in != null) {
/* 309 */           in.close();
/*     */         }
/* 311 */         if (fout != null)
/* 312 */           fout.close();
/*     */       }
/*     */       catch (Exception ex)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void unzip(String file)
/*     */   {
/*     */     try
/*     */     {
/* 324 */       File fSourceZip = new File(file);
/* 325 */       String zipPath = file.substring(0, file.length() - 4);
/* 326 */       ZipFile zipFile = new ZipFile(fSourceZip);
/* 327 */       Enumeration e = zipFile.entries();
/* 328 */       while (e.hasMoreElements()) {
/* 329 */         ZipEntry entry = (ZipEntry)e.nextElement();
/* 330 */         File destinationFilePath = new File(zipPath, entry.getName());
/* 331 */         destinationFilePath.getParentFile().mkdirs();
/* 332 */         if (!entry.isDirectory())
/*     */         {
/* 335 */           BufferedInputStream bis = new BufferedInputStream(zipFile.getInputStream(entry));
/*     */ 
/* 337 */           byte[] buffer = new byte[1024];
/* 338 */           FileOutputStream fos = new FileOutputStream(destinationFilePath);
/* 339 */           BufferedOutputStream bos = new BufferedOutputStream(fos, 1024);
/*     */           int b;
/* 340 */           while ((b = bis.read(buffer, 0, 1024)) != -1) {
/* 341 */             bos.write(buffer, 0, b);
/*     */           }
/* 343 */           bos.flush();
/* 344 */           bos.close();
/* 345 */           bis.close();
/* 346 */           String name = destinationFilePath.getName();
/* 347 */           if ((name.endsWith(".jar")) && (pluginFile(name))) {
/* 348 */             destinationFilePath.renameTo(new File(this.plugin.getDataFolder().getParent(), new StringBuilder().append(this.updateFolder).append("/").append(name).toString()));
/*     */           }
/*     */ 
/* 351 */           entry = null;
/* 352 */           destinationFilePath = null;
/*     */         }
/*     */       }
/* 354 */       e = null;
/* 355 */       zipFile.close();
/* 356 */       zipFile = null;
/*     */ 
/* 359 */       for (File dFile : new File(zipPath).listFiles()) {
/* 360 */         if ((dFile.isDirectory()) && 
/* 361 */           (pluginFile(dFile.getName()))) {
/* 362 */           File oFile = new File(this.plugin.getDataFolder().getParent(), dFile.getName());
/* 363 */           File[] contents = oFile.listFiles();
/* 364 */           for (File cFile : dFile.listFiles())
/*     */           {
/* 366 */             boolean found = false;
/* 367 */             for (File xFile : contents)
/*     */             {
/* 369 */               if (xFile.getName().equals(cFile.getName())) {
/* 370 */                 found = true;
/* 371 */                 break;
/*     */               }
/*     */             }
/* 374 */             if (!found)
/*     */             {
/* 376 */               cFile.renameTo(new File(new StringBuilder().append(oFile.getCanonicalFile()).append("/").append(cFile.getName()).toString()));
/*     */             }
/*     */             else {
/* 379 */               cFile.delete();
/*     */             }
/*     */           }
/*     */         }
/*     */ 
/* 384 */         dFile.delete();
/*     */       }
/* 386 */       new File(zipPath).delete();
/* 387 */       fSourceZip.delete();
/*     */     } catch (IOException ex) {
/* 389 */       this.plugin.getLogger().warning("The auto-updater tried to unzip a new update file, but was unsuccessful.");
/* 390 */       this.result = UpdateResult.FAIL_DOWNLOAD;
/* 391 */       ex.printStackTrace();
/*     */     }
/* 393 */     new File(file).delete();
/*     */   }
/*     */ 
/*     */   private boolean pluginFile(String name)
/*     */   {
/* 400 */     for (File file : new File("plugins").listFiles()) {
/* 401 */       if (file.getName().equals(name)) {
/* 402 */         return true;
/*     */       }
/*     */     }
/* 405 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean versionCheck(String title)
/*     */   {
/* 412 */     if (this.type != UpdateType.NO_VERSION_CHECK) {
/* 413 */       String version = this.plugin.getDescription().getVersion().split("-")[0];
/* 414 */       if (title.split(" v").length == 2) {
/* 415 */         String remoteVersion = title.split(" v")[1].split(" ")[0];
/* 416 */         int remVer = -1; int curVer = 0;
/*     */         try {
/* 418 */           remVer = calVer(remoteVersion).intValue();
/* 419 */           curVer = calVer(version).intValue();
/*     */         } catch (NumberFormatException nfe) {
/* 421 */           remVer = -1;
/*     */         }
/* 423 */         if ((hasTag(version)) || (version.equalsIgnoreCase(remoteVersion)) || (curVer >= remVer))
/*     */         {
/* 425 */           this.result = UpdateResult.NO_UPDATE;
/* 426 */           return false;
/*     */         }
/*     */       }
/*     */       else {
/* 430 */         String authorInfo = this.plugin.getDescription().getAuthors().size() == 0 ? "" : new StringBuilder().append(" (").append((String)this.plugin.getDescription().getAuthors().get(0)).append(")").toString();
/* 431 */         this.plugin.getLogger().warning(new StringBuilder().append("The author of this plugin").append(authorInfo).append(" has misconfigured their Auto Update system").toString());
/* 432 */         this.plugin.getLogger().warning("Files uploaded to BukkitDev should contain the version number, seperated from the name by a 'v', such as PluginName v1.0");
/* 433 */         this.plugin.getLogger().warning("Please notify the author of this error.");
/* 434 */         this.result = UpdateResult.FAIL_NOVERSION;
/* 435 */         return false;
/*     */       }
/*     */     }
/* 438 */     return true;
/*     */   }
/*     */ 
/*     */   private Integer calVer(String s)
/*     */     throws NumberFormatException
/*     */   {
/* 445 */     if (s.contains(".")) {
/* 446 */       StringBuilder sb = new StringBuilder();
/* 447 */       for (int i = 0; i < s.length(); i++) {
/* 448 */         Character c = Character.valueOf(s.charAt(i));
/* 449 */         if (Character.isLetterOrDigit(c.charValue())) {
/* 450 */           sb.append(c);
/*     */         }
/*     */       }
/* 453 */       return Integer.valueOf(Integer.parseInt(sb.toString()));
/*     */     }
/* 455 */     return Integer.valueOf(Integer.parseInt(s));
/*     */   }
/*     */ 
/*     */   private boolean hasTag(String version)
/*     */   {
/* 462 */     for (String string : NO_UPDATE_TAG) {
/* 463 */       if (version.contains(string)) {
/* 464 */         return true;
/*     */       }
/*     */     }
/* 467 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean read() {
/*     */     try {
/* 472 */       URLConnection conn = this.url.openConnection();
/* 473 */       conn.setConnectTimeout(5000);
/*     */ 
/* 475 */       if (this.apiKey != null) {
/* 476 */         conn.addRequestProperty("X-API-Key", this.apiKey);
/*     */       }
/* 478 */       conn.addRequestProperty("User-Agent", "Updater (by Gravity)");
/*     */ 
/* 480 */       conn.setDoOutput(true);
/*     */ 
/* 482 */       BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
/* 483 */       String response = reader.readLine();
/*     */ 
/* 485 */       JSONArray array = (JSONArray)JSONValue.parse(response);
/*     */ 
/* 487 */       if (array.size() == 0) {
/* 488 */         this.plugin.getLogger().warning(new StringBuilder().append("The updater could not find any files for the project id ").append(this.id).toString());
/* 489 */         this.result = UpdateResult.FAIL_BADID;
/* 490 */         return false;
/*     */       }
/*     */ 
/* 493 */       this.versionName = ((String)((JSONObject)array.get(array.size() - 1)).get("name"));
/* 494 */       this.versionLink = ((String)((JSONObject)array.get(array.size() - 1)).get("downloadUrl"));
/* 495 */       this.versionType = ((String)((JSONObject)array.get(array.size() - 1)).get("releaseType"));
/* 496 */       this.versionGameVersion = ((String)((JSONObject)array.get(array.size() - 1)).get("gameVersion"));
/*     */ 
/* 498 */       return true;
/*     */     } catch (IOException e) {
/* 500 */       if (e.getMessage().contains("HTTP response code: 403")) {
/* 501 */         this.plugin.getLogger().warning("dev.bukkit.org rejected the API key provided in plugins/Updater/config.yml");
/* 502 */         this.plugin.getLogger().warning("Please double-check your configuration to ensure it is correct.");
/* 503 */         this.result = UpdateResult.FAIL_APIKEY;
/*     */       } else {
/* 505 */         this.plugin.getLogger().warning("The updater could not contact dev.bukkit.org for updating.");
/* 506 */         this.plugin.getLogger().warning("If you have not recently modified your configuration and this is the first time you are seeing this message, the site may be experiencing temporary downtime.");
/* 507 */         this.result = UpdateResult.FAIL_DBO;
/*     */       }
/* 509 */       e.printStackTrace();
/* 510 */     }return false;
/*     */   }
/*     */ 
/*     */   private class UpdateRunnable implements Runnable {
/*     */     private UpdateRunnable() {
/*     */     }
/*     */ 
/*     */     public void run() {
/* 518 */       if (Updater.this.url != null)
/*     */       {
/* 520 */         if ((Updater.this.read()) && 
/* 521 */           (Updater.this.versionCheck(Updater.this.versionName)))
/* 522 */           if ((Updater.this.versionLink != null) && (Updater.this.type != Updater.UpdateType.NO_DOWNLOAD)) {
/* 523 */             String name = Updater.this.file.getName();
/*     */ 
/* 525 */             if (Updater.this.versionLink.endsWith(".zip")) {
/* 526 */               String[] split = Updater.this.versionLink.split("/");
/* 527 */               name = split[(split.length - 1)];
/*     */             }
/* 529 */             Updater.this.saveFile(new File(Updater.this.plugin.getDataFolder().getParent(), Updater.this.updateFolder), name, Updater.this.versionLink);
/*     */           } else {
/* 531 */             Updater.this.result = Updater.UpdateResult.UPDATE_AVAILABLE;
/*     */           }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static enum UpdateType
/*     */   {
/* 119 */     DEFAULT, 
/*     */ 
/* 123 */     NO_VERSION_CHECK, 
/*     */ 
/* 127 */     NO_DOWNLOAD;
/*     */   }
/*     */ 
/*     */   public static enum UpdateResult
/*     */   {
/*  77 */     SUCCESS, 
/*     */ 
/*  81 */     NO_UPDATE, 
/*     */ 
/*  85 */     DISABLED, 
/*     */ 
/*  89 */     FAIL_DOWNLOAD, 
/*     */ 
/*  93 */     FAIL_DBO, 
/*     */ 
/*  97 */     FAIL_NOVERSION, 
/*     */ 
/* 101 */     FAIL_BADID, 
/*     */ 
/* 105 */     FAIL_APIKEY, 
/*     */ 
/* 109 */     UPDATE_AVAILABLE;
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.Updater
 * JD-Core Version:    0.6.2
 */