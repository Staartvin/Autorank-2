/*    */ package nl.lolmewn.stats.api;
/*    */ 
/*    */ import nl.lolmewn.stats.player.StatsPlayer;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class StatsPlayerLoadedEvent extends Event
/*    */ {
/* 17 */   private static final HandlerList handlers = new HandlerList();
/*    */   private final StatsPlayer player;
/*    */ 
/*    */   public StatsPlayerLoadedEvent(StatsPlayer player, boolean async)
/*    */   {
/* 21 */     super(async);
/* 22 */     this.player = player;
/*    */   }
/*    */ 
/*    */   public HandlerList getHandlers()
/*    */   {
/* 27 */     return handlers;
/*    */   }
/*    */ 
/*    */   public static HandlerList getHandlerList() {
/* 31 */     return handlers;
/*    */   }
/*    */ 
/*    */   public StatsPlayer getStatsPlayer() {
/* 35 */     return this.player;
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.api.StatsPlayerLoadedEvent
 * JD-Core Version:    0.6.2
 */