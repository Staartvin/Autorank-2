/*    */ package nl.lolmewn.stats.api;
/*    */ 
/*    */ import nl.lolmewn.stats.StatType;
/*    */ import nl.lolmewn.stats.player.StatData;
/*    */ import nl.lolmewn.stats.player.StatsPlayer;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class StatUpdateEvent extends Event
/*    */   implements Cancellable
/*    */ {
/* 15 */   private static final HandlerList handlers = new HandlerList();
/* 16 */   private boolean cancelled = false;
/*    */   private final StatData statData;
/*    */   private double value;
/*    */   private final Object[] vars;
/*    */ 
/*    */   public StatUpdateEvent(StatData statData, double value, Object[] vars, boolean async)
/*    */   {
/* 23 */     super(async);
/* 24 */     this.statData = statData;
/* 25 */     this.value = value;
/* 26 */     this.vars = vars;
/*    */   }
/*    */ 
/*    */   public HandlerList getHandlers()
/*    */   {
/* 31 */     return handlers;
/*    */   }
/*    */ 
/*    */   public static HandlerList getHandlerList() {
/* 35 */     return handlers;
/*    */   }
/*    */ 
/*    */   public boolean isCancelled()
/*    */   {
/* 40 */     return this.cancelled;
/*    */   }
/*    */ 
/*    */   public void setCancelled(boolean bln)
/*    */   {
/* 45 */     this.cancelled = bln;
/*    */   }
/*    */ 
/*    */   public Stat getStat() {
/* 49 */     return this.statData.getStat();
/*    */   }
/*    */ 
/*    */   public StatData getStatData() {
/* 53 */     return this.statData;
/*    */   }
/*    */ 
/*    */   public double getUpdateValue()
/*    */   {
/* 61 */     return this.value;
/*    */   }
/*    */ 
/*    */   public double getCurrentValue()
/*    */   {
/* 69 */     return this.statData.getValue(this.vars);
/*    */   }
/*    */ 
/*    */   public double getNewValue() {
/* 73 */     return getCurrentValue() + this.value;
/*    */   }
/*    */ 
/*    */   public Object[] getVars() {
/* 77 */     return this.vars;
/*    */   }
/*    */ 
/*    */   public void setUpdateValue(int value) {
/* 81 */     this.value = value;
/*    */   }
/*    */ 
/*    */   @Deprecated
/*    */   public StatType getStatType()
/*    */   {
/* 89 */     for (StatType type : StatType.values()) {
/* 90 */       if (type.makeMePretty().equals(this.statData.getStat().getName())) {
/* 91 */         return type;
/*    */       }
/*    */     }
/* 94 */     return null;
/*    */   }
/*    */ 
/*    */   public StatsPlayer getPlayer() {
/* 98 */     return this.statData.getStatsPlayer();
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.api.StatUpdateEvent
 * JD-Core Version:    0.6.2
 */