/*    */ package nl.lolmewn.stats.api;
/*    */ 
/*    */ public class Stat
/*    */ {
/*    */   private final String name;
/*    */   private final String update;
/*    */   private final String insert;
/*    */ 
/*    */   public Stat(String name, String update, String insert)
/*    */   {
/* 11 */     this.name = name;
/* 12 */     this.update = update;
/* 13 */     this.insert = insert;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 17 */     return this.name;
/*    */   }
/*    */ 
/*    */   public String getInsert() {
/* 21 */     return this.insert;
/*    */   }
/*    */ 
/*    */   public String getUpdate() {
/* 25 */     return this.update;
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.api.Stat
 * JD-Core Version:    0.6.2
 */