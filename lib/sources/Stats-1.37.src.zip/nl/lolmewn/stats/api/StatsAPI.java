/*     */ package nl.lolmewn.stats.api;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.util.Collection;
/*     */ import java.util.List;
/*     */ import nl.lolmewn.stats.Main;
/*     */ import nl.lolmewn.stats.MySQL;
/*     */ import nl.lolmewn.stats.Settings;
/*     */ import nl.lolmewn.stats.StatType;
/*     */ import nl.lolmewn.stats.StatTypes;
/*     */ import nl.lolmewn.stats.player.PlayerManager;
/*     */ import nl.lolmewn.stats.player.StatData;
/*     */ import nl.lolmewn.stats.player.StatsPlayer;
/*     */ import nl.lolmewn.stats.signs.SignManager;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class StatsAPI
/*     */ {
/*     */   private final Main plugin;
/*     */ 
/*     */   public StatsAPI(Main plugin)
/*     */   {
/*  26 */     this.plugin = plugin;
/*     */   }
/*     */ 
/*     */   public double getPlaytime(String name)
/*     */   {
/*  34 */     StatsPlayer player = getStatsPlayer(name);
/*  35 */     return player.getStatData(getStat("Playtime"), true).getValue(new Object[0]);
/*     */   }
/*     */ 
/*     */   public double getPlaytime(String name, String world)
/*     */   {
/*  44 */     StatsPlayer player = getStatsPlayer(name);
/*  45 */     return player.getStatData(getStat("Playtime"), world, true).getValue(new Object[0]);
/*     */   }
/*     */ 
/*     */   public double getTotalBlocksBroken(String name)
/*     */   {
/*  53 */     StatsPlayer player = getStatsPlayer(name);
/*  54 */     StatData stat = player.getStatData(getStat("Block break"), false);
/*  55 */     if (stat == null) {
/*  56 */       return 0.0D;
/*     */     }
/*  58 */     double value = 0.0D;
/*  59 */     for (Object[] vars : stat.getAllVariables()) {
/*  60 */       value += stat.getValue(vars);
/*     */     }
/*  62 */     return value;
/*     */   }
/*     */ 
/*     */   public double getTotalBlocksBroken(String name, String world)
/*     */   {
/*  71 */     StatsPlayer player = getStatsPlayer(name);
/*  72 */     StatData stat = player.getStatData(getStat("Block break"), world, false);
/*  73 */     if (stat == null) {
/*  74 */       return 0.0D;
/*     */     }
/*  76 */     double value = 0.0D;
/*  77 */     for (Object[] vars : stat.getAllVariables()) {
/*  78 */       value += stat.getValue(vars);
/*     */     }
/*  80 */     return value;
/*     */   }
/*     */ 
/*     */   public double getTotalBlocksPlaced(String name)
/*     */   {
/*  88 */     StatsPlayer player = getStatsPlayer(name);
/*  89 */     StatData stat = player.getStatData(getStat("Block place"), false);
/*  90 */     if (stat == null) {
/*  91 */       return 0.0D;
/*     */     }
/*  93 */     double value = 0.0D;
/*  94 */     for (Object[] vars : stat.getAllVariables()) {
/*  95 */       value += stat.getValue(vars);
/*     */     }
/*  97 */     return value;
/*     */   }
/*     */ 
/*     */   public double getTotalBlocksPlaced(String name, String world)
/*     */   {
/* 106 */     StatsPlayer player = getStatsPlayer(name);
/* 107 */     StatData stat = player.getStatData(getStat("Block place"), world, false);
/* 108 */     if (stat == null) {
/* 109 */       return 0.0D;
/*     */     }
/* 111 */     double value = 0.0D;
/* 112 */     for (Object[] vars : stat.getAllVariables()) {
/* 113 */       value += stat.getValue(vars);
/*     */     }
/* 115 */     return value;
/*     */   }
/*     */ 
/*     */   public double getTotalDeaths(String name)
/*     */   {
/* 123 */     StatsPlayer player = getStatsPlayer(name);
/* 124 */     StatData stat = player.getStatData(getStat("Death"), true);
/* 125 */     if (stat == null) {
/* 126 */       return 0.0D;
/*     */     }
/* 128 */     double value = 0.0D;
/* 129 */     for (Object[] vars : stat.getAllVariables()) {
/* 130 */       value += stat.getValue(vars);
/*     */     }
/* 132 */     return value;
/*     */   }
/*     */ 
/*     */   public double getTotalDeaths(String name, String world)
/*     */   {
/* 141 */     StatsPlayer player = getStatsPlayer(name);
/* 142 */     StatData stat = player.getStatData(getStat("Death"), world, true);
/* 143 */     if (stat == null) {
/* 144 */       return 0.0D;
/*     */     }
/* 146 */     double value = 0.0D;
/* 147 */     for (Object[] vars : stat.getAllVariables()) {
/* 148 */       value += stat.getValue(vars);
/*     */     }
/* 150 */     return value;
/*     */   }
/*     */ 
/*     */   public double getTotalKills(String name)
/*     */   {
/* 158 */     StatsPlayer player = getStatsPlayer(name);
/* 159 */     StatData stat = player.getStatData(getStat("Kill"), true);
/* 160 */     if (stat == null) {
/* 161 */       return 0.0D;
/*     */     }
/* 163 */     double value = 0.0D;
/* 164 */     for (Object[] vars : stat.getAllVariables()) {
/* 165 */       value += stat.getValue(vars);
/*     */     }
/* 167 */     return value;
/*     */   }
/*     */ 
/*     */   public double getTotalKills(String name, String world)
/*     */   {
/* 176 */     StatsPlayer player = getStatsPlayer(name);
/* 177 */     StatData stat = player.getStatData(getStat("Kill"), world, true);
/* 178 */     if (stat == null) {
/* 179 */       return 0.0D;
/*     */     }
/* 181 */     double value = 0.0D;
/* 182 */     for (Object[] vars : stat.getAllVariables()) {
/* 183 */       value += stat.getValue(vars);
/*     */     }
/* 185 */     return value;
/*     */   }
/*     */ 
/*     */   public double getTotalBlocks(String player)
/*     */   {
/* 193 */     return getTotalBlocksBroken(player) + getTotalBlocksPlaced(player);
/*     */   }
/*     */ 
/*     */   public double getTotalBlocks(String player, String world)
/*     */   {
/* 202 */     return getTotalBlocksBroken(player, world) + getTotalBlocksPlaced(player, world);
/*     */   }
/*     */ 
/*     */   public String getDatabasePrefix()
/*     */   {
/* 212 */     return this.plugin.getSettings().getDbPrefix();
/*     */   }
/*     */ 
/*     */   public SignManager getSignManager()
/*     */   {
/* 220 */     return this.plugin.getSignManager();
/*     */   }
/*     */ 
/*     */   public Connection getConnection()
/*     */   {
/* 228 */     return this.plugin.getMySQL().getConnection();
/*     */   }
/*     */ 
/*     */   public boolean isStatsSign(Location loc)
/*     */   {
/* 237 */     return this.plugin.getSignManager().getSignAt(loc) != null;
/*     */   }
/*     */ 
/*     */   public StatsPlayer getStatsPlayer(String playername)
/*     */   {
/* 248 */     return this.plugin.getPlayerManager().getPlayer(playername);
/*     */   }
/*     */ 
/*     */   public boolean isStatEnabled(String type)
/*     */   {
/* 257 */     return !this.plugin.getSettings().getDisabledStats().contains(type);
/*     */   }
/*     */ 
/*     */   public boolean isStatEnabled(StatType type) {
/* 261 */     return !this.plugin.getSettings().getDisabledStats().contains(type.makeMePretty());
/*     */   }
/*     */ 
/*     */   public Stat getStat(String statName) {
/* 265 */     return this.plugin.getStatTypes().find(statName);
/*     */   }
/*     */ 
/*     */   public Collection<Stat> getAllStats() {
/* 269 */     return this.plugin.getStatTypes().values();
/*     */   }
/*     */ 
/*     */   public Stat getStatExact(String exactStatName) {
/* 273 */     return (Stat)this.plugin.getStatTypes().get(exactStatName);
/*     */   }
/*     */ 
/*     */   public StatsPlayer getPlayer(String name) {
/* 277 */     return this.plugin.getPlayerManager().getPlayer(name);
/*     */   }
/*     */ 
/*     */   public StatsPlayer getPlayer(Player player) {
/* 281 */     return getPlayer(player.getName());
/*     */   }
/*     */ 
/*     */   public Stat addStat(String statName, String updateQuery, String insertQuery) {
/* 285 */     return this.plugin.getStatTypes().addStat(statName, updateQuery, insertQuery);
/*     */   }
/*     */ 
/*     */   public boolean isUsingBetaFunctions() {
/* 289 */     return this.plugin.getSettings().isUsingBetaFunctions();
/*     */   }
/*     */ 
/*     */   public boolean isCreatingSnapshots() {
/* 293 */     return (this.plugin.getSettings().createSnapshots()) && (isUsingBetaFunctions());
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.api.StatsAPI
 * JD-Core Version:    0.6.2
 */