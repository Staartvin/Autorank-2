/*     */ package nl.lolmewn.stats.mysql;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ public abstract class Database
/*     */ {
/*     */   protected Logger log;
/*     */   protected final String PREFIX;
/*     */   protected final String DATABASE_PREFIX;
/*     */   protected boolean connected;
/*     */   public int lastUpdate;
/*     */ 
/*     */   public Database(Logger log, String prefix, String dp)
/*     */   {
/*  40 */     this.log = log;
/*  41 */     this.PREFIX = prefix;
/*  42 */     this.DATABASE_PREFIX = dp;
/*  43 */     this.connected = false;
/*     */   }
/*     */ 
/*     */   protected void writeInfo(String toWrite)
/*     */   {
/*  55 */     if (toWrite != null)
/*  56 */       this.log.info(this.PREFIX + this.DATABASE_PREFIX + toWrite);
/*     */   }
/*     */ 
/*     */   protected void writeError(String toWrite, boolean severe)
/*     */   {
/*  71 */     if (toWrite != null)
/*  72 */       if (severe)
/*  73 */         this.log.severe(this.PREFIX + this.DATABASE_PREFIX + toWrite);
/*     */       else
/*  75 */         this.log.warning(this.PREFIX + this.DATABASE_PREFIX + toWrite);
/*     */   }
/*     */ 
/*     */   abstract boolean initialize();
/*     */ 
/*     */   abstract Connection open();
/*     */ 
/*     */   abstract Connection getConnection();
/*     */ 
/*     */   protected Statements getStatement(String query)
/*     */   {
/* 110 */     String trimmedQuery = query.trim();
/* 111 */     if (trimmedQuery.substring(0, 6).equalsIgnoreCase("SELECT"))
/* 112 */       return Statements.SELECT;
/* 113 */     if (trimmedQuery.substring(0, 6).equalsIgnoreCase("INSERT"))
/* 114 */       return Statements.INSERT;
/* 115 */     if (trimmedQuery.substring(0, 6).equalsIgnoreCase("UPDATE"))
/* 116 */       return Statements.UPDATE;
/* 117 */     if (trimmedQuery.substring(0, 6).equalsIgnoreCase("DELETE"))
/* 118 */       return Statements.DELETE;
/* 119 */     if (trimmedQuery.substring(0, 6).equalsIgnoreCase("CREATE"))
/* 120 */       return Statements.CREATE;
/* 121 */     if (trimmedQuery.substring(0, 5).equalsIgnoreCase("ALTER"))
/* 122 */       return Statements.ALTER;
/* 123 */     if (trimmedQuery.substring(0, 4).equalsIgnoreCase("DROP"))
/* 124 */       return Statements.DROP;
/* 125 */     if (trimmedQuery.substring(0, 8).equalsIgnoreCase("TRUNCATE"))
/* 126 */       return Statements.TRUNCATE;
/* 127 */     if (trimmedQuery.substring(0, 6).equalsIgnoreCase("RENAME"))
/* 128 */       return Statements.RENAME;
/* 129 */     if (trimmedQuery.substring(0, 2).equalsIgnoreCase("DO"))
/* 130 */       return Statements.DO;
/* 131 */     if (trimmedQuery.substring(0, 7).equalsIgnoreCase("REPLACE"))
/* 132 */       return Statements.REPLACE;
/* 133 */     if (trimmedQuery.substring(0, 4).equalsIgnoreCase("LOAD"))
/* 134 */       return Statements.LOAD;
/* 135 */     if (trimmedQuery.substring(0, 7).equalsIgnoreCase("HANDLER"))
/* 136 */       return Statements.HANDLER;
/* 137 */     if (trimmedQuery.substring(0, 4).equalsIgnoreCase("CALL")) {
/* 138 */       return Statements.CALL;
/*     */     }
/* 140 */     return Statements.SELECT;
/*     */   }
/*     */ 
/*     */   protected static enum Statements
/*     */   {
/*  22 */     SELECT, INSERT, UPDATE, DELETE, DO, REPLACE, LOAD, HANDLER, CALL, 
/*  23 */     CREATE, ALTER, DROP, TRUNCATE, RENAME, 
/*     */ 
/*  26 */     START, COMMIT, ROLLBACK, SAVEPOINT, LOCK, UNLOCK, 
/*  27 */     PREPARE, EXECUTE, DEALLOCATE, 
/*  28 */     SET, SHOW, 
/*  29 */     DESCRIBE, EXPLAIN, HELP, USE, 
/*     */ 
/*  32 */     ANALYZE, ATTACH, BEGIN, DETACH, END, INDEXED, ON, PRAGMA, REINDEX, RELEASE, VACUUM;
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.mysql.Database
 * JD-Core Version:    0.6.2
 */