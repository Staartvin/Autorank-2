/*    */ package nl.lolmewn.stats.mysql;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.SQLException;
/*    */ import java.util.logging.Logger;
/*    */ import org.apache.commons.dbcp.DriverManagerConnectionFactory;
/*    */ import org.apache.commons.dbcp.PoolableConnectionFactory;
/*    */ import org.apache.commons.dbcp.PoolingDataSource;
/*    */ import org.apache.commons.pool.impl.GenericObjectPool;
/*    */ 
/*    */ public class MySQLLib extends Database
/*    */ {
/*    */   private PoolingDataSource source;
/*    */ 
/*    */   public MySQLLib(Logger log, String prefix, String hostname, String portnmbr, String database, String username, String password)
/*    */   {
/* 29 */     super(log, prefix, "[MySQL] ");
/* 30 */     initialize();
/* 31 */     String url = "jdbc:mysql://" + hostname + ":" + portnmbr + "/" + database + "?zeroDateTimeBehavior=convertToNull";
/* 32 */     PoolableConnectionFactory factory = new PoolableConnectionFactory(new DriverManagerConnectionFactory(url, username, password), new GenericObjectPool(null, 15, (byte)2, 1000L, 10, true, true), null, "SELECT 1", false, true, 8);
/*    */ 
/* 40 */     this.source = new PoolingDataSource(factory.getPool());
/*    */   }
/*    */ 
/*    */   protected final boolean initialize()
/*    */   {
/*    */     try {
/* 46 */       Class.forName("com.mysql.jdbc.Driver");
/* 47 */       return true;
/*    */     } catch (ClassNotFoundException e) {
/* 49 */       writeError("Class not found in initialize(): " + e.getMessage() + ".", true);
/* 50 */     }return false;
/*    */   }
/*    */ 
/*    */   public synchronized Connection open()
/*    */   {
/* 56 */     if (initialize()) {
/*    */       try {
/* 58 */         return this.source.getConnection();
/*    */       } catch (SQLException ex) {
/* 60 */         this.log.severe("Couldn't retrieve connection from pool, erroring");
/*    */       }
/*    */     }
/* 63 */     return null;
/*    */   }
/*    */ 
/*    */   public Connection getConnection()
/*    */   {
/* 68 */     return open();
/*    */   }
/*    */ 
/*    */   public void exit() {
/* 72 */     this.source = null;
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.mysql.MySQLLib
 * JD-Core Version:    0.6.2
 */