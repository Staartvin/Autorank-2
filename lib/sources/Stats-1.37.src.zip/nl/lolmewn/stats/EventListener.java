/*     */ package nl.lolmewn.stats;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import nl.lolmewn.stats.api.Stat;
/*     */ import nl.lolmewn.stats.player.PlayerManager;
/*     */ import nl.lolmewn.stats.player.StatData;
/*     */ import nl.lolmewn.stats.player.StatsPlayer;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Arrow;
/*     */ import org.bukkit.entity.Boat;
/*     */ import org.bukkit.entity.Entity;
/*     */ import org.bukkit.entity.EntityType;
/*     */ import org.bukkit.entity.Horse;
/*     */ import org.bukkit.entity.HumanEntity;
/*     */ import org.bukkit.entity.LivingEntity;
/*     */ import org.bukkit.entity.Minecart;
/*     */ import org.bukkit.entity.Pig;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.event.block.BlockPlaceEvent;
/*     */ import org.bukkit.event.entity.EntityDamageByEntityEvent;
/*     */ import org.bukkit.event.entity.EntityDamageEvent;
/*     */ import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
/*     */ import org.bukkit.event.entity.EntityDeathEvent;
/*     */ import org.bukkit.event.entity.EntityShootBowEvent;
/*     */ import org.bukkit.event.entity.FoodLevelChangeEvent;
/*     */ import org.bukkit.event.entity.PlayerDeathEvent;
/*     */ import org.bukkit.event.inventory.CraftItemEvent;
/*     */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*     */ import org.bukkit.event.player.PlayerBedEnterEvent;
/*     */ import org.bukkit.event.player.PlayerBucketEmptyEvent;
/*     */ import org.bukkit.event.player.PlayerBucketFillEvent;
/*     */ import org.bukkit.event.player.PlayerChangedWorldEvent;
/*     */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*     */ import org.bukkit.event.player.PlayerDropItemEvent;
/*     */ import org.bukkit.event.player.PlayerEggThrowEvent;
/*     */ import org.bukkit.event.player.PlayerExpChangeEvent;
/*     */ import org.bukkit.event.player.PlayerFishEvent;
/*     */ import org.bukkit.event.player.PlayerItemBreakEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerKickEvent;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.event.player.PlayerPickupItemEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.event.player.PlayerShearEntityEvent;
/*     */ import org.bukkit.event.player.PlayerTeleportEvent;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class EventListener
/*     */   implements Listener
/*     */ {
/*     */   private final Main plugin;
/*  28 */   private final String permissionNode = "stats.track";
/*  29 */   private ConcurrentHashMap<String, Double> moveHolder = new ConcurrentHashMap();
/*  30 */   private final Object[] empty = new Object[0];
/*     */ 
/*     */   private Main getPlugin() {
/*  33 */     return this.plugin;
/*     */   }
/*     */ 
/*     */   public EventListener(Main aThis) {
/*  37 */     this.plugin = aThis;
/*  38 */     this.plugin.getServer().getScheduler().runTaskTimerAsynchronously(this.plugin, new Runnable()
/*     */     {
/*     */       public void run() {
/*  41 */         for (String key : EventListener.this.moveHolder.keySet())
/*  42 */           if (((Double)EventListener.this.moveHolder.get(key)).doubleValue() != 0.0D)
/*     */           {
/*  45 */             if (EventListener.this.plugin.getSettings().isUsingBetaFunctions()) {
/*  46 */               String[] args = key.split(",");
/*  47 */               int type = Integer.parseInt(args[0].substring(1));
/*  48 */               String player = args[1].substring(1);
/*  49 */               String world = args[2].substring(1, args[2].indexOf("]"));
/*  50 */               EventListener.this.plugin.getPlayerManager().getPlayer(player).getStatData(EventListener.this.getStat("Move"), world, true).addUpdate(new Object[] { Integer.valueOf(type) }, ((Double)EventListener.this.moveHolder.get(key)).doubleValue());
/*  51 */               EventListener.this.moveHolder.replace(key, Double.valueOf(0.0D));
/*     */             } else {
/*  53 */               int type = Integer.parseInt(key.substring(1, 2));
/*  54 */               String player = key.substring(key.indexOf(",") + 2, key.indexOf("]"));
/*  55 */               EventListener.this.plugin.getPlayerManager().getPlayer(player).getStatData(EventListener.this.getStat("Move"), true).addUpdate(new Object[] { Integer.valueOf(type) }, ((Double)EventListener.this.moveHolder.get(key)).doubleValue());
/*  56 */               EventListener.this.moveHolder.replace(key, Double.valueOf(0.0D));
/*     */             }
/*     */           }
/*     */       }
/*     */     }
/*     */     , 20L, 20L);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void onBlockBreak(BlockBreakEvent event)
/*     */   {
/*  65 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/*  66 */       return;
/*     */     }
/*  68 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/*  69 */       return;
/*     */     }
/*  71 */     if (getPlugin().getSettings().getDisabledStats().contains("Block break")) {
/*  72 */       return;
/*     */     }
/*  74 */     if (event.getBlock().getType().equals(Material.AIR)) {
/*  75 */       return;
/*     */     }
/*  77 */     if (this.plugin.getSettings().isUsingBetaFunctions())
/*  78 */       this.plugin.getPlayerManager().getPlayer(event.getPlayer().getName()).getStatData(getStat("Block break"), event.getBlock().getWorld().getName(), true).addUpdate(new Object[] { Integer.valueOf(event.getBlock().getTypeId()), Byte.valueOf(event.getBlock().getData()), Boolean.valueOf(true) }, 1.0D);
/*     */     else
/*  80 */       this.plugin.getPlayerManager().getPlayer(event.getPlayer().getName()).getStatData(getStat("Block break"), true).addUpdate(new Object[] { Integer.valueOf(event.getBlock().getTypeId()), Byte.valueOf(event.getBlock().getData()), Boolean.valueOf(true) }, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void onBlockPlace(BlockPlaceEvent event)
/*     */   {
/*  86 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/*  87 */       return;
/*     */     }
/*  89 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/*  90 */       return;
/*     */     }
/*  92 */     if (getPlugin().getSettings().getDisabledStats().contains("Block place")) {
/*  93 */       return;
/*     */     }
/*  95 */     if (this.plugin.getSettings().isUsingBetaFunctions())
/*  96 */       this.plugin.getPlayerManager().getPlayer(event.getPlayer().getName()).getStatData(getStat("Block place"), event.getBlock().getWorld().getName(), true).addUpdate(new Object[] { Integer.valueOf(event.getBlock().getTypeId()), Byte.valueOf(event.getBlock().getData()), Boolean.valueOf(false) }, 1.0D);
/*     */     else
/*  98 */       this.plugin.getPlayerManager().getPlayer(event.getPlayer().getName()).getStatData(getStat("Block place"), true).addUpdate(new Object[] { Integer.valueOf(event.getBlock().getTypeId()), Byte.valueOf(event.getBlock().getData()), Boolean.valueOf(false) }, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void onPlayerMove(PlayerMoveEvent event)
/*     */   {
/* 104 */     if ((event instanceof PlayerTeleportEvent)) {
/* 105 */       return;
/*     */     }
/* 107 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 108 */       return;
/*     */     }
/* 110 */     if ((getPlugin().getConfig().getBoolean("ignoreFlying", false)) && (event.getPlayer().isFlying())) {
/* 111 */       return;
/*     */     }
/* 113 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 114 */       return;
/*     */     }
/* 116 */     if (getPlugin().getSettings().getDisabledStats().contains("Move")) {
/* 117 */       return;
/*     */     }
/* 119 */     if (!event.getFrom().getWorld().equals(event.getTo().getWorld())) {
/* 120 */       return;
/*     */     }
/* 122 */     Player p = event.getPlayer();
/* 123 */     double distance = event.getFrom().distance(event.getTo());
/* 124 */     if ((distance < 0.0001D) || (distance > 10.0D)) {
/* 125 */       return;
/*     */     }
/* 127 */     int type = 0;
/* 128 */     if (p.isInsideVehicle()) {
/* 129 */       Entity vehicle = p.getVehicle();
/* 130 */       if ((vehicle instanceof Boat))
/* 131 */         type = 1;
/* 132 */       else if ((vehicle instanceof Minecart))
/* 133 */         type = 2;
/* 134 */       else if ((vehicle instanceof Pig)) {
/* 135 */         if ((vehicle.isInsideVehicle()) && ((vehicle.getVehicle() instanceof Minecart)))
/* 136 */           type = 4;
/*     */         else
/* 138 */           type = 3;
/*     */       }
/*     */       else
/*     */         try {
/* 142 */           if ((vehicle instanceof Horse))
/* 143 */             type = 5;
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/*     */         }
/*     */     }
/*     */     String key;
/*     */     String key;
/* 152 */     if (getPlugin().getSettings().isUsingBetaFunctions())
/* 153 */       key = Arrays.toString(new Object[] { Integer.valueOf(type), event.getPlayer().getName(), event.getFrom().getWorld().getName() });
/*     */     else {
/* 155 */       key = Arrays.toString(new Object[] { Integer.valueOf(type), event.getPlayer().getName() });
/*     */     }
/* 157 */     if (this.moveHolder.replace(key, Double.valueOf(distance + (this.moveHolder.containsKey(key) ? ((Double)this.moveHolder.get(key)).doubleValue() : 0.0D))) == null)
/* 158 */       this.moveHolder.put(key, Double.valueOf(distance));
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR)
/*     */   public void onEntityDeath(EntityDeathEvent event)
/*     */   {
/* 164 */     if (event.getEntity().hasMetadata("NPC")) {
/* 165 */       return;
/*     */     }
/* 167 */     EntityType e = event.getEntityType();
/* 168 */     if (event.getEntity().getKiller() != null) {
/* 169 */       if ((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getEntity().getKiller().hasPermission("stats.track"))) {
/* 170 */         return;
/*     */       }
/* 172 */       if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getEntity().getKiller().getGameMode().equals(GameMode.CREATIVE))) {
/* 173 */         return;
/*     */       }
/* 175 */       if (getPlugin().getSettings().getDisabledStats().contains("Kill")) {
/* 176 */         return;
/*     */       }
/* 178 */       StatsPlayer p = this.plugin.getPlayerManager().getPlayer(event.getEntity().getKiller().getName());
/* 179 */       if (this.plugin.getSettings().isUsingBetaFunctions())
/* 180 */         p.updateStat(getStat("Kill"), new Object[] { e.toString().substring(0, 1) + e.toString().substring(1).toLowerCase() }, 1.0D, event.getEntity().getWorld().getName());
/*     */       else
/* 182 */         p.updateStat(getStat("Kill"), new Object[] { e.toString().substring(0, 1) + e.toString().substring(1).toLowerCase() }, 1.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR)
/*     */   public void onPlayerDeath(PlayerDeathEvent event)
/*     */   {
/* 189 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getEntity().hasPermission("stats.track"))) || (event.getEntity().hasMetadata("NPC"))) {
/* 190 */       return;
/*     */     }
/* 192 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getEntity().getGameMode().equals(GameMode.CREATIVE))) {
/* 193 */       return;
/*     */     }
/* 195 */     if (getPlugin().getSettings().getDisabledStats().contains("Death")) {
/* 196 */       return;
/*     */     }
/* 198 */     EntityDamageEvent e = event.getEntity().getLastDamageCause();
/* 199 */     Player dead = event.getEntity();
/* 200 */     StatsPlayer player = getPlugin().getPlayerManager().getPlayer(dead.getName());
/* 201 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (dead.getGameMode().equals(GameMode.CREATIVE))) {
/* 202 */       return;
/*     */     }
/* 204 */     if ((e instanceof EntityDamageByEntityEvent)) {
/* 205 */       EntityDamageByEntityEvent ev = (EntityDamageByEntityEvent)e;
/* 206 */       if ((ev.getDamager() instanceof Arrow)) {
/* 207 */         Arrow a = (Arrow)ev.getDamager();
/* 208 */         if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 209 */           player.updateStat(getStat("Death"), new Object[] { a.getShooter().getType().toString().substring(0, 1) + a.getShooter().getType().toString().substring(1).toLowerCase(), Boolean.valueOf(true) }, 1.0D, dead.getWorld().getName());
/*     */         }
/*     */         else
/*     */         {
/* 214 */           player.updateStat(getStat("Death"), new Object[] { a.getShooter().getType().toString().substring(0, 1) + a.getShooter().getType().toString().substring(1).toLowerCase(), Boolean.valueOf(true) }, 1.0D);
/*     */         }
/*     */ 
/*     */       }
/* 219 */       else if (this.plugin.getSettings().isUsingBetaFunctions())
/*     */       {
/* 221 */         player.updateStat(getStat("Death"), new Object[] { ev.getDamager().getType().toString().substring(0, 1) + ev.getDamager().getType().toString().substring(1).toLowerCase(), Boolean.valueOf(true) }, 1.0D, dead.getWorld().getName());
/*     */       }
/*     */       else {
/* 224 */         player.updateStat(getStat("Death"), new Object[] { ev.getDamager().getType().toString().substring(0, 1) + ev.getDamager().getType().toString().substring(1).toLowerCase(), Boolean.valueOf(true) }, 1.0D);
/*     */       }
/*     */ 
/*     */     }
/* 229 */     else if (e == null) {
/* 230 */       if (this.plugin.getSettings().isUsingBetaFunctions())
/* 231 */         player.updateStat(getStat("Death"), new Object[] { "Suicide", Boolean.valueOf(true) }, 1.0D, dead.getWorld().getName());
/*     */       else {
/* 233 */         player.updateStat(getStat("Death"), new Object[] { "Suicide", Boolean.valueOf(true) }, 1.0D);
/*     */       }
/*     */     }
/* 236 */     else if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 237 */       player.updateStat(getStat("Death"), new Object[] { e.getCause().toString().substring(0, 1) + e.getCause().toString().substring(1).toLowerCase(), Boolean.valueOf(true) }, 1.0D, dead.getWorld().getName());
/*     */     }
/*     */     else {
/* 240 */       player.updateStat(getStat("Death"), new Object[] { e.getCause().toString().substring(0, 1) + e.getCause().toString().substring(1).toLowerCase(), Boolean.valueOf(true) }, 1.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR)
/*     */   public void logout(PlayerQuitEvent event)
/*     */   {
/* 250 */     if ((getPlugin().getSettings().getDisabledStats().contains("Lastleave")) || (event.getPlayer().hasMetadata("NPC"))) {
/* 251 */       return;
/*     */     }
/* 253 */     StatsPlayer player = getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName());
/* 254 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 255 */       StatData stat = player.getStatData(getStat("Lastleave"), event.getPlayer().getWorld().getName(), true);
/* 256 */       stat.setCurrentValue(this.empty, System.currentTimeMillis());
/* 257 */       stat.forceUpdate(this.empty);
/*     */     } else {
/* 259 */       StatData stat = player.getStatData(getStat("Lastleave"), true);
/* 260 */       stat.setCurrentValue(this.empty, System.currentTimeMillis());
/* 261 */       stat.forceUpdate(this.empty);
/*     */     }
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void login(PlayerJoinEvent event) {
/* 267 */     if (event.getPlayer().hasMetadata("NPC")) {
/* 268 */       return;
/*     */     }
/* 270 */     StatsPlayer player = getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName());
/* 271 */     if (!getPlugin().getSettings().getDisabledStats().contains("Lastjoin")) {
/* 272 */       if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 273 */         StatData lastjoinStat = player.getStatData(getStat("Lastjoin"), event.getPlayer().getWorld().getName(), true);
/* 274 */         lastjoinStat.setCurrentValue(this.empty, System.currentTimeMillis());
/* 275 */         lastjoinStat.forceUpdate(this.empty);
/*     */       } else {
/* 277 */         StatData lastjoinStat = player.getStatData(getStat("Lastjoin"), true);
/* 278 */         lastjoinStat.setCurrentValue(this.empty, System.currentTimeMillis());
/* 279 */         lastjoinStat.forceUpdate(this.empty);
/*     */       }
/*     */     }
/* 282 */     if (getPlugin().getSettings().getDisabledStats().contains("Joins")) {
/* 283 */       return;
/*     */     }
/* 285 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 286 */       StatData joinsStat = player.getStatData(getStat("Joins"), event.getPlayer().getWorld().getName(), true);
/* 287 */       joinsStat.addUpdate(this.empty, 1.0D);
/*     */     } else {
/* 289 */       StatData joinsStat = player.getStatData(getStat("Joins"), true);
/* 290 */       joinsStat.addUpdate(this.empty, 1.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void XPChange(PlayerExpChangeEvent event) {
/* 296 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 297 */       return;
/*     */     }
/* 299 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 300 */       return;
/*     */     }
/* 302 */     if (getPlugin().getSettings().getDisabledStats().contains("Xp gained")) {
/* 303 */       return;
/*     */     }
/* 305 */     if (event.getAmount() > 0)
/* 306 */       if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 307 */         getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).getStatData(getStat("Xp gained"), event.getPlayer().getWorld().getName(), true).addUpdate(this.empty, event.getAmount());
/*     */       }
/*     */       else
/* 310 */         getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).getStatData(getStat("Xp gained"), true).addUpdate(this.empty, event.getAmount());
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void fish(PlayerFishEvent event)
/*     */   {
/* 318 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 319 */       return;
/*     */     }
/* 321 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 322 */       return;
/*     */     }
/* 324 */     if (getPlugin().getSettings().getDisabledStats().contains("Fish catched")) {
/* 325 */       return;
/*     */     }
/* 327 */     if (event.getCaught() != null)
/* 328 */       if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 329 */         getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Fish catched"), this.empty, 1.0D, event.getPlayer().getWorld().getName());
/*     */       }
/*     */       else
/* 332 */         getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Fish catched"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void kick(PlayerKickEvent event)
/*     */   {
/* 340 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 341 */       return;
/*     */     }
/* 343 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 344 */       return;
/*     */     }
/* 346 */     if (getPlugin().getSettings().getDisabledStats().contains("Times kicked")) {
/* 347 */       return;
/*     */     }
/* 349 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 350 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Times kicked"), this.empty, 1.0D, event.getPlayer().getWorld().getName());
/*     */     }
/*     */     else
/* 353 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Times kicked"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void eggThrow(PlayerEggThrowEvent event)
/*     */   {
/* 360 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 361 */       return;
/*     */     }
/* 363 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 364 */       return;
/*     */     }
/* 366 */     if (getPlugin().getSettings().getDisabledStats().contains("Eggs thrown")) {
/* 367 */       return;
/*     */     }
/* 369 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 370 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Eggs thrown"), this.empty, 1.0D, event.getPlayer().getWorld().getName());
/*     */     }
/*     */     else
/* 373 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Eggs thrown"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void onEntityDamage(EntityDamageEvent event)
/*     */   {
/* 380 */     if (!(event.getEntity() instanceof Player)) {
/* 381 */       return;
/*     */     }
/* 383 */     Player ent = (Player)event.getEntity();
/* 384 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!ent.hasPermission("stats.track"))) || (ent.hasMetadata("NPC"))) {
/* 385 */       return;
/*     */     }
/* 387 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (ent.getGameMode().equals(GameMode.CREATIVE))) {
/* 388 */       return;
/*     */     }
/* 390 */     if (!getPlugin().getSettings().getDisabledStats().contains("Damage taken")) {
/* 391 */       if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 392 */         getPlugin().getPlayerManager().getPlayer(ent.getName()).getStatData(getStat("Damage taken"), ent.getWorld().getName(), true).addUpdate(this.empty, event.getDamage());
/*     */       }
/*     */       else {
/* 395 */         getPlugin().getPlayerManager().getPlayer(ent.getName()).getStatData(getStat("Damage taken"), true).addUpdate(this.empty, event.getDamage());
/*     */       }
/*     */     }
/*     */ 
/* 399 */     if (event.getCause().equals(EntityDamageEvent.DamageCause.FIRE)) {
/* 400 */       if (getPlugin().getSettings().getDisabledStats().contains("On fire")) {
/* 401 */         return;
/*     */       }
/* 403 */       if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 404 */         getPlugin().getPlayerManager().getPlayer(ent.getName()).getStatData(getStat("On fire"), ent.getWorld().getName(), true).addUpdate(this.empty, event.getDamage());
/*     */       }
/*     */       else
/* 407 */         getPlugin().getPlayerManager().getPlayer(ent.getName()).getStatData(getStat("On fire"), true).addUpdate(this.empty, event.getDamage());
/*     */     }
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void itemBreak(PlayerItemBreakEvent event)
/*     */   {
/* 415 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 416 */       return;
/*     */     }
/* 418 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 419 */       return;
/*     */     }
/* 421 */     if (getPlugin().getSettings().getDisabledStats().contains("Tools broken")) {
/* 422 */       return;
/*     */     }
/* 424 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 425 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Tools broken"), this.empty, 1.0D, event.getPlayer().getWorld().getName());
/*     */     }
/*     */     else
/* 428 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Tools broken"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void chat(AsyncPlayerChatEvent event)
/*     */   {
/* 435 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 436 */       return;
/*     */     }
/* 438 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 439 */       return;
/*     */     }
/* 441 */     if (getPlugin().getSettings().getDisabledStats().contains("Words said")) {
/* 442 */       return;
/*     */     }
/* 444 */     int words = event.getMessage().split(" ").length;
/* 445 */     words += (words == 0 ? 1 : 0);
/* 446 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 447 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).getStatData(getStat("Words said"), event.getPlayer().getWorld().getName(), true).addUpdate(this.empty, words);
/*     */     }
/*     */     else
/* 450 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).getStatData(getStat("Words said"), true).addUpdate(this.empty, words);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void entityShoot(EntityShootBowEvent event)
/*     */   {
/* 457 */     if (!(event.getEntity() instanceof Player)) {
/* 458 */       return;
/*     */     }
/* 460 */     Player p = (Player)event.getEntity();
/* 461 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!p.hasPermission("stats.track"))) || (p.hasMetadata("NPC"))) {
/* 462 */       return;
/*     */     }
/* 464 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (p.getGameMode().equals(GameMode.CREATIVE))) {
/* 465 */       return;
/*     */     }
/* 467 */     if (getPlugin().getSettings().getDisabledStats().contains("Arrows")) {
/* 468 */       return;
/*     */     }
/* 470 */     if (this.plugin.getSettings().isUsingBetaFunctions())
/* 471 */       getPlugin().getPlayerManager().getPlayer(p.getName()).updateStat(getStat("Arrows"), this.empty, 1.0D, p.getWorld().getName());
/*     */     else
/* 473 */       getPlugin().getPlayerManager().getPlayer(p.getName()).updateStat(getStat("Arrows"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void command(PlayerCommandPreprocessEvent event)
/*     */   {
/* 479 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 480 */       return;
/*     */     }
/* 482 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 483 */       return;
/*     */     }
/* 485 */     if (getPlugin().getSettings().getDisabledStats().contains("Commands done")) {
/* 486 */       return;
/*     */     }
/* 488 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 489 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Commands done"), this.empty, 1.0D, event.getPlayer().getWorld().getName());
/*     */     }
/*     */     else
/* 492 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Commands done"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void craftItem(CraftItemEvent event)
/*     */   {
/* 499 */     if (event.getWhoClicked().hasMetadata("NPC")) {
/* 500 */       return;
/*     */     }
/* 502 */     if ((event.getWhoClicked() instanceof Player)) {
/* 503 */       Player p = (Player)event.getWhoClicked();
/* 504 */       if ((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!p.hasPermission("stats.track"))) {
/* 505 */         return;
/*     */       }
/* 507 */       if ((getPlugin().getSettings().isIgnoreCreative()) && (p.getGameMode().equals(GameMode.CREATIVE))) {
/* 508 */         return;
/*     */       }
/* 510 */       if (getPlugin().getSettings().getDisabledStats().contains("Items crafted")) {
/* 511 */         return;
/*     */       }
/* 513 */       if (this.plugin.getSettings().isUsingBetaFunctions())
/* 514 */         getPlugin().getPlayerManager().getPlayer(p.getName()).updateStat(getStat("Items crafted"), this.empty, 1.0D, p.getWorld().getName());
/*     */       else
/* 516 */         getPlugin().getPlayerManager().getPlayer(p.getName()).updateStat(getStat("Items crafted"), this.empty, 1.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void eat(FoodLevelChangeEvent event)
/*     */   {
/* 523 */     if (event.getEntity().hasMetadata("NPC")) {
/* 524 */       return;
/*     */     }
/* 526 */     if ((event.getEntity() instanceof Player)) {
/* 527 */       Player p = (Player)event.getEntity();
/* 528 */       if ((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!p.hasPermission("stats.track"))) {
/* 529 */         return;
/*     */       }
/* 531 */       if ((getPlugin().getSettings().isIgnoreCreative()) && (p.getGameMode().equals(GameMode.CREATIVE))) {
/* 532 */         return;
/*     */       }
/* 534 */       if (getPlugin().getSettings().getDisabledStats().contains("Omnomnom")) {
/* 535 */         return;
/*     */       }
/* 537 */       if (this.plugin.getSettings().isUsingBetaFunctions())
/* 538 */         getPlugin().getPlayerManager().getPlayer(p.getName()).updateStat(getStat("Omnomnom"), this.empty, 1.0D, p.getWorld().getName());
/*     */       else
/* 540 */         getPlugin().getPlayerManager().getPlayer(p.getName()).updateStat(getStat("Omnomnom"), this.empty, 1.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void itemPickup(PlayerPickupItemEvent event)
/*     */   {
/* 547 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 548 */       return;
/*     */     }
/* 550 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 551 */       return;
/*     */     }
/* 553 */     if (getPlugin().getSettings().getDisabledStats().contains("Itempickups")) {
/* 554 */       return;
/*     */     }
/* 556 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 557 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Itempickups"), this.empty, 1.0D, event.getPlayer().getWorld().getName());
/*     */     }
/*     */     else
/* 560 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Itempickups"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void teleports(PlayerTeleportEvent event)
/*     */   {
/* 567 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 568 */       return;
/*     */     }
/* 570 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 571 */       return;
/*     */     }
/* 573 */     if (getPlugin().getSettings().getDisabledStats().contains("Teleports")) {
/* 574 */       return;
/*     */     }
/* 576 */     if (this.plugin.getSettings().isUsingBetaFunctions())
/* 577 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Teleports"), this.empty, 1.0D, event.getPlayer().getWorld().getName());
/*     */     else
/* 579 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Teleports"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void bedEnter(PlayerBedEnterEvent event)
/*     */   {
/* 585 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 586 */       return;
/*     */     }
/* 588 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 589 */       return;
/*     */     }
/* 591 */     if (getPlugin().getSettings().getDisabledStats().contains("Bedenter")) {
/* 592 */       return;
/*     */     }
/* 594 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 595 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Bedenter"), this.empty, 1.0D, event.getPlayer().getWorld().getName());
/*     */     }
/*     */     else
/* 598 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Bedenter"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void bucketFill(PlayerBucketFillEvent event)
/*     */   {
/* 605 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 606 */       return;
/*     */     }
/* 608 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 609 */       return;
/*     */     }
/* 611 */     if (getPlugin().getSettings().getDisabledStats().contains("Bucketfill")) {
/* 612 */       return;
/*     */     }
/* 614 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 615 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Bucketfill"), this.empty, 1.0D, event.getPlayer().getWorld().getName());
/*     */     }
/*     */     else
/* 618 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Bucketfill"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void bucketEmpty(PlayerBucketEmptyEvent event)
/*     */   {
/* 625 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 626 */       return;
/*     */     }
/* 628 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 629 */       return;
/*     */     }
/* 631 */     if (getPlugin().getSettings().getDisabledStats().contains("Bucketempty")) {
/* 632 */       return;
/*     */     }
/* 634 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 635 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Bucketempty"), this.empty, 1.0D, event.getPlayer().getWorld().getName());
/*     */     }
/*     */     else
/* 638 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Bucketempty"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void worldChange(PlayerChangedWorldEvent event)
/*     */   {
/* 645 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 646 */       return;
/*     */     }
/* 648 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 649 */       return;
/*     */     }
/* 651 */     if (getPlugin().getSettings().getDisabledStats().contains("Worldchange")) {
/* 652 */       return;
/*     */     }
/* 654 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 655 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Worldchange"), this.empty, 1.0D, event.getPlayer().getWorld().getName());
/*     */     }
/*     */     else
/* 658 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Worldchange"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void itemDrop(PlayerDropItemEvent event)
/*     */   {
/* 665 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 666 */       return;
/*     */     }
/* 668 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 669 */       return;
/*     */     }
/* 671 */     if (getPlugin().getSettings().getDisabledStats().contains("Itemdrops")) {
/* 672 */       return;
/*     */     }
/* 674 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 675 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Itemdrops"), this.empty, 1.0D, event.getPlayer().getWorld().getName());
/*     */     }
/*     */     else
/* 678 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Itemdrops"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   @EventHandler(priority=EventPriority.MONITOR, ignoreCancelled=true)
/*     */   public void shear(PlayerShearEntityEvent event)
/*     */   {
/* 685 */     if (((this.plugin.getSettings().isUsingPermissionsForTracking()) && (!event.getPlayer().hasPermission("stats.track"))) || (event.getPlayer().hasMetadata("NPC"))) {
/* 686 */       return;
/*     */     }
/* 688 */     if ((getPlugin().getSettings().isIgnoreCreative()) && (event.getPlayer().getGameMode().equals(GameMode.CREATIVE))) {
/* 689 */       return;
/*     */     }
/* 691 */     if (getPlugin().getSettings().getDisabledStats().contains("Shear")) {
/* 692 */       return;
/*     */     }
/* 694 */     if (this.plugin.getSettings().isUsingBetaFunctions()) {
/* 695 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Shear"), this.empty, 1.0D, event.getPlayer().getWorld().getName());
/*     */     }
/*     */     else
/* 698 */       getPlugin().getPlayerManager().getPlayer(event.getPlayer().getName()).updateStat(getStat("Shear"), this.empty, 1.0D);
/*     */   }
/*     */ 
/*     */   public Stat getStat(String name)
/*     */   {
/* 704 */     return (Stat)this.plugin.getStatTypes().get(name);
/*     */   }
/*     */ 
/*     */   public byte getByte(int block, byte def) {
/* 708 */     switch (block) {
/*     */     case 23:
/*     */     case 26:
/*     */     case 27:
/*     */     case 28:
/*     */     case 29:
/*     */     case 33:
/*     */     case 50:
/*     */     case 53:
/*     */     case 54:
/*     */     case 61:
/*     */     case 62:
/*     */     case 63:
/*     */     case 64:
/*     */     case 65:
/*     */     case 66:
/*     */     case 67:
/*     */     case 71:
/*     */     case 75:
/*     */     case 76:
/*     */     case 77:
/*     */     case 85:
/*     */     case 86:
/*     */     case 91:
/*     */     case 92:
/*     */     case 93:
/*     */     case 94:
/*     */     case 95:
/*     */     case 101:
/*     */     case 102:
/*     */     case 103:
/*     */     case 104:
/*     */     case 105:
/*     */     case 106:
/*     */     case 107:
/*     */     case 108:
/*     */     case 109:
/*     */     case 111:
/*     */     case 113:
/*     */     case 114:
/*     */     case 115:
/*     */     case 117:
/*     */     case 127:
/* 751 */       return 0;
/*     */     case 24:
/*     */     case 25:
/*     */     case 30:
/*     */     case 31:
/*     */     case 32:
/*     */     case 34:
/*     */     case 35:
/*     */     case 36:
/*     */     case 37:
/*     */     case 38:
/*     */     case 39:
/*     */     case 40:
/*     */     case 41:
/*     */     case 42:
/*     */     case 43:
/*     */     case 44:
/*     */     case 45:
/*     */     case 46:
/*     */     case 47:
/*     */     case 48:
/*     */     case 49:
/*     */     case 51:
/*     */     case 52:
/*     */     case 55:
/*     */     case 56:
/*     */     case 57:
/*     */     case 58:
/*     */     case 59:
/*     */     case 60:
/*     */     case 68:
/*     */     case 69:
/*     */     case 70:
/*     */     case 72:
/*     */     case 73:
/*     */     case 74:
/*     */     case 78:
/*     */     case 79:
/*     */     case 80:
/*     */     case 81:
/*     */     case 82:
/*     */     case 83:
/*     */     case 84:
/*     */     case 87:
/*     */     case 88:
/*     */     case 89:
/*     */     case 90:
/*     */     case 96:
/*     */     case 97:
/*     */     case 98:
/*     */     case 99:
/*     */     case 100:
/*     */     case 110:
/*     */     case 112:
/*     */     case 116:
/*     */     case 118:
/*     */     case 119:
/*     */     case 120:
/*     */     case 121:
/*     */     case 122:
/*     */     case 123:
/*     */     case 124:
/*     */     case 125:
/* 753 */     case 126: } return def;
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.EventListener
 * JD-Core Version:    0.6.2
 */