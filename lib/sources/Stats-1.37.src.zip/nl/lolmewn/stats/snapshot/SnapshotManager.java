/*     */ package nl.lolmewn.stats.snapshot;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import nl.lolmewn.stats.Main;
/*     */ import nl.lolmewn.stats.MySQL;
/*     */ import nl.lolmewn.stats.Settings;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class SnapshotManager
/*     */ {
/*     */   private final Main plugin;
/*     */   private long timeUntilNextSnapshot;
/*     */   private long interval;
/*     */   private long timeToLive;
/*     */   private boolean sending;
/*     */ 
/*     */   public SnapshotManager(Main m, long timeUntilNextSnapshot, long interval, long timeToLive)
/*     */   {
/*  22 */     this.plugin = m;
/*  23 */     this.timeUntilNextSnapshot = timeUntilNextSnapshot;
/*  24 */     this.interval = interval;
/*  25 */     this.timeToLive = timeToLive;
/*  26 */     startRunnables();
/*     */   }
/*     */ 
/*     */   public final void startRunnables() {
/*  30 */     this.plugin.getServer().getScheduler().runTaskTimerAsynchronously(this.plugin, new Runnable()
/*     */     {
/*     */       public void run() {
/*  33 */         SnapshotManager.this.runSnapshotCreator("auto_generated_snapshot");
/*     */         try {
/*  35 */           Thread.sleep(3000L);
/*     */         } catch (InterruptedException ex) {
/*  37 */           Logger.getLogger(SnapshotManager.class.getName()).log(Level.SEVERE, null, ex);
/*     */         }
/*  39 */         SnapshotManager.this.runSnapshotDeletor();
/*     */       }
/*     */     }
/*     */     , this.timeUntilNextSnapshot, this.interval);
/*     */ 
/*  42 */     this.plugin.getLogger().info("Next snapshot scheduled to run in " + this.timeUntilNextSnapshot + " ticks");
/*     */   }
/*     */ 
/*     */   private void runSnapshotCreator(String name)
/*     */   {
/*     */     try {
/*  48 */       if (this.sending) {
/*  49 */         this.plugin.getLogger().warning("Snapshot creator was still running, aborting!");
/*  50 */         this.plugin.getConfig().set("snapshots.previous", Long.valueOf(System.currentTimeMillis()));
/*  51 */         this.plugin.saveConfig();
/*     */       }
/*     */       else {
/*  54 */         this.sending = true;
/*  55 */         long timeStarted = System.nanoTime();
/*  56 */         String query = "INSERT INTO " + this.plugin.getSettings().getDbPrefix() + "player (player," + "playtime," + "arrows," + "xpgained," + "joins," + "fishcatch," + "damagetaken," + "timeskicked," + "toolsbroken," + "eggsthrown," + "itemscrafted," + "omnomnom," + "onfire," + "wordssaid," + "commandsdone," + "votes," + "teleports," + "itempickups," + "bedenter," + "bucketfill," + "bucketempty," + "worldchange," + "itemdrops," + "shear," + "lastjoin," + "lastleave," + "snapshot_time," + "snapshot_name," + "world)" + " SELECT player," + "playtime," + "arrows," + "xpgained," + "joins," + "fishcatch," + "damagetaken," + "timeskicked," + "toolsbroken," + "eggsthrown," + "itemscrafted," + "omnomnom," + "onfire," + "wordssaid," + "commandsdone," + "votes," + "teleports," + "itempickups," + "bedenter," + "bucketfill," + "bucketempty," + "worldchange," + "itemdrops," + "shear," + "lastjoin," + "lastleave," + "?, " + "?," + "world " + "FROM " + this.plugin.getSettings().getDbPrefix() + "player WHERE snapshot_name='main_snapshot'";
/*     */ 
/* 115 */         Connection con = this.plugin.getMySQL().getConnection();
/* 116 */         PreparedStatement st = con.prepareStatement(query);
/* 117 */         st.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
/* 118 */         st.setString(2, name);
/* 119 */         st.execute();
/* 120 */         st.close();
/* 121 */         query = "INSERT INTO " + this.plugin.getSettings().getDbPrefix() + "block (player," + "blockID, blockData, amount, break, snapshot_time, snapshot_name, world) SELECT " + "player, blockID, blockData, amount, break, ?, ?, world" + " FROM " + this.plugin.getSettings().getDbPrefix() + "block WHERE snapshot_name='main_snapshot'";
/*     */ 
/* 125 */         st = con.prepareStatement(query);
/* 126 */         st.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
/* 127 */         st.setString(2, name);
/* 128 */         st.execute();
/* 129 */         st.close();
/* 130 */         query = "INSERT INTO " + this.plugin.getSettings().getDbPrefix() + "death (player," + "cause, amount, entity, snapshot_time, snapshot_name, world) SELECT " + "player, cause, amount, entity, ?, ?, world " + "FROM " + this.plugin.getSettings().getDbPrefix() + "death WHERE snapshot_name='main_snapshot'";
/*     */ 
/* 134 */         st = con.prepareStatement(query);
/* 135 */         st.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
/* 136 */         st.setString(2, name);
/* 137 */         st.execute();
/* 138 */         st.close();
/* 139 */         query = "INSERT INTO " + this.plugin.getSettings().getDbPrefix() + "kill (player," + "type, amount, snapshot_time, snapshot_name, world) SELECT " + "player, type, amount, ?, ?, world" + " FROM " + this.plugin.getSettings().getDbPrefix() + "kill WHERE snapshot_name='main_snapshot'";
/*     */ 
/* 143 */         st = con.prepareStatement(query);
/* 144 */         st.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
/* 145 */         st.setString(2, name);
/* 146 */         st.execute();
/* 147 */         st.close();
/* 148 */         query = "INSERT INTO " + this.plugin.getSettings().getDbPrefix() + "move (player," + "type, distance, snapshot_time, snapshot_name, world) SELECT " + "player, type, distance, ?, ?, world" + " FROM " + this.plugin.getSettings().getDbPrefix() + "move WHERE snapshot_name='main_snapshot'";
/*     */ 
/* 152 */         st = con.prepareStatement(query);
/* 153 */         st.setTimestamp(1, new Timestamp(System.currentTimeMillis()));
/* 154 */         st.setString(2, name);
/* 155 */         st.execute();
/* 156 */         st.close();
/* 157 */         long timeTaken = (System.nanoTime() - timeStarted) / 1000000L;
/* 158 */         this.plugin.getLogger().info("Snapshot created succesfully in " + timeTaken + "ms");
/* 159 */         this.plugin.getConfig().set("snapshots.previous", Long.valueOf(System.currentTimeMillis()));
/* 160 */         this.plugin.saveConfig();
/* 161 */         st.close();
/* 162 */         con.close();
/* 163 */         this.sending = false;
/*     */       }
/*     */     } catch (SQLException ex) { this.plugin.getLogger().severe("Couldn't create Snapshot;");
/* 166 */       Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } finally {
/* 168 */       this.sending = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void runSnapshotDeletor() {
/*     */     try {
/* 174 */       String[] tables = { "block", "move", "kill", "death", "player" };
/* 175 */       Connection con = this.plugin.getMySQL().getConnection();
/* 176 */       for (String table : tables) {
/* 177 */         String query = "DELETE FROM " + this.plugin.getSettings().getDbPrefix() + table + " " + "WHERE snapshot_time < (NOW() - " + this.timeToLive + "/1000)" + " AND snapshot_name = 'auto_generated_snapshot'";
/*     */ 
/* 180 */         Statement st = con.createStatement();
/* 181 */         st.execute(query);
/* 182 */         st.close();
/*     */       }
/* 184 */       con.close();
/* 185 */       this.plugin.getLogger().info("Old snapshots deleted.");
/*     */     } catch (SQLException ex) {
/* 187 */       this.plugin.getLogger().severe("Couldn't delete Snapshots;");
/* 188 */       Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setInterval(long interval) {
/* 193 */     this.interval = interval;
/*     */   }
/*     */ 
/*     */   public void setTimeUntilNextSnapshot(long timeUntilNextSnapshot) {
/* 197 */     this.timeUntilNextSnapshot = timeUntilNextSnapshot;
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.snapshot.SnapshotManager
 * JD-Core Version:    0.6.2
 */