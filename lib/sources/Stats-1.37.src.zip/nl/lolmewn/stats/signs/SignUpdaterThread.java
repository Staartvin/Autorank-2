/*    */ package nl.lolmewn.stats.signs;
/*    */ 
/*    */ import java.util.Iterator;
/*    */ import java.util.Set;
/*    */ import java.util.concurrent.ConcurrentHashMap;
/*    */ import java.util.logging.Logger;
/*    */ import nl.lolmewn.stats.Main;
/*    */ import nl.lolmewn.stats.signs.events.StatsSignUpdateEvent;
/*    */ import org.bukkit.Server;
/*    */ import org.bukkit.plugin.PluginManager;
/*    */ 
/*    */ public class SignUpdaterThread
/*    */   implements Runnable
/*    */ {
/*    */   private final SignDataGetter source;
/*    */ 
/*    */   public SignUpdaterThread(SignDataGetter from)
/*    */   {
/* 21 */     this.source = from;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/* 26 */     for (Iterator it = this.source.toUpdate.keySet().iterator(); it.hasNext(); ) {
/* 27 */       String location = (String)it.next();
/* 28 */       String[] values = (String[])this.source.toUpdate.get(location);
/* 29 */       it.remove();
/* 30 */       StatsSign sign = this.source.getPlugin().getSignManager().getSignAt(location);
/* 31 */       if (sign == null) {
/* 32 */         this.source.getPlugin().getLogger().warning("StatsSign not found at " + location + ", cancelling...");
/*    */       }
/*    */       else {
/* 35 */         StatsSignUpdateEvent event = new StatsSignUpdateEvent(sign, values);
/* 36 */         this.source.getPlugin().getServer().getPluginManager().callEvent(event);
/* 37 */         if (event.isCancelled()) {
/* 38 */           return;
/*    */         }
/* 40 */         sign.updateSign(values[0], values[1], values[2], values[3]);
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.signs.SignUpdaterThread
 * JD-Core Version:    0.6.2
 */