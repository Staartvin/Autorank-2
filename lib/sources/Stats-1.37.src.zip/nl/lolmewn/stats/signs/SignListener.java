/*     */ package nl.lolmewn.stats.signs;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.text.DecimalFormat;
/*     */ import java.util.HashMap;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import nl.lolmewn.stats.Main;
/*     */ import nl.lolmewn.stats.MySQL;
/*     */ import nl.lolmewn.stats.Settings;
/*     */ import nl.lolmewn.stats.StatTypes;
/*     */ import nl.lolmewn.stats.api.Stat;
/*     */ import nl.lolmewn.stats.api.StatUpdateEvent;
/*     */ import nl.lolmewn.stats.player.PlayerManager;
/*     */ import nl.lolmewn.stats.player.StatData;
/*     */ import nl.lolmewn.stats.player.StatsPlayer;
/*     */ import nl.lolmewn.stats.signs.events.StatsSignCreateEvent;
/*     */ import nl.lolmewn.stats.signs.events.StatsSignDestroyEvent;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.EventPriority;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.BlockBreakEvent;
/*     */ import org.bukkit.event.block.SignChangeEvent;
/*     */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.PlayerInventory;
/*     */ import org.bukkit.metadata.FixedMetadataValue;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class SignListener
/*     */   implements Listener
/*     */ {
/*     */   private final Main plugin;
/*  40 */   private final HashMap<String, Location> customSetters = new HashMap();
/*  41 */   private final HashMap<String, Location> signLineSettings = new HashMap();
/*     */ 
/*     */   public SignListener(Main m) {
/*  44 */     this.plugin = m;
/*     */   }
/*     */ 
/*     */   @EventHandler
/*     */   public void onSignChange(SignChangeEvent event) {
/*  49 */     if (!event.getLine(0).equalsIgnoreCase("[Stats]")) {
/*  50 */       return;
/*     */     }
/*  52 */     if (!event.getPlayer().hasPermission("stats.sign.place")) {
/*  53 */       event.getPlayer().sendMessage(ChatColor.RED + "You are not allowed to place a stats sign!");
/*  54 */       event.setCancelled(true);
/*  55 */       event.getBlock().setType(Material.AIR);
/*  56 */       event.getPlayer().getInventory().addItem(new ItemStack[] { new ItemStack(Material.SIGN, 1) });
/*  57 */       return;
/*     */     }
/*  59 */     if ((!event.getLine(2).equalsIgnoreCase("global")) && (!event.getLine(2).equalsIgnoreCase("player")) && (!event.getLine(2).equalsIgnoreCase("custom"))) {
/*  60 */       event.setCancelled(true);
/*  61 */       event.getBlock().setType(Material.AIR);
/*  62 */       event.getPlayer().getInventory().addItem(new ItemStack[] { new ItemStack(Material.SIGN, 1) });
/*  63 */       event.getPlayer().sendMessage(ChatColor.RED + "Only signs of type 'global', 'player' or 'custom' allowed");
/*     */       return;
/*     */     }
/*     */     SignType type;
/*     */     SignType type;
/*  67 */     if (event.getLine(2).equalsIgnoreCase("global")) {
/*  68 */       type = SignType.GLOBAL;
/*     */     }
/*     */     else
/*     */     {
/*     */       SignType type;
/*  69 */       if (event.getLine(2).equalsIgnoreCase("Custom")) {
/*  70 */         type = SignType.CUSTOM;
/*     */       } else {
/*  72 */         if (event.getLine(3).equals("")) {
/*  73 */           event.setCancelled(true);
/*  74 */           event.getBlock().setType(Material.AIR);
/*  75 */           event.getPlayer().getInventory().addItem(new ItemStack[] { new ItemStack(Material.SIGN, 1) });
/*  76 */           event.getPlayer().sendMessage(ChatColor.RED + "Last line should be a player name");
/*  77 */           return;
/*     */         }
/*  79 */         type = SignType.PLAYER;
/*     */       }
/*     */     }
/*  81 */     Stat stat = this.plugin.getStatTypes().find(event.getLine(1));
/*  82 */     if (stat == null) {
/*  83 */       event.setCancelled(true);
/*  84 */       event.getBlock().setType(Material.AIR);
/*  85 */       event.getPlayer().getInventory().addItem(new ItemStack[] { new ItemStack(Material.SIGN, 1) });
/*  86 */       event.getPlayer().sendMessage(ChatColor.RED + "StatType not recognized. Please use an appropriate one.");
/*  87 */       return;
/*     */     }
/*  89 */     StatsSign sign = new StatsSign(this.plugin.getAPI(), type, stat, event.getBlock().getWorld().getName(), event.getBlock().getX(), event.getBlock().getY(), event.getBlock().getZ());
/*     */ 
/*  95 */     if (type == SignType.PLAYER) {
/*  96 */       sign.setVariable(event.getLine(3));
/*     */     }
/*     */ 
/*  99 */     StatsSignCreateEvent createEvent = new StatsSignCreateEvent(sign, event.getPlayer());
/* 100 */     this.plugin.getServer().getPluginManager().callEvent(createEvent);
/* 101 */     if (createEvent.isCancelled()) {
/* 102 */       return;
/*     */     }
/*     */ 
/* 105 */     if (type.equals(SignType.CUSTOM)) {
/* 106 */       event.getPlayer().sendMessage(ChatColor.GREEN + "Please say the SQL Query to get the data from in chat");
/* 107 */       this.customSetters.put(event.getPlayer().getName(), event.getBlock().getLocation());
/* 108 */       sign.setVariable("UNSET");
/* 109 */       sign.setSignLine("UNSET");
/*     */     }
/* 111 */     this.plugin.getSignManager().addSign(sign, event.getBlock().getLocation());
/* 112 */     event.getBlock().setMetadata("statssign", new FixedMetadataValue(this.plugin, Boolean.valueOf(true)));
/*     */ 
/* 114 */     event.setLine(1, ChatColor.YELLOW + "This sign is");
/* 115 */     event.setLine(2, ChatColor.YELLOW + "pending for");
/* 116 */     event.setLine(3, ChatColor.YELLOW + "data updates...");
/*     */   }
/*     */ 
/*     */   @EventHandler(ignoreCancelled=true, priority=EventPriority.HIGHEST)
/*     */   public void chat(AsyncPlayerChatEvent event) {
/* 121 */     if (this.customSetters.containsKey(event.getPlayer().getName())) {
/*     */       try {
/* 123 */         Connection con = this.plugin.getMySQL().getConnection();
/* 124 */         Statement st = con.createStatement();
/* 125 */         st.executeQuery(event.getMessage());
/* 126 */         st.close();
/* 127 */         con.close();
/* 128 */         this.signLineSettings.put(event.getPlayer().getName(), this.customSetters.get(event.getPlayer().getName()));
/* 129 */         this.customSetters.remove(event.getPlayer().getName());
/* 130 */         event.setCancelled(true);
/* 131 */         StatsSign sign = this.plugin.getSignManager().getSignAt((Location)this.signLineSettings.get(event.getPlayer().getName()));
/* 132 */         sign.setVariable(event.getMessage());
/* 133 */         sign.setSignLine(ChatColor.RED + "Placeholder");
/* 134 */         event.getPlayer().sendMessage(ChatColor.GREEN + "Please set line two for this sign now by saying it in chat.");
/* 135 */         return;
/*     */       } catch (SQLException ex) {
/* 137 */         Logger.getLogger(SignListener.class.getName()).log(Level.SEVERE, null, ex);
/* 138 */         this.plugin.getLogger().severe(ChatColor.RED + "The exeption above was generated by someone entering a faulty SQL query to the Stats plugin, please do NOT report it");
/* 139 */         event.getPlayer().sendMessage(ChatColor.RED + "Faulty SQL query, check the logs and try again.");
/* 140 */         event.setCancelled(true);
/*     */       }
/*     */     }
/* 143 */     if (this.signLineSettings.containsKey(event.getPlayer().getName())) {
/* 144 */       StatsSign sign = this.plugin.getSignManager().getSignAt((Location)this.signLineSettings.get(event.getPlayer().getName()));
/* 145 */       sign.setSignLine(event.getMessage());
/* 146 */       event.setCancelled(true);
/* 147 */       event.getPlayer().sendMessage("Sign is now ready for use!");
/* 148 */       this.signLineSettings.remove(event.getPlayer().getName());
/*     */     }
/*     */   }
/*     */ 
/*     */   @EventHandler(ignoreCancelled=true)
/*     */   public void onBlockBreak(BlockBreakEvent event) {
/* 154 */     Location loc = event.getBlock().getLocation();
/* 155 */     if (this.plugin.getSignManager().getSignAt(loc) != null) {
/* 156 */       StatsSignDestroyEvent ev = new StatsSignDestroyEvent(event.getPlayer(), this.plugin.getSignManager().getSignAt(loc));
/* 157 */       this.plugin.getServer().getPluginManager().callEvent(ev);
/* 158 */       if (ev.isCancelled()) {
/* 159 */         return;
/*     */       }
/* 161 */       this.plugin.getSignManager().removeSign(loc);
/* 162 */       event.getPlayer().sendMessage(ChatColor.GREEN + "Stats sign destroyed and deleted!");
/*     */     }
/*     */   }
/*     */ 
/*     */   @EventHandler
/*     */   public void statsSignCreate(StatsSignCreateEvent event) {
/* 168 */     if (!event.getStatsSign().getSignType().equals(SignType.PLAYER)) {
/* 169 */       return;
/*     */     }
/* 171 */     StatsPlayer player = this.plugin.getPlayerManager().matchPlayerPartially(event.getStatsSign().getVariable());
/* 172 */     if (player == null) {
/* 173 */       return;
/*     */     }
/* 175 */     if (this.plugin.getSettings().isUsingBetaFunctions())
/* 176 */       player.addSignReference(event.getStatsSign(), event.getCreator().getWorld().getName());
/*     */     else {
/* 178 */       player.addSignReference(event.getStatsSign());
/*     */     }
/* 180 */     event.getStatsSign().setAttachedToStat(true);
/*     */   }
/*     */ 
/*     */   @EventHandler
/*     */   public void statsSignDestroy(StatsSignDestroyEvent event) {
/* 185 */     if (!event.getPlayer().hasPermission("stats.sign.destroy")) {
/* 186 */       event.setCancelled(true);
/* 187 */       event.getPlayer().sendMessage(ChatColor.RED + "You are not allowed to destroy a stats sign!");
/*     */     }
/*     */   }
/*     */ 
/*     */   @EventHandler
/*     */   public void statUpdate(StatUpdateEvent event) {
/* 193 */     if (!event.getStatData().hasSigns()) {
/* 194 */       return;
/*     */     }
/* 196 */     final HashMap updates = new HashMap();
/* 197 */     for (String signLoc : event.getStatData().getSignLocations()) {
/* 198 */       StatsSign sign = this.plugin.getSignManager().getSignAt(signLoc);
/* 199 */       if (this.plugin.getSettings().isUsingBetaFunctions())
/*     */       {
/* 200 */         Player p = this.plugin.getServer().getPlayerExact(event.getPlayer().getPlayername());
/* 201 */         if ((p != null) && 
/* 202 */           (!p.getWorld().getName().equals(sign.getWorld())));
/*     */       }
/* 207 */       else if (sign != null) {
/* 208 */         String line1 = ChatColor.BLACK + "[" + ChatColor.YELLOW + "Stats" + ChatColor.BLACK + "]";
/* 209 */         String line2 = sign.getSignLine().substring(0, 1).toUpperCase() + sign.getSignLine().substring(1).toLowerCase();
/* 210 */         String line3 = "by " + sign.getVariable();
/*     */         String line4;
/*     */         String line4;
/* 212 */         if (sign.getStat().getName().equals("Playtime")) {
/* 213 */           long playTimeSeconds = ()event.getNewValue();
/* 214 */           line4 = String.format("%dd %dh %dm %ds", new Object[] { Long.valueOf(TimeUnit.SECONDS.toDays(playTimeSeconds)), Long.valueOf(TimeUnit.SECONDS.toHours(playTimeSeconds) - TimeUnit.SECONDS.toDays(playTimeSeconds) * 24L), Long.valueOf(TimeUnit.SECONDS.toMinutes(playTimeSeconds) - TimeUnit.SECONDS.toHours(playTimeSeconds) * 60L), Long.valueOf(TimeUnit.SECONDS.toSeconds(playTimeSeconds) - TimeUnit.SECONDS.toMinutes(playTimeSeconds) * 60L) });
/*     */         }
/*     */         else
/*     */         {
/*     */           String line4;
/* 219 */           if (sign.getStat().getName().equals("Move"))
/* 220 */             line4 = new DecimalFormat("###0.##").format(event.getNewValue());
/*     */           else
/* 222 */             line4 = Double.toString(event.getNewValue());
/*     */         }
/* 224 */         if (line4.endsWith(".0")) {
/* 225 */           line4 = line4.substring(0, line4.length() - 2);
/*     */         }
/* 227 */         updates.put(sign, new String[] { line1, line2, line3, line4 });
/*     */       }
/*     */     }
/* 230 */     this.plugin.getServer().getScheduler().runTask(this.plugin, new Runnable()
/*     */     {
/*     */       public void run() {
/* 233 */         for (StatsSign sign : updates.keySet()) {
/* 234 */           if (!sign.isActive()) {
/* 235 */             return;
/*     */           }
/* 237 */           String[] values = (String[])updates.get(sign);
/* 238 */           sign.updateSign(values[0], values[1], values[2], values[3]);
/*     */         }
/*     */       }
/*     */     });
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.signs.SignListener
 * JD-Core Version:    0.6.2
 */