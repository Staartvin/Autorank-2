/*    */ package nl.lolmewn.stats.signs.events;
/*    */ 
/*    */ import nl.lolmewn.stats.signs.StatsSign;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.block.Sign;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class StatsSignUpdateEvent extends Event
/*    */   implements Cancellable
/*    */ {
/* 16 */   private boolean cancelled = false;
/* 17 */   private static final HandlerList handlers = new HandlerList();
/*    */   private final StatsSign sign;
/*    */   private final String[] newLines;
/*    */ 
/*    */   public StatsSignUpdateEvent(StatsSign sign, String[] newLines)
/*    */   {
/* 22 */     this.sign = sign;
/* 23 */     this.newLines = newLines;
/*    */   }
/*    */ 
/*    */   public String[] getNewLines() {
/* 27 */     return this.newLines;
/*    */   }
/*    */ 
/*    */   public HandlerList getHandlers()
/*    */   {
/* 32 */     return handlers;
/*    */   }
/*    */ 
/*    */   public static HandlerList getHandlerList() {
/* 36 */     return handlers;
/*    */   }
/*    */ 
/*    */   public boolean isCancelled()
/*    */   {
/* 41 */     return this.cancelled;
/*    */   }
/*    */ 
/*    */   public void setCancelled(boolean cancel)
/*    */   {
/* 46 */     this.cancelled = cancel;
/*    */   }
/*    */ 
/*    */   public StatsSign getStatsSign() {
/* 50 */     return this.sign;
/*    */   }
/*    */ 
/*    */   public Sign getSignBlock() {
/* 54 */     if (this.sign.isActive()) {
/* 55 */       String[] split = this.sign.getLocationString().split(",");
/* 56 */       Location loc = new Location(Bukkit.getWorld(split[0]), Integer.parseInt(split[1]), Integer.parseInt(split[2]), Integer.parseInt(split[3]));
/*    */ 
/* 60 */       return (Sign)loc.getBlock();
/*    */     }
/* 62 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.signs.events.StatsSignUpdateEvent
 * JD-Core Version:    0.6.2
 */