/*    */ package nl.lolmewn.stats.signs.events;
/*    */ 
/*    */ import nl.lolmewn.stats.signs.StatsSign;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.block.Sign;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class StatsSignDestroyEvent extends Event
/*    */   implements Cancellable
/*    */ {
/* 21 */   private static final HandlerList handlers = new HandlerList();
/* 22 */   private boolean cancelled = false;
/*    */   private final StatsSign sign;
/*    */   private final Player player;
/*    */ 
/*    */   public StatsSignDestroyEvent(Player player, StatsSign sign)
/*    */   {
/* 27 */     this.sign = sign;
/* 28 */     this.player = player;
/*    */   }
/*    */ 
/*    */   public StatsSign getStatsSign() {
/* 32 */     return this.sign;
/*    */   }
/*    */ 
/*    */   public Player getPlayer() {
/* 36 */     return this.player;
/*    */   }
/*    */ 
/*    */   public Location getBlockLocation() {
/* 40 */     if (this.sign.isActive()) {
/* 41 */       String[] split = this.sign.getLocationString().split(",");
/* 42 */       Location loc = new Location(Bukkit.getWorld(split[0]), Integer.parseInt(split[1]), Integer.parseInt(split[2]), Integer.parseInt(split[3]));
/*    */ 
/* 46 */       return loc;
/*    */     }
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */   public Sign getSignBlock() {
/* 52 */     Location loc = getBlockLocation();
/* 53 */     if (loc == null) {
/* 54 */       return null;
/*    */     }
/* 56 */     return (Sign)loc.getBlock();
/*    */   }
/*    */ 
/*    */   public HandlerList getHandlers()
/*    */   {
/* 61 */     return handlers;
/*    */   }
/*    */ 
/*    */   public static HandlerList getHandlerList() {
/* 65 */     return handlers;
/*    */   }
/*    */ 
/*    */   public boolean isCancelled()
/*    */   {
/* 70 */     return this.cancelled;
/*    */   }
/*    */ 
/*    */   public void setCancelled(boolean cancel)
/*    */   {
/* 75 */     this.cancelled = cancel;
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.signs.events.StatsSignDestroyEvent
 * JD-Core Version:    0.6.2
 */