/*    */ package nl.lolmewn.stats.signs.events;
/*    */ 
/*    */ import nl.lolmewn.stats.signs.StatsSign;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.Location;
/*    */ import org.bukkit.block.Sign;
/*    */ import org.bukkit.entity.Player;
/*    */ import org.bukkit.event.Cancellable;
/*    */ import org.bukkit.event.Event;
/*    */ import org.bukkit.event.HandlerList;
/*    */ 
/*    */ public class StatsSignCreateEvent extends Event
/*    */   implements Cancellable
/*    */ {
/* 17 */   private static final HandlerList handlers = new HandlerList();
/* 18 */   private boolean cancelled = false;
/*    */   private final StatsSign sign;
/*    */   private final Player creator;
/*    */ 
/*    */   public StatsSignCreateEvent(StatsSign sign, Player player)
/*    */   {
/* 23 */     this.sign = sign;
/* 24 */     this.creator = player;
/*    */   }
/*    */ 
/*    */   public StatsSign getStatsSign() {
/* 28 */     return this.sign;
/*    */   }
/*    */ 
/*    */   public Sign getSignBlock() {
/* 32 */     if (this.sign.isActive()) {
/* 33 */       String[] split = this.sign.getLocationString().split(",");
/* 34 */       Location loc = new Location(Bukkit.getWorld(split[0]), Integer.parseInt(split[1]), Integer.parseInt(split[2]), Integer.parseInt(split[3]));
/*    */ 
/* 38 */       return (Sign)loc.getBlock();
/*    */     }
/* 40 */     return null;
/*    */   }
/*    */ 
/*    */   public HandlerList getHandlers()
/*    */   {
/* 46 */     return handlers;
/*    */   }
/*    */ 
/*    */   public static HandlerList getHandlerList() {
/* 50 */     return handlers;
/*    */   }
/*    */ 
/*    */   public boolean isCancelled()
/*    */   {
/* 55 */     return this.cancelled;
/*    */   }
/*    */ 
/*    */   public void setCancelled(boolean cancel)
/*    */   {
/* 60 */     this.cancelled = cancel;
/*    */   }
/*    */ 
/*    */   public Player getCreator() {
/* 64 */     return this.creator;
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.signs.events.StatsSignCreateEvent
 * JD-Core Version:    0.6.2
 */