/*     */ package nl.lolmewn.stats.signs;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import nl.lolmewn.stats.Main;
/*     */ import nl.lolmewn.stats.MySQL;
/*     */ import nl.lolmewn.stats.Settings;
/*     */ import nl.lolmewn.stats.api.Stat;
/*     */ import nl.lolmewn.stats.api.StatsAPI;
/*     */ import nl.lolmewn.stats.player.PlayerManager;
/*     */ import nl.lolmewn.stats.player.StatData;
/*     */ import nl.lolmewn.stats.player.StatsPlayer;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class SignDataGetter
/*     */   implements Runnable
/*     */ {
/*     */   private final Main plugin;
/*  25 */   protected ConcurrentHashMap<String, String[]> toUpdate = new ConcurrentHashMap();
/*     */ 
/*     */   public SignDataGetter(Main plugin) {
/*  28 */     this.plugin = plugin;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  33 */     if (this.plugin.newConfig) {
/*  34 */       return;
/*     */     }
/*  36 */     if ((this.plugin.getMySQL() == null) || (this.plugin.getMySQL().isFault())) {
/*  37 */       return;
/*     */     }
/*  39 */     boolean usingBeta = this.plugin.getSettings().isUsingBetaFunctions();
/*  40 */     Connection con = this.plugin.getMySQL().getConnection();
/*  41 */     for (StatsSign sign : this.plugin.getSignManager().getAllSigns())
/*  42 */       if (sign.getSignType().equals(SignType.PLAYER))
/*     */       {
/*     */         ResultSet set;
/*     */         String query;
/*     */         String statName;
/*     */         String query;
/*     */         String query;
/*     */         String query;
/*     */         String query;
/*     */         String query;
/*     */         String query;
/*     */         String query;
/*     */         String[] array;
/*  43 */         if (!sign.isAttachedToStat())
/*     */         {
/*  46 */           String[] array = new String[4];
/*  47 */           array[0] = (ChatColor.BLACK + "[" + ChatColor.YELLOW + "Stats" + ChatColor.BLACK + "]");
/*  48 */           array[1] = (sign.getSignLine().substring(0, 1).toUpperCase() + sign.getSignLine().substring(1).toLowerCase());
/*  49 */           array[2] = ("by " + sign.getVariable());
/*  50 */           StatsPlayer player = this.plugin.getPlayerManager().matchPlayerPartially(sign.getVariable());
/*  51 */           if (player != null)
/*     */           {
/*  54 */             String statName = sign.getStat().getName();
/*  55 */             if (statName.equals("Block break")) {
/*  56 */               array[3] = (usingBeta ? Double.toString(this.plugin.getAPI().getTotalBlocksBroken(player.getPlayername(), sign.getWorld())) : Double.toString(this.plugin.getAPI().getTotalBlocksBroken(player.getPlayername())));
/*  57 */             } else if (statName.equals("Block place")) {
/*  58 */               array[3] = (usingBeta ? Double.toString(this.plugin.getAPI().getTotalBlocksPlaced(player.getPlayername(), sign.getWorld())) : Double.toString(this.plugin.getAPI().getTotalBlocksPlaced(player.getPlayername())));
/*  59 */             } else if (statName.equals("Death")) {
/*  60 */               array[3] = (usingBeta ? Double.toString(this.plugin.getAPI().getTotalDeaths(player.getPlayername(), sign.getWorld())) : Double.toString(this.plugin.getAPI().getTotalDeaths(player.getPlayername())));
/*  61 */             } else if (statName.equals("Kill")) {
/*  62 */               array[3] = (usingBeta ? Double.toString(this.plugin.getAPI().getTotalKills(player.getPlayername(), sign.getWorld())) : Double.toString(this.plugin.getAPI().getTotalKills(player.getPlayername())));
/*  63 */             } else if (statName.equals("Playtime")) {
/*  64 */               int playTimeSeconds = usingBeta ? (int)this.plugin.getAPI().getPlaytime(player.getPlayername(), sign.getWorld()) : (int)this.plugin.getAPI().getPlaytime(player.getPlayername());
/*  65 */               array[3] = String.format("%dd %dh %dm %ds", new Object[] { Long.valueOf(TimeUnit.SECONDS.toDays(playTimeSeconds)), Long.valueOf(TimeUnit.SECONDS.toHours(playTimeSeconds) - TimeUnit.SECONDS.toDays(playTimeSeconds) * 24L), Long.valueOf(TimeUnit.SECONDS.toMinutes(playTimeSeconds) - TimeUnit.SECONDS.toHours(playTimeSeconds) * 60L), Long.valueOf(TimeUnit.SECONDS.toSeconds(playTimeSeconds) - TimeUnit.SECONDS.toMinutes(playTimeSeconds) * 60L) });
/*     */             }
/*     */             else
/*     */             {
/*  71 */               double val = this.plugin.getSettings().isUsingBetaFunctions() ? player.getStatData(sign.getStat(), sign.getLocationString().split(",")[0], true).getValueUnsafe() : player.getStatData(sign.getStat(), true).getValueUnsafe();
/*     */ 
/*  74 */               array[3] = Double.toString(val);
/*     */             }
/*  76 */             this.toUpdate.put(sign.getLocationString(), array);
/*     */           }
/*     */         }
/*     */       } else { set = null;
/*  80 */         if (sign.getSignType().equals(SignType.CUSTOM)) {
/*  81 */           if ((!sign.getVariable().equals("UNSET")) && (!sign.getSignLine().equals("UNSET")))
/*     */           {
/*  84 */             query = sign.getVariable();
/*  85 */             set = getResultSet(con, query, new Object[0]);
/*     */           }
/*     */         } else {
/*  88 */           statName = sign.getStat().getName();
/*  89 */           if (statName.equals("Block break")) {
/*  90 */             query = "SELECT SUM(amount) as result FROM " + this.plugin.getSettings().getDbPrefix() + "block" + " WHERE break=1";
/*  91 */             set = getResultSet(con, query, new Object[0]);
/*  92 */           } else if (statName.equals("Block place")) {
/*  93 */             query = "SELECT SUM(amount) as result FROM " + this.plugin.getSettings().getDbPrefix() + "block" + " WHERE break=0";
/*  94 */             set = getResultSet(con, query, new Object[0]);
/*  95 */           } else if (statName.equals("Death")) {
/*  96 */             query = "SELECT SUM(amount) as result FROM " + this.plugin.getSettings().getDbPrefix() + "death";
/*  97 */             set = getResultSet(con, query, new Object[0]);
/*  98 */           } else if (statName.equals("Kill")) {
/*  99 */             query = "SELECT SUM(amount) as result FROM " + this.plugin.getSettings().getDbPrefix() + "kill";
/* 100 */             set = getResultSet(con, query, new Object[0]);
/* 101 */           } else if (statName.equals("Playtime")) {
/* 102 */             query = "SELECT SUM(playtime) as result FROM " + this.plugin.getSettings().getDbPrefix() + "player";
/* 103 */             set = getResultSet(con, query, new Object[0]);
/* 104 */           } else if (sign.getStat().getUpdate().contains("PREFIXplayer")) {
/* 105 */             query = "SELECT SUM(" + sign.getStat().getUpdate().split("SET ")[1].split("=")[0] + ") as result FROM " + this.plugin.getSettings().getDbPrefix() + "player";
/* 106 */             set = getResultSet(con, query, new Object[0]);
/*     */           } else {
/* 108 */             sign.updateSign(ChatColor.BLACK + "[" + ChatColor.YELLOW + "Stats" + ChatColor.BLACK + "]", sign.getSignType().toString().substring(0, 1).toUpperCase() + sign.getSignType().toString().substring(1).toLowerCase(), sign.getSignLine().length() > 15 ? sign.getSignLine().substring(15) : sign.getSignType() == SignType.GLOBAL ? "in total" : "", ChatColor.RED + "Error occured");
/*     */ 
/* 112 */             continue;
/*     */           }
/*     */ 
/* 115 */           array = new String[4];
/* 116 */           array[0] = (ChatColor.BLACK + "[" + ChatColor.YELLOW + "Stats" + ChatColor.BLACK + "]");
/* 117 */           array[1] = (sign.getSignLine().substring(0, 1).toUpperCase() + sign.getSignLine().substring(1).toLowerCase());
/* 118 */           array[2] = (sign.getSignLine().length() > 15 ? sign.getSignLine().substring(15) : sign.getSignType() == SignType.GLOBAL ? "in total" : "");
/*     */           try {
/* 120 */             if ((set != null) && (set.next())) {
/* 121 */               if (set.getObject(1) == null) {
/* 122 */                 array[3] = (ChatColor.RED + "Non-existing");
/* 123 */               } else if (set.getString(1).equalsIgnoreCase("")) {
/* 124 */                 array[3] = "None!";
/*     */               }
/* 126 */               else if (sign.getStat().getName().equals("Playtime")) {
/* 127 */                 int playTimeSeconds = set.getInt(1);
/* 128 */                 array[3] = String.format("%dd %dh %dm %ds", new Object[] { Long.valueOf(TimeUnit.SECONDS.toDays(playTimeSeconds)), Long.valueOf(TimeUnit.SECONDS.toHours(playTimeSeconds) - TimeUnit.SECONDS.toDays(playTimeSeconds) * 24L), Long.valueOf(TimeUnit.SECONDS.toMinutes(playTimeSeconds) - TimeUnit.SECONDS.toHours(playTimeSeconds) * 60L), Long.valueOf(TimeUnit.SECONDS.toSeconds(playTimeSeconds) - TimeUnit.SECONDS.toMinutes(playTimeSeconds) * 60L) });
/*     */               }
/*     */               else
/*     */               {
/* 134 */                 array[3] = set.getString(1);
/*     */               }
/*     */             }
/*     */             else
/* 138 */               array[3] = "Error :O";
/*     */           }
/*     */           catch (SQLException ex) {
/* 141 */             Logger.getLogger(SignDataGetter.class.getName()).log(Level.SEVERE, null, ex);
/* 142 */             array[3] = "Error :O";
/*     */           }
/* 144 */           this.toUpdate.put(sign.getLocationString(), array);
/*     */         } }
/*     */     try
/*     */     {
/* 148 */       con.close();
/*     */     } catch (SQLException ex) {
/* 150 */       Logger.getLogger(SignDataGetter.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } finally {
/* 152 */       this.plugin.getServer().getScheduler().runTaskLater(this.plugin, new SignUpdaterThread(this), 1L);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Main getPlugin() {
/* 157 */     return this.plugin;
/*     */   }
/*     */ 
/*     */   private ResultSet getResultSet(Connection con, String query, Object[] variables) {
/*     */     try {
/* 162 */       PreparedStatement st = con.prepareStatement(query);
/* 163 */       if ((variables != null) && (
/* 164 */         (variables.length != 1) || (variables[0] != null))) {
/* 165 */         for (int i = 0; i < variables.length; i++) {
/* 166 */           st.setObject(i + 1, variables[i]);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 171 */       return st.executeQuery();
/*     */     }
/*     */     catch (SQLException ex) {
/* 174 */       Logger.getLogger(SignDataGetter.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */ 
/* 177 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.signs.SignDataGetter
 * JD-Core Version:    0.6.2
 */