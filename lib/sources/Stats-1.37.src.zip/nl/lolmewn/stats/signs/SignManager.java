/*     */ package nl.lolmewn.stats.signs;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.Collection;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import nl.lolmewn.stats.Main;
/*     */ import nl.lolmewn.stats.Settings;
/*     */ import nl.lolmewn.stats.api.Stat;
/*     */ import nl.lolmewn.stats.player.PlayerManager;
/*     */ import nl.lolmewn.stats.player.StatsPlayer;
/*     */ import org.bukkit.Location;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.configuration.ConfigurationSection;
/*     */ import org.bukkit.configuration.file.YamlConfiguration;
/*     */ import org.bukkit.metadata.FixedMetadataValue;
/*     */ 
/*     */ public class SignManager
/*     */ {
/*     */   private final Main plugin;
/*  26 */   private final ConcurrentHashMap<String, StatsSign> signs = new ConcurrentHashMap();
/*  27 */   private File signFile = null;
/*  28 */   private YamlConfiguration c = null;
/*     */ 
/*     */   public SignManager(Main plugin) {
/*  31 */     this.plugin = plugin;
/*  32 */     this.signFile = new File(plugin.getDataFolder(), "signs.yml");
/*  33 */     this.c = YamlConfiguration.loadConfiguration(this.signFile);
/*     */   }
/*     */ 
/*     */   public void addSign(StatsSign sign, String locationString) {
/*  37 */     this.signs.put(locationString, sign);
/*     */   }
/*     */ 
/*     */   public void addSign(StatsSign sign, Location loc) {
/*  41 */     addSign(sign, loc.getWorld().getName() + "," + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ());
/*     */   }
/*     */ 
/*     */   public StatsSign getSignAt(Location loc) {
/*  45 */     return getSignAt(loc.getWorld().getName() + "," + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ());
/*     */   }
/*     */ 
/*     */   public StatsSign getSignAt(String locationString) {
/*  49 */     if (this.signs.containsKey(locationString)) {
/*  50 */       return (StatsSign)this.signs.get(locationString);
/*     */     }
/*  52 */     return null;
/*     */   }
/*     */ 
/*     */   public Collection<StatsSign> getAllSigns() {
/*  56 */     return this.signs.values();
/*     */   }
/*     */ 
/*     */   public void removeSign(Location loc) {
/*  60 */     if (this.signs.containsKey(loc.getWorld().getName() + "," + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ())) {
/*  61 */       this.signs.remove(loc.getWorld().getName() + "," + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ());
/*  62 */       this.c.set(loc.getWorld().getName() + "," + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ(), null);
/*     */       try {
/*  64 */         this.c.save(this.signFile);
/*     */       } catch (IOException ex) {
/*  66 */         Logger.getLogger(SignManager.class.getName()).log(Level.SEVERE, null, ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void save() {
/*  72 */     if (!this.signFile.exists()) {
/*  73 */       this.signFile.getParentFile().mkdirs();
/*     */       try {
/*  75 */         this.signFile.createNewFile();
/*     */       } catch (IOException ex) {
/*  77 */         Logger.getLogger(SignManager.class.getName()).log(Level.SEVERE, null, ex);
/*     */       }
/*     */     }
/*  80 */     for (String loc : this.signs.keySet()) {
/*  81 */       StatsSign sign = (StatsSign)this.signs.get(loc);
/*  82 */       this.c.set(loc + ".type", sign.getSignType().toString());
/*  83 */       this.c.set(loc + ".stat", sign.getStat().getName());
/*  84 */       if (sign.hasVariable()) {
/*  85 */         this.c.set(loc + ".var", sign.getVariable());
/*     */       }
/*  87 */       if (sign.getSignType().equals(SignType.CUSTOM))
/*  88 */         this.c.set(loc + ".line", sign.getSignLine());
/*     */     }
/*     */     try
/*     */     {
/*  92 */       this.c.save(this.signFile);
/*     */     } catch (IOException ex) {
/*  94 */       Logger.getLogger(SignManager.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void load() {
/*  99 */     if (!this.signFile.exists()) {
/* 100 */       return;
/*     */     }
/* 102 */     for (String key : this.c.getConfigurationSection("").getKeys(false)) {
/* 103 */       String[] chop = key.split(",");
/* 104 */       if ((chop[0] != null) && (this.plugin.getServer().getWorld(chop[0]) != null)) {
/* 105 */         Location loc = new Location(this.plugin.getServer().getWorld(chop[0]), Integer.parseInt(chop[1]), Integer.parseInt(chop[2]), Integer.parseInt(chop[3]));
/*     */ 
/* 109 */         loc.getBlock().setMetadata("statssign", new FixedMetadataValue(this.plugin, Boolean.valueOf(true)));
/*     */         StatsSign sign;
/* 111 */         if (this.c.contains(key + ".dataType")) {
/* 112 */           StatsSign sign = new StatsSign(this.plugin.getAPI(), key, this.c.getConfigurationSection(key));
/*     */           try {
/* 114 */             this.c.save(this.signFile);
/*     */           } catch (IOException ex) {
/* 116 */             Logger.getLogger(SignManager.class.getName()).log(Level.SEVERE, null, ex);
/*     */           }
/*     */         } else {
/* 119 */           sign = new StatsSign(this.plugin.getAPI(), key, this.c.getConfigurationSection(key));
/*     */         }
/* 121 */         addSign(sign, key);
/* 122 */         if (sign.getSignType().equals(SignType.PLAYER)) {
/* 123 */           StatsPlayer p = this.plugin.getPlayerManager().matchPlayerPartially(sign.getVariable());
/* 124 */           if (p != null)
/*     */           {
/* 127 */             if (this.plugin.getSettings().isUsingBetaFunctions())
/* 128 */               p.addSignReference(sign, sign.getWorld());
/*     */             else {
/* 130 */               p.addSignReference(sign);
/*     */             }
/* 132 */             sign.setAttachedToStat(true);
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.signs.SignManager
 * JD-Core Version:    0.6.2
 */