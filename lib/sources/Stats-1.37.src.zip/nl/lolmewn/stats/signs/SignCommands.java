/*    */ package nl.lolmewn.stats.signs;
/*    */ 
/*    */ import nl.lolmewn.stats.Main;
/*    */ import org.bukkit.command.CommandSender;
/*    */ 
/*    */ public class SignCommands
/*    */ {
/*    */   public boolean onCommand(Main m, CommandSender sender, String[] args)
/*    */   {
/* 13 */     return true;
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.signs.SignCommands
 * JD-Core Version:    0.6.2
 */