/*     */ package nl.lolmewn.stats.signs;
/*     */ 
/*     */ import nl.lolmewn.stats.api.Stat;
/*     */ import nl.lolmewn.stats.api.StatsAPI;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.World;
/*     */ import org.bukkit.block.Block;
/*     */ import org.bukkit.block.Sign;
/*     */ import org.bukkit.configuration.ConfigurationSection;
/*     */ 
/*     */ public class StatsSign
/*     */ {
/*     */   private StatsAPI api;
/*     */   private Stat stat;
/*     */   private String type;
/*     */   private SignType signType;
/*     */   private final String world;
/*     */   private final int x;
/*     */   private final int y;
/*     */   private final int z;
/*     */   private String variable;
/*     */   private String signLine;
/*     */   private boolean assignedToStat;
/*     */ 
/*     */   public StatsSign(StatsAPI api, SignType type, Stat stat, String world, int x, int y, int z)
/*     */   {
/*  32 */     this.stat = stat;
/*  33 */     this.type = stat.getName();
/*  34 */     this.signType = type;
/*  35 */     this.world = world;
/*  36 */     this.x = x;
/*  37 */     this.y = y;
/*  38 */     this.z = z;
/*     */   }
/*     */ 
/*     */   public StatsSign(StatsAPI api, String location, ConfigurationSection section) {
/*  42 */     String[] split = location.split(",");
/*  43 */     this.world = split[0];
/*  44 */     this.x = Integer.parseInt(split[1]);
/*  45 */     this.y = Integer.parseInt(split[2]);
/*  46 */     this.z = Integer.parseInt(split[3]);
/*  47 */     this.signType = SignType.fromString(section.getString("type"));
/*  48 */     if (section.getString("dataType", null) == null) {
/*  49 */       this.stat = api.getStat(section.getString("stat"));
/*     */     } else {
/*  51 */       this.type = section.getString("dataType");
/*  52 */       if (this.type.equalsIgnoreCase("pvpkills")) {
/*  53 */         setVariable(new StringBuilder().append("SELECT ").append(this.signType.equals(SignType.GLOBAL) ? "SUM(amount) " : "amount ").append("FROM ").append(api.getDatabasePrefix()).append("kill WHERE type='Player'").append(this.signType.equals(SignType.GLOBAL) ? "" : new StringBuilder().append("AND player='").append(section.getString("var")).append("'").toString()).toString());
/*     */ 
/*  56 */         this.signType = SignType.CUSTOM;
/*  57 */         this.signLine = "PVP kills";
/*  58 */         this.type = "Kill";
/*  59 */         section.set("var", this.variable);
/*  60 */       } else if ((this.type.equalsIgnoreCase("deaths")) || (this.type.equalsIgnoreCase("Kills"))) {
/*  61 */         this.type = this.type.substring(0, this.type.length() - 2);
/*  62 */       } else if (this.type.equalsIgnoreCase("blocks broken")) {
/*  63 */         this.type = "Block break";
/*  64 */       } else if (this.type.equalsIgnoreCase("blocks placed")) {
/*  65 */         this.type = "Block place";
/*     */       }
/*  67 */       this.stat = api.getStat(this.type);
/*  68 */       section.set("dataType", null);
/*  69 */       section.set("stat", this.stat.getName());
/*     */     }
/*     */ 
/*  72 */     if (section.isSet("var")) {
/*  73 */       this.variable = section.getString("var");
/*     */     }
/*  75 */     this.signLine = section.getString("line", null);
/*     */   }
/*     */ 
/*     */   public boolean isActive() {
/*  79 */     World w = Bukkit.getWorld(this.world);
/*  80 */     if (w == null) {
/*  81 */       return false;
/*     */     }
/*  83 */     if (!w.isChunkLoaded(this.x >> 4, this.z >> 4)) {
/*  84 */       return false;
/*     */     }
/*  86 */     Block b = w.getBlockAt(this.x, this.y, this.z);
/*  87 */     if ((!b.getType().equals(Material.SIGN_POST)) && (!b.getType().equals(Material.WALL_SIGN))) {
/*  88 */       return false;
/*     */     }
/*  90 */     return b.hasMetadata("statssign");
/*     */   }
/*     */ 
/*     */   public Stat getStat() {
/*  94 */     return this.stat;
/*     */   }
/*     */ 
/*     */   public SignType getSignType() {
/*  98 */     return this.signType;
/*     */   }
/*     */ 
/*     */   public void updateSign(String line1, String line2, String line3, String line4) {
/* 102 */     if (!isActive()) {
/* 103 */       return;
/*     */     }
/* 105 */     Sign s = (Sign)Bukkit.getWorld(this.world).getBlockAt(this.x, this.y, this.z).getState();
/* 106 */     s.setLine(0, line1);
/* 107 */     s.setLine(1, line2);
/* 108 */     s.setLine(2, line3);
/* 109 */     s.setLine(3, line4);
/* 110 */     s.update();
/*     */   }
/*     */ 
/*     */   public String getLocationString() {
/* 114 */     return new StringBuilder().append(this.world).append(",").append(this.x).append(",").append(this.y).append(",").append(this.z).toString();
/*     */   }
/*     */ 
/*     */   public String getWorld() {
/* 118 */     return this.world;
/*     */   }
/*     */ 
/*     */   public void setVariable(String var) {
/* 122 */     this.variable = var;
/*     */   }
/*     */ 
/*     */   public boolean hasVariable() {
/* 126 */     return this.variable != null;
/*     */   }
/*     */ 
/*     */   public String getVariable() {
/* 130 */     return this.variable;
/*     */   }
/*     */ 
/*     */   public String getSignLine() {
/* 134 */     if (this.signType.equals(SignType.CUSTOM)) {
/* 135 */       return this.signLine;
/*     */     }
/* 137 */     if (this.stat == null) {
/* 138 */       this.stat = this.api.getStat(this.type);
/* 139 */       if (this.stat == null) {
/* 140 */         return "Broken Stat :(";
/*     */       }
/*     */     }
/* 143 */     return this.stat.getName();
/*     */   }
/*     */ 
/*     */   public void setSignLine(String signLine)
/*     */   {
/* 150 */     this.signLine = signLine;
/*     */   }
/*     */ 
/*     */   public void setAttachedToStat(boolean b) {
/* 154 */     this.assignedToStat = b;
/*     */   }
/*     */ 
/*     */   public boolean isAttachedToStat() {
/* 158 */     return this.assignedToStat;
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.signs.StatsSign
 * JD-Core Version:    0.6.2
 */