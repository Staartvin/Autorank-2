/*    */ package nl.lolmewn.stats.signs;
/*    */ 
/*    */ public enum SignType
/*    */ {
/* 13 */   PLAYER, 
/* 14 */   GLOBAL, 
/* 15 */   CUSTOM;
/*    */ 
/*    */   public static SignType fromString(String input) {
/* 18 */     if (input != null) {
/* 19 */       for (SignType t : values()) {
/* 20 */         if (t.toString().equalsIgnoreCase(input.toUpperCase())) {
/* 21 */           return t;
/*    */         }
/*    */       }
/*    */     }
/* 25 */     throw new IllegalArgumentException("No constant with text " + input + " found");
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.signs.SignType
 * JD-Core Version:    0.6.2
 */