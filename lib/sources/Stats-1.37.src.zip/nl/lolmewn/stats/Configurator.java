/*     */ package nl.lolmewn.stats;
/*     */ 
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.conversations.BooleanPrompt;
/*     */ import org.bukkit.conversations.Conversation;
/*     */ import org.bukkit.conversations.ConversationContext;
/*     */ import org.bukkit.conversations.ConversationFactory;
/*     */ import org.bukkit.conversations.MessagePrompt;
/*     */ import org.bukkit.conversations.PluginNameConversationPrefix;
/*     */ import org.bukkit.conversations.Prompt;
/*     */ import org.bukkit.conversations.StringPrompt;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class Configurator
/*     */ {
/*     */   private ConversationFactory factory;
/*     */   private Main plugin;
/*     */   private final Player p;
/*     */   private Conversation c;
/*     */ 
/*     */   public Configurator(Main m, final Player p)
/*     */   {
/*  23 */     this.plugin = m;
/*  24 */     this.p = p;
/*  25 */     this.factory = new ConversationFactory(m).withModality(true).withEscapeSequence("stop").withPrefix(new PluginNameConversationPrefix(m, " ", ChatColor.GREEN)).withFirstPrompt(new ConversationStartPrompt(null)).withLocalEcho(false);
/*     */ 
/*  31 */     m.getServer().getScheduler().runTaskLater(this.plugin, new Runnable()
/*     */     {
/*     */       public void run() {
/*  34 */         if (p.isOnline()) {
/*  35 */           Configurator.this.c = Configurator.this.factory.buildConversation(p);
/*  36 */           Configurator.this.c.begin();
/*     */         } else {
/*  38 */           Configurator.this.plugin.beingConfigged = false;
/*  39 */           Configurator.this.factory = null;
/*     */         }
/*     */       }
/*     */     }
/*     */     , 60L);
/*     */   }
/*     */ 
/*     */   private class Finished extends MessagePrompt
/*     */   {
/*     */     private Finished()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected Prompt getNextPrompt(ConversationContext cc)
/*     */     {
/* 140 */       return Prompt.END_OF_CONVERSATION;
/*     */     }
/*     */ 
/*     */     public String getPromptText(ConversationContext cc)
/*     */     {
/* 145 */       return "Configuration finished!";
/*     */     }
/*     */   }
/*     */ 
/*     */   private class connectionFailedPrompt extends MessagePrompt
/*     */   {
/*     */     private connectionFailedPrompt()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected Prompt getNextPrompt(ConversationContext cc)
/*     */     {
/* 121 */       return new Configurator.inputPrompt(Configurator.this, "your database host (usually localhost)", "MySQL-Host", new Configurator.inputPrompt(Configurator.this, "your database username (usually root)", "MySQL-User", new Configurator.inputPrompt(Configurator.this, "your database password", "MySQL-Pass", new Configurator.inputPrompt(Configurator.this, "your database name (usually minecraft)", "MySQL-Database", new Configurator.inputPrompt(Configurator.this, "your database port (usually 3306)", "MySQL-Port", new Configurator.endPrompt(Configurator.this, null))))));
/*     */     }
/*     */ 
/*     */     public String getPromptText(ConversationContext cc)
/*     */     {
/* 131 */       return "Connection to MySQL database failed! Starting over..";
/*     */     }
/*     */   }
/*     */ 
/*     */   private class endPrompt extends BooleanPrompt
/*     */   {
/*     */     private endPrompt()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected Prompt acceptValidatedInput(ConversationContext cc, boolean bln)
/*     */     {
/*  96 */       cc.setSessionData("update", Boolean.valueOf(bln));
/*  97 */       Configurator.this.p.sendMessage("Configuration complete. Checking MySQL connection values...");
/*  98 */       if (Configurator.this.plugin.setupMySQL(cc)) {
/*  99 */         Configurator.this.p.sendMessage("Connection succesful. Saving config values...");
/* 100 */         Configurator.this.plugin.saveValues(cc);
/* 101 */         Configurator.this.plugin.beingConfigged = false;
/* 102 */         Configurator.this.plugin.newConfig = false;
/* 103 */         Configurator.this.plugin.configComplete();
/*     */       } else {
/* 105 */         return new Configurator.connectionFailedPrompt(Configurator.this, null);
/*     */       }
/* 107 */       return new Configurator.Finished(Configurator.this, null);
/*     */     }
/*     */ 
/*     */     public String getPromptText(ConversationContext cc)
/*     */     {
/* 112 */       return "Final config value: Allow for automatic updating of this plugin?";
/*     */     }
/*     */   }
/*     */ 
/*     */   private class inputPrompt extends StringPrompt
/*     */   {
/*     */     private final String key;
/*     */     private final String value;
/*     */     private final Prompt next;
/*     */ 
/*     */     public inputPrompt(String key, String value, Prompt next)
/*     */     {
/*  74 */       this.key = key;
/*  75 */       this.value = value;
/*  76 */       this.next = next;
/*     */     }
/*     */ 
/*     */     public String getPromptText(ConversationContext cc)
/*     */     {
/*  81 */       return "Please type " + this.key;
/*     */     }
/*     */ 
/*     */     public Prompt acceptInput(ConversationContext cc, String string)
/*     */     {
/*  86 */       cc.setSessionData(this.value, string);
/*  87 */       return this.next;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ConversationStartPrompt extends MessagePrompt
/*     */   {
/*     */     private ConversationStartPrompt()
/*     */     {
/*     */     }
/*     */ 
/*     */     protected Prompt getNextPrompt(ConversationContext cc)
/*     */     {
/*  50 */       return new Configurator.inputPrompt(Configurator.this, "your database host (usually localhost)", "MySQL-Host", new Configurator.inputPrompt(Configurator.this, "your database username (usually root)", "MySQL-User", new Configurator.inputPrompt(Configurator.this, "your database password", "MySQL-Pass", new Configurator.inputPrompt(Configurator.this, "your database name (usually minecraft)", "MySQL-Database", new Configurator.inputPrompt(Configurator.this, "your database port (usually 3306)", "MySQL-Port", new Configurator.endPrompt(Configurator.this, null))))));
/*     */     }
/*     */ 
/*     */     public String getPromptText(ConversationContext cc)
/*     */     {
/*  60 */       return "Welcome to the automatic configuration wizard for Stats. This wizard will guide you through the configuration of the plugin. You can type the answers to the questions in plain text, no-one will be able to see them.";
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.Configurator
 * JD-Core Version:    0.6.2
 */