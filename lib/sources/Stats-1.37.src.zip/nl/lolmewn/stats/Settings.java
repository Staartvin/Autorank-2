/*     */ package nl.lolmewn.stats;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.configuration.file.FileConfigurationOptions;
/*     */ 
/*     */ public class Settings
/*     */ {
/*     */   private final Main plugin;
/*     */   private String dbHost;
/*     */   private String dbPass;
/*     */   private String dbUser;
/*     */   private String dbName;
/*     */   private String dbPrefix;
/*     */   private int dbPort;
/*     */   private boolean ignoreCreative;
/*     */   private boolean debug;
/*     */   private boolean sendToGlobal;
/*     */   private boolean instaUpdateSigns;
/*     */   private int signsUpdateInterval;
/*     */   private boolean update;
/*  30 */   private List<String> disabled = new ArrayList();
/*  31 */   private List<String> command = new ArrayList();
/*     */   private boolean useBetaFunctions;
/*     */   private String snapshotTimeToLive;
/*     */   private String snapshotInterval;
/*     */   private long previousSnapshot;
/*     */   private boolean createSnapshots;
/*     */   private boolean isXServerEnabled;
/*     */   private boolean isXServerHost;
/*     */   private int xServerPort;
/*     */   private String xServerHost;
/*     */   private boolean usePermissionsForTracking;
/*     */ 
/*     */   public boolean isXServerHost()
/*     */   {
/*  44 */     return this.isXServerHost;
/*     */   }
/*     */ 
/*     */   public boolean isXServerEnabled() {
/*  48 */     return this.isXServerEnabled;
/*     */   }
/*     */ 
/*     */   public int getXServerPort() {
/*  52 */     return this.xServerPort;
/*     */   }
/*     */ 
/*     */   public String getxServerHost() {
/*  56 */     return this.xServerHost;
/*     */   }
/*     */ 
/*     */   public boolean isUsingPermissionsForTracking() {
/*  60 */     return this.usePermissionsForTracking;
/*     */   }
/*     */ 
/*     */   private Main getPlugin() {
/*  64 */     return this.plugin;
/*     */   }
/*     */ 
/*     */   public Settings(Main m) {
/*  68 */     this.plugin = m;
/*     */   }
/*     */ 
/*     */   protected void loadSettings() {
/*  72 */     FileConfiguration f = getPlugin().getConfig();
/*  73 */     f.options().copyDefaults(true);
/*     */     try {
/*  75 */       f.save(new File(this.plugin.getDataFolder(), "config.yml"));
/*     */     } catch (IOException ex) {
/*  77 */       Logger.getLogger(Settings.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*  79 */     this.dbUser = f.getString("MySQL-User", "root");
/*  80 */     this.dbPass = f.getString("MySQL-Pass", "root");
/*  81 */     this.dbHost = f.getString("MySQL-Host", "localhost");
/*  82 */     this.dbPort = f.getInt("MySQL-Port", 3306);
/*  83 */     this.dbName = f.getString("MySQL-Database", "minecraft");
/*  84 */     this.dbPrefix = f.getString("MySQL-Prefix", "Stats_");
/*  85 */     this.debug = f.getBoolean("debug", false);
/*  86 */     this.update = f.getBoolean("update", true);
/*  87 */     this.sendToGlobal = f.getBoolean("sendStatsToGlobalServer", true);
/*  88 */     this.ignoreCreative = f.getBoolean("ignoreCreative", false);
/*  89 */     this.instaUpdateSigns = f.getBoolean("signs.insta-update", true);
/*  90 */     this.signsUpdateInterval = f.getInt("signs.update-interval", 10);
/*  91 */     this.useBetaFunctions = f.getBoolean("useBetaFunctions", false);
/*  92 */     this.snapshotTimeToLive = f.getString("snapshots.timeToLive", "30D");
/*  93 */     this.snapshotInterval = f.getString("snapshots.interval", "1D");
/*  94 */     this.createSnapshots = f.getBoolean("snapshots.enabled", true);
/*  95 */     this.previousSnapshot = f.getLong("snapshots.previous", 0L);
/*  96 */     if (f.contains("disabledStats")) {
/*  97 */       this.disabled = f.getStringList("disabledStats");
/*     */     }
/*  99 */     if (f.contains("commandList")) {
/* 100 */       this.command = f.getStringList("commandList");
/*     */     }
/* 102 */     this.isXServerEnabled = f.getBoolean("cross-server.enabled", false);
/* 103 */     this.isXServerHost = f.getBoolean("cross-server.isMainServer", false);
/* 104 */     this.xServerHost = f.getString("cross-server.mainServerHost", "localhost");
/* 105 */     this.xServerPort = f.getInt("cross-server.mainServerPort", 25500);
/* 106 */     this.usePermissionsForTracking = f.getBoolean("usePermissionsForTracking", true);
/*     */   }
/*     */ 
/*     */   public void setDebugging(boolean value) {
/* 110 */     this.debug = value;
/*     */   }
/*     */ 
/*     */   public boolean isDebugging() {
/* 114 */     return this.debug;
/*     */   }
/*     */ 
/*     */   public boolean isUpdating() {
/* 118 */     return this.update;
/*     */   }
/*     */ 
/*     */   protected String getDbHost() {
/* 122 */     return this.dbHost;
/*     */   }
/*     */ 
/*     */   protected String getDbName() {
/* 126 */     return this.dbName;
/*     */   }
/*     */ 
/*     */   protected String getDbPass() {
/* 130 */     return this.dbPass;
/*     */   }
/*     */ 
/*     */   protected int getDbPort() {
/* 134 */     return this.dbPort;
/*     */   }
/*     */ 
/*     */   public String getDbPrefix() {
/* 138 */     return this.dbPrefix;
/*     */   }
/*     */ 
/*     */   protected String getDbUser() {
/* 142 */     return this.dbUser;
/*     */   }
/*     */ 
/*     */   public boolean isSendToGlobal() {
/* 146 */     return this.sendToGlobal;
/*     */   }
/*     */ 
/*     */   public boolean isIgnoreCreative() {
/* 150 */     return this.ignoreCreative;
/*     */   }
/*     */ 
/*     */   public boolean isInstaUpdateSigns() {
/* 154 */     return this.instaUpdateSigns;
/*     */   }
/*     */ 
/*     */   public int getSignsUpdateInterval() {
/* 158 */     return this.signsUpdateInterval;
/*     */   }
/*     */ 
/*     */   public List<String> getDisabledStats() {
/* 162 */     return this.disabled;
/*     */   }
/*     */ 
/*     */   public List<String> getCommand() {
/* 166 */     return this.command;
/*     */   }
/*     */ 
/*     */   public boolean isUsingBetaFunctions() {
/* 170 */     return this.useBetaFunctions;
/*     */   }
/*     */ 
/*     */   public String getSnapshotTTL() {
/* 174 */     return this.snapshotTimeToLive;
/*     */   }
/*     */ 
/*     */   public String getSnapshotInterval() {
/* 178 */     return this.snapshotInterval;
/*     */   }
/*     */ 
/*     */   public boolean createSnapshots() {
/* 182 */     return this.createSnapshots;
/*     */   }
/*     */ 
/*     */   public long getPreviousSnapshot() {
/* 186 */     return this.previousSnapshot;
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.Settings
 * JD-Core Version:    0.6.2
 */