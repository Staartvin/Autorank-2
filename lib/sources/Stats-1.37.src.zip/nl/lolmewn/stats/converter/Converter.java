package nl.lolmewn.stats.converter;

public abstract interface Converter
{
  public abstract void execute();
}

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.converter.Converter
 * JD-Core Version:    0.6.2
 */