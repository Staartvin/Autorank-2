package nl.lolmewn.stats.converter;

public class LogBlock
  implements Converter
{
  public void execute()
  {
  }
}

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.converter.LogBlock
 * JD-Core Version:    0.6.2
 */