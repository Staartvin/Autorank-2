/*     */ package nl.lolmewn.stats.converter;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import me.tehbeard.BeardStat.BeardStat;
/*     */ import me.tehbeard.BeardStat.containers.PlayerStat;
/*     */ import me.tehbeard.BeardStat.containers.PlayerStatBlob;
/*     */ import me.tehbeard.BeardStat.containers.PlayerStatManager;
/*     */ import net.dragonzone.promise.Promise;
/*     */ import nl.lolmewn.stats.Main;
/*     */ import nl.lolmewn.stats.StatType;
/*     */ import nl.lolmewn.stats.StatTypes;
/*     */ import nl.lolmewn.stats.api.Stat;
/*     */ import nl.lolmewn.stats.player.PlayerManager;
/*     */ import nl.lolmewn.stats.player.StatData;
/*     */ import nl.lolmewn.stats.player.StatsPlayer;
/*     */ import org.bukkit.ChatColor;
/*     */ import org.bukkit.OfflinePlayer;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class BeardStats
/*     */   implements Converter
/*     */ {
/*     */   private final Main m;
/*     */   private final boolean replace;
/*     */   private final CommandSender sender;
/*  27 */   private final List<StatType> replacedStats = new ArrayList();
/*     */ 
/*     */   public BeardStats(Main main, boolean replace, CommandSender sender) {
/*  30 */     this.m = main;
/*  31 */     this.replace = replace;
/*  32 */     this.sender = sender;
/*     */   }
/*     */ 
/*     */   public void execute()
/*     */   {
/*     */     StatsPlayer statsPlayer;
/*  37 */     for (OfflinePlayer player : this.m.getServer().getOfflinePlayers()) {
/*  38 */       Promise promiseBlob = BeardStat.self().getStatManager().findPlayerBlobASync(player.getName());
/*  39 */       if (promiseBlob != null)
/*     */       {
/*  42 */         PlayerStatBlob blob = (PlayerStatBlob)promiseBlob.getValue();
/*  43 */         statsPlayer = this.m.getPlayerManager().getPlayer(player.getName());
/*  44 */         for (PlayerStat stat : blob.getStats()) {
/*  45 */           StatType type = getStatType(stat.getCat());
/*  46 */           if (type != null)
/*     */           {
/*  49 */             if (this.replace) {
/*  50 */               if (!this.replacedStats.contains(type)) {
/*  51 */                 statsPlayer.addStat(type, new StatData(statsPlayer, (Stat)this.m.getStatTypes().get(type.makeMePretty()), type.equals(StatType.MOVE)));
/*  52 */                 this.replacedStats.add(type);
/*     */               }
/*  54 */               switch (type) {
/*     */               case MOVE:
/*  56 */                 if (stat.getName().equals("boat"))
/*  57 */                   statsPlayer.getStat(type, false).setCurrentValueDouble(new Object[] { Integer.valueOf(1) }, stat.getValue());
/*  58 */                 else if (stat.getName().equals("minecart"))
/*  59 */                   statsPlayer.getStat(type, false).setCurrentValueDouble(new Object[] { Integer.valueOf(2) }, stat.getValue());
/*     */                 else
/*  61 */                   sendMessage("So, I found a MOVE type that I don't know. Please tell Lolmewn about it, will you? " + stat.getCat() + ":" + stat.getName());
/*     */                 break;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private StatType getStatType(String cat)
/*     */   {
/* 141 */     Types t = Types.valueOf(cat);
/* 142 */     switch (1.$SwitchMap$nl$lolmewn$stats$converter$BeardStats$Types[t.ordinal()]) {
/*     */     case 1:
/* 144 */       return StatType.BLOCK_PLACE;
/*     */     case 2:
/* 146 */       return StatType.BLOCK_BREAK;
/*     */     case 3:
/* 148 */       return StatType.ARROWS;
/*     */     case 4:
/*     */     case 5:
/*     */     case 6:
/* 152 */       return null;
/*     */     case 7:
/* 154 */       return StatType.DEATH;
/*     */     case 8:
/* 156 */       return StatType.ITEMDROPS;
/*     */     case 9:
/* 158 */       return StatType.ITEMPICKUPS;
/*     */     case 10:
/* 160 */       return null;
/*     */     case 11:
/* 162 */       return StatType.KILL;
/*     */     case 12:
/* 164 */       return null;
/*     */     case 13:
/* 166 */       return StatType.MOVE;
/*     */     }
/* 168 */     return null;
/*     */   }
/*     */ 
/*     */   private void sendMessage(String message)
/*     */   {
/* 173 */     if ((this.sender != null) && ((!(this.sender instanceof Player)) || (((Player)this.sender).isOnline())))
/* 174 */       this.sender.sendMessage(ChatColor.RED + "[CV] " + ChatColor.RESET + message);
/*     */   }
/*     */ 
/*     */   private static enum DeathTypes
/*     */   {
/* 184 */     arrow, creeper, drowning, enderman, entityattack, normal_skeleton, player, skeleton, spider, total, zombie;
/*     */   }
/*     */ 
/*     */   private static enum Types
/*     */   {
/* 179 */     blockcreate, blockdestroy, bow, comp, damagedealt, damagetaken, deaths, exp, itemdrop, 
/* 180 */     itempickup, itemuse, kills, stats, vehicle;
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.converter.BeardStats
 * JD-Core Version:    0.6.2
 */