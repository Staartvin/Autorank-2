/*     */ package nl.lolmewn.stats.player;
/*     */ 
/*     */ import java.sql.Connection;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import nl.lolmewn.stats.Main;
/*     */ import nl.lolmewn.stats.MySQL;
/*     */ import nl.lolmewn.stats.Settings;
/*     */ import nl.lolmewn.stats.StatTypes;
/*     */ import nl.lolmewn.stats.api.Stat;
/*     */ import nl.lolmewn.stats.api.StatsPlayerLoadedEvent;
/*     */ import nl.lolmewn.stats.signs.SignManager;
/*     */ import nl.lolmewn.stats.signs.SignType;
/*     */ import nl.lolmewn.stats.signs.StatsSign;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class PlayerManager
/*     */ {
/*     */   private final Main plugin;
/*  22 */   private final ConcurrentHashMap<String, StatsPlayer> players = new ConcurrentHashMap();
/*     */ 
/*     */   public PlayerManager(Main m) {
/*  25 */     this.plugin = m;
/*     */   }
/*     */ 
/*     */   public boolean hasPlayer(String name) {
/*  29 */     return this.players.containsKey(name);
/*     */   }
/*     */ 
/*     */   public void addPlayer(String name, StatsPlayer player) {
/*  33 */     this.players.put(name, player);
/*     */   }
/*     */ 
/*     */   public void unloadPlayer(String name) {
/*  37 */     this.players.remove(name);
/*     */   }
/*     */ 
/*     */   public StatsPlayer getPlayer(String name) {
/*  41 */     if (!hasPlayer(name)) {
/*  42 */       StatsPlayer sp = new StatsPlayer(this.plugin, name, true);
/*  43 */       this.players.put(name, sp);
/*  44 */       loadPlayerAsync(name);
/*  45 */       return sp;
/*     */     }
/*  47 */     return (StatsPlayer)this.players.get(name);
/*     */   }
/*     */ 
/*     */   public void loadPlayerAsync(final String name) {
/*  51 */     this.plugin.getServer().getScheduler().runTaskAsynchronously(this.plugin, new Runnable()
/*     */     {
/*     */       public void run() {
/*  54 */         StatsPlayer sp = new StatsPlayer(PlayerManager.this.plugin, name, false);
/*  55 */         if ((PlayerManager.this.plugin.newConfig) || (PlayerManager.this.plugin.getMySQL() == null)) {
/*  56 */           return;
/*     */         }
/*  58 */         PlayerManager.this.plugin.debug(new StringBuilder().append("Starting to load ").append(name).append(" async...").toString());
/*  59 */         Object[] empty = new Object[0];
/*     */         try {
/*  61 */           Connection con = PlayerManager.this.plugin.getMySQL().getConnection();
/*  62 */           PreparedStatement st = con.prepareStatement(new StringBuilder().append("SELECT * FROM ").append(PlayerManager.this.plugin.getSettings().getDbPrefix()).append("player WHERE player=?").append((PlayerManager.this.plugin.getSettings().isUsingBetaFunctions()) && (PlayerManager.this.plugin.getSettings().createSnapshots()) ? " AND snapshot_name=?" : "").append(" LIMIT 1").toString());
/*     */ 
/*  64 */           st.setString(1, name);
/*  65 */           if ((PlayerManager.this.plugin.getSettings().isUsingBetaFunctions()) && (PlayerManager.this.plugin.getSettings().createSnapshots())) {
/*  66 */             st.setString(2, "main_snapshot");
/*     */           }
/*  68 */           ResultSet set = st.executeQuery();
/*  69 */           if (set.next()) {
/*  70 */             if (PlayerManager.this.plugin.getSettings().isUsingBetaFunctions()) {
/*  71 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Arrows"), set.getString("world"), true).setCurrentValue(empty, set.getInt("arrows"));
/*  72 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Playtime"), set.getString("world"), true).setCurrentValue(empty, set.getInt("playtime"));
/*  73 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Xp gained"), set.getString("world"), true).setCurrentValue(empty, set.getInt("xpgained"));
/*  74 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Joins"), set.getString("world"), true).setCurrentValue(empty, set.getInt("joins"));
/*  75 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Fish catched"), set.getString("world"), true).setCurrentValue(empty, set.getInt("fishcatch"));
/*  76 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Damage taken"), set.getString("world"), true).setCurrentValue(empty, set.getInt("damagetaken"));
/*  77 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Times kicked"), set.getString("world"), true).setCurrentValue(empty, set.getInt("timeskicked"));
/*  78 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Tools broken"), set.getString("world"), true).setCurrentValue(empty, set.getInt("toolsbroken"));
/*  79 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Eggs thrown"), set.getString("world"), true).setCurrentValue(empty, set.getInt("eggsthrown"));
/*  80 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Items crafted"), set.getString("world"), true).setCurrentValue(empty, set.getInt("itemscrafted"));
/*  81 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Omnomnom"), set.getString("world"), true).setCurrentValue(empty, set.getInt("omnomnom"));
/*  82 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("On fire"), set.getString("world"), true).setCurrentValue(empty, set.getInt("onfire"));
/*  83 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Words said"), set.getString("world"), true).setCurrentValue(empty, set.getInt("wordssaid"));
/*  84 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Commands done"), set.getString("world"), true).setCurrentValue(empty, set.getInt("commandsdone"));
/*  85 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Votes"), set.getString("world"), true).setCurrentValue(empty, set.getInt("votes"));
/*  86 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Teleports"), set.getString("world"), true).setCurrentValue(empty, set.getInt("teleports"));
/*  87 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Itempickups"), set.getString("world"), true).setCurrentValue(empty, set.getInt("itempickups"));
/*  88 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Bedenter"), set.getString("world"), true).setCurrentValue(empty, set.getInt("bedenter"));
/*  89 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Bucketfill"), set.getString("world"), true).setCurrentValue(empty, set.getInt("bucketfill"));
/*  90 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Bucketempty"), set.getString("world"), true).setCurrentValue(empty, set.getInt("bucketempty"));
/*  91 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Worldchange"), set.getString("world"), true).setCurrentValue(empty, set.getInt("worldchange"));
/*  92 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Itemdrops"), set.getString("world"), true).setCurrentValue(empty, set.getInt("itemdrops"));
/*  93 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Shear"), set.getString("world"), true).setCurrentValue(empty, set.getInt("shear"));
/*  94 */               if (set.getTimestamp("lastleave") != null) {
/*  95 */                 sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Lastjoin"), set.getString("world"), true).setCurrentValue(empty, set.getTimestamp("lastjoin").getTime());
/*     */               }
/*  97 */               if (set.getTimestamp("lastleave") != null)
/*  98 */                 sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Lastleave"), set.getString("world"), true).setCurrentValue(empty, set.getTimestamp("lastleave").getTime());
/*     */             }
/*     */             else {
/* 101 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Arrows"), true).setCurrentValue(empty, set.getInt("arrows"));
/* 102 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Playtime"), true).setCurrentValue(empty, set.getInt("playtime"));
/* 103 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Xp gained"), true).setCurrentValue(empty, set.getInt("xpgained"));
/* 104 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Joins"), true).setCurrentValue(empty, set.getInt("joins"));
/* 105 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Fish catched"), true).setCurrentValue(empty, set.getInt("fishcatch"));
/* 106 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Damage taken"), true).setCurrentValue(empty, set.getInt("damagetaken"));
/* 107 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Times kicked"), true).setCurrentValue(empty, set.getInt("timeskicked"));
/* 108 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Tools broken"), true).setCurrentValue(empty, set.getInt("toolsbroken"));
/* 109 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Eggs thrown"), true).setCurrentValue(empty, set.getInt("eggsthrown"));
/* 110 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Items crafted"), true).setCurrentValue(empty, set.getInt("itemscrafted"));
/* 111 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Omnomnom"), true).setCurrentValue(empty, set.getInt("omnomnom"));
/* 112 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("On fire"), true).setCurrentValue(empty, set.getInt("onfire"));
/* 113 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Words said"), true).setCurrentValue(empty, set.getInt("wordssaid"));
/* 114 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Commands done"), true).setCurrentValue(empty, set.getInt("commandsdone"));
/* 115 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Votes"), true).setCurrentValue(empty, set.getInt("votes"));
/* 116 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Teleports"), true).setCurrentValue(empty, set.getInt("teleports"));
/* 117 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Itempickups"), true).setCurrentValue(empty, set.getInt("itempickups"));
/* 118 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Bedenter"), true).setCurrentValue(empty, set.getInt("bedenter"));
/* 119 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Bucketfill"), true).setCurrentValue(empty, set.getInt("bucketfill"));
/* 120 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Bucketempty"), true).setCurrentValue(empty, set.getInt("bucketempty"));
/* 121 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Worldchange"), true).setCurrentValue(empty, set.getInt("worldchange"));
/* 122 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Itemdrops"), true).setCurrentValue(empty, set.getInt("itemdrops"));
/* 123 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Shear"), true).setCurrentValue(empty, set.getInt("shear"));
/* 124 */               if (set.getTimestamp("lastleave") != null) {
/* 125 */                 sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Lastjoin"), true).setCurrentValue(empty, set.getTimestamp("lastjoin").getTime());
/*     */               }
/* 127 */               if (set.getTimestamp("lastleave") != null) {
/* 128 */                 sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Lastleave"), true).setCurrentValue(empty, set.getTimestamp("lastleave").getTime());
/*     */               }
/* 130 */               sp.setHasPlayerDatabaseRow(true);
/*     */             }
/*     */           }
/* 133 */           set.close();
/* 134 */           st.close();
/* 135 */           st = con.prepareStatement(new StringBuilder().append("SELECT * FROM ").append(PlayerManager.this.plugin.getSettings().getDbPrefix()).append("move WHERE player=?").append((PlayerManager.this.plugin.getSettings().isUsingBetaFunctions()) && (PlayerManager.this.plugin.getSettings().createSnapshots()) ? " AND snapshot_name=?" : "").toString());
/*     */ 
/* 137 */           st.setString(1, name);
/* 138 */           if ((PlayerManager.this.plugin.getSettings().isUsingBetaFunctions()) && (PlayerManager.this.plugin.getSettings().createSnapshots())) {
/* 139 */             st.setString(2, "main_snapshot");
/*     */           }
/* 141 */           set = st.executeQuery();
/* 142 */           while (set.next()) {
/* 143 */             if (PlayerManager.this.plugin.getSettings().isUsingBetaFunctions())
/* 144 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Move"), set.getString("world"), true).setCurrentValue(new Object[] { Integer.valueOf(set.getInt("type")) }, set.getDouble("distance"));
/*     */             else {
/* 146 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Move"), true).setCurrentValue(new Object[] { Integer.valueOf(set.getInt("type")) }, set.getDouble("distance"));
/*     */             }
/*     */           }
/* 149 */           set.close();
/* 150 */           st.close();
/* 151 */           st = con.prepareStatement(new StringBuilder().append("SELECT * FROM ").append(PlayerManager.this.plugin.getSettings().getDbPrefix()).append("kill WHERE player=?").append((PlayerManager.this.plugin.getSettings().isUsingBetaFunctions()) && (PlayerManager.this.plugin.getSettings().createSnapshots()) ? " AND snapshot_name=?" : "").toString());
/*     */ 
/* 153 */           st.setString(1, name);
/* 154 */           if ((PlayerManager.this.plugin.getSettings().isUsingBetaFunctions()) && (PlayerManager.this.plugin.getSettings().createSnapshots())) {
/* 155 */             st.setString(2, "main_snapshot");
/*     */           }
/* 157 */           set = st.executeQuery();
/* 158 */           while (set.next()) {
/* 159 */             if (PlayerManager.this.plugin.getSettings().isUsingBetaFunctions())
/* 160 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Kill"), set.getString("world"), true).setCurrentValue(new Object[] { set.getString("type") }, set.getInt("amount"));
/*     */             else {
/* 162 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Kill"), true).setCurrentValue(new Object[] { set.getString("type") }, set.getInt("amount"));
/*     */             }
/*     */           }
/* 165 */           set.close();
/* 166 */           st.close();
/* 167 */           st = con.prepareStatement(new StringBuilder().append("SELECT * FROM ").append(PlayerManager.this.plugin.getSettings().getDbPrefix()).append("death WHERE player=?").append((PlayerManager.this.plugin.getSettings().isUsingBetaFunctions()) && (PlayerManager.this.plugin.getSettings().createSnapshots()) ? " AND snapshot_name=?" : "").toString());
/*     */ 
/* 169 */           st.setString(1, name);
/* 170 */           if ((PlayerManager.this.plugin.getSettings().isUsingBetaFunctions()) && (PlayerManager.this.plugin.getSettings().createSnapshots())) {
/* 171 */             st.setString(2, "main_snapshot");
/*     */           }
/* 173 */           set = st.executeQuery();
/* 174 */           while (set.next()) {
/* 175 */             if (PlayerManager.this.plugin.getSettings().isUsingBetaFunctions())
/* 176 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Death"), set.getString("world"), true).setCurrentValue(new Object[] { set.getString("cause"), Boolean.valueOf(set.getBoolean("entity")) }, set.getInt("amount"));
/*     */             else {
/* 178 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Death"), true).setCurrentValue(new Object[] { set.getString("cause"), Boolean.valueOf(set.getBoolean("entity")) }, set.getInt("amount"));
/*     */             }
/*     */           }
/* 181 */           set.close();
/* 182 */           st.close();
/* 183 */           st = con.prepareStatement(new StringBuilder().append("SELECT * FROM ").append(PlayerManager.this.plugin.getSettings().getDbPrefix()).append("block WHERE player=?").append((PlayerManager.this.plugin.getSettings().isUsingBetaFunctions()) && (PlayerManager.this.plugin.getSettings().createSnapshots()) ? " AND snapshot_name=?" : "").toString());
/*     */ 
/* 185 */           st.setString(1, name);
/* 186 */           if ((PlayerManager.this.plugin.getSettings().isUsingBetaFunctions()) && (PlayerManager.this.plugin.getSettings().createSnapshots())) {
/* 187 */             st.setString(2, "main_snapshot");
/*     */           }
/* 189 */           set = st.executeQuery();
/* 190 */           while (set.next()) {
/* 191 */             Byte blockData = Byte.valueOf(set.getByte("blockData"));
/* 192 */             if (PlayerManager.this.plugin.getSettings().isUsingBetaFunctions()) {
/* 193 */               if (set.getBoolean("break")) {
/* 194 */                 sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Block break"), set.getString("world"), true).setCurrentValue(new Object[] { Integer.valueOf(set.getInt("blockID")), Byte.valueOf(blockData.byteValue()), Boolean.valueOf(true) }, set.getInt("amount"));
/*     */               }
/*     */               else
/*     */               {
/* 198 */                 sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Block place"), set.getString("world"), true).setCurrentValue(new Object[] { Integer.valueOf(set.getInt("blockID")), Byte.valueOf(blockData.byteValue()), Boolean.valueOf(false) }, set.getInt("amount"));
/*     */               }
/*     */             }
/* 201 */             else if (set.getBoolean("break"))
/*     */             {
/* 203 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Block break"), true).setCurrentValue(new Object[] { Integer.valueOf(set.getInt("blockID")), Byte.valueOf(blockData.byteValue()), Boolean.valueOf(true) }, set.getInt("amount"));
/*     */             }
/*     */             else {
/* 206 */               sp.getStatData((Stat)PlayerManager.this.plugin.getStatTypes().get("Block place"), true).setCurrentValue(new Object[] { Integer.valueOf(set.getInt("blockID")), Byte.valueOf(blockData.byteValue()), Boolean.valueOf(false) }, set.getInt("amount"));
/*     */             }
/*     */           }
/*     */ 
/* 210 */           set.close();
/* 211 */           st.close();
/* 212 */           con.close();
/*     */         } catch (SQLException e) {
/* 214 */           Logger.getLogger(PlayerManager.class.getName()).log(Level.SEVERE, null, e);
/*     */         }
/* 216 */         if (PlayerManager.this.players.containsKey(name)) {
/* 217 */           StatsPlayer old = (StatsPlayer)PlayerManager.this.players.get(name);
/* 218 */           PlayerManager.this.players.put(name, sp);
/* 219 */           sp.syncData(old);
/*     */         } else {
/* 221 */           PlayerManager.this.players.put(name, sp);
/*     */         }
/* 223 */         if (PlayerManager.this.plugin.getSettings().isInstaUpdateSigns()) {
/* 224 */           for (StatsSign sign : PlayerManager.this.plugin.getSignManager().getAllSigns()) {
/* 225 */             if ((sign.getSignType().equals(SignType.PLAYER)) && (name.startsWith(sign.getVariable()))) {
/* 226 */               if (PlayerManager.this.plugin.getSettings().isUsingBetaFunctions())
/* 227 */                 sp.addSignReference(sign, sign.getWorld());
/*     */               else {
/* 229 */                 sp.addSignReference(sign);
/*     */               }
/* 231 */               sign.setAttachedToStat(true);
/*     */             }
/*     */           }
/*     */         }
/* 235 */         StatsPlayerLoadedEvent event = new StatsPlayerLoadedEvent(sp, true);
/* 236 */         PlayerManager.this.plugin.getServer().getPluginManager().callEvent(event);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public Iterable<StatsPlayer> getPlayers() {
/* 242 */     return this.players.values();
/*     */   }
/*     */ 
/*     */   public StatsPlayer matchPlayerPartially(String variable) {
/* 246 */     if (this.players.containsKey(variable)) {
/* 247 */       return (StatsPlayer)this.players.get(variable);
/*     */     }
/* 249 */     for (String playerName : this.players.keySet()) {
/* 250 */       if (playerName.startsWith(variable)) {
/* 251 */         return (StatsPlayer)this.players.get(playerName);
/*     */       }
/*     */     }
/* 254 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.player.PlayerManager
 * JD-Core Version:    0.6.2
 */