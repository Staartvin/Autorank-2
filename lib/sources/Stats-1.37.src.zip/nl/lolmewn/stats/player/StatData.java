/*     */ package nl.lolmewn.stats.player;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import nl.lolmewn.stats.Main;
/*     */ import nl.lolmewn.stats.api.Stat;
/*     */ import nl.lolmewn.stats.api.StatUpdateEvent;
/*     */ import nl.lolmewn.stats.signs.StatsSign;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public class StatData
/*     */ {
/*     */   private Stat type;
/*     */   private StatsPlayer superClass;
/*     */   private ConcurrentHashMap<String, Double> rows;
/*     */   private ConcurrentHashMap<String, Double> currentValues;
/*  24 */   private final Set<String> hasUpdate = Collections.synchronizedSet(new HashSet());
/*  25 */   private final ConcurrentHashMap<String, Object[]> linker = new ConcurrentHashMap();
/*  26 */   private final ConcurrentHashMap<String, String> signs = new ConcurrentHashMap();
/*     */ 
/*     */   public StatData(StatsPlayer superClass, Stat type, boolean usingDouble) {
/*  29 */     this(superClass, type);
/*     */   }
/*     */ 
/*     */   public StatData(StatsPlayer superClass, Stat type) {
/*  33 */     this.superClass = superClass;
/*  34 */     this.type = type;
/*  35 */     this.rows = new ConcurrentHashMap();
/*  36 */     this.currentValues = new ConcurrentHashMap();
/*     */   }
/*     */ 
/*     */   public Stat getStat() {
/*  40 */     return this.type;
/*     */   }
/*     */ 
/*     */   public StatsPlayer getStatsPlayer() {
/*  44 */     return this.superClass;
/*     */   }
/*     */ 
/*     */   public boolean hasUpdate(Object[] variables) {
/*  48 */     return this.hasUpdate.contains(Arrays.toString(variables));
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public double getUpdateValueDouble(Object[] variables, boolean updatingDatabase) {
/*  53 */     return getUpdateValue(variables, updatingDatabase);
/*     */   }
/*     */ 
/*     */   public double getUpdateValue(Object[] variables, boolean updatingDatabase) {
/*  57 */     String hash = Arrays.toString(variables);
/*  58 */     if (!this.currentValues.containsKey(hash)) {
/*  59 */       if (updatingDatabase) {
/*  60 */         this.currentValues.put(hash, this.rows.get(hash));
/*  61 */         this.hasUpdate.remove(hash);
/*     */       }
/*  63 */       return this.rows.contains(hash) ? ((Double)this.rows.get(hash)).doubleValue() : 0.0D;
/*     */     }
/*  65 */     double update = hasUpdate(variables) ? ((Double)this.rows.get(hash)).doubleValue() - ((Double)this.currentValues.get(hash)).doubleValue() : 0.0D;
/*  66 */     if (updatingDatabase) {
/*  67 */       this.currentValues.put(hash, this.rows.get(hash));
/*  68 */       this.hasUpdate.remove(hash);
/*     */     }
/*  70 */     return update;
/*     */   }
/*     */ 
/*     */   public void addUpdate(final Object[] variables, double add) {
/*  74 */     final StatUpdateEvent event = new StatUpdateEvent(this, add, variables, true);
/*  75 */     final boolean temp = this.superClass.isTemp();
/*  76 */     Bukkit.getScheduler().runTaskAsynchronously(this.superClass.getPlugin(), new Runnable()
/*     */     {
/*     */       public void run() {
/*  79 */         if (!temp) {
/*  80 */           Bukkit.getPluginManager().callEvent(event);
/*     */         }
/*  82 */         if (event.isCancelled()) {
/*  83 */           return;
/*     */         }
/*  85 */         String hash = Arrays.toString(variables);
/*  86 */         if (StatData.this.rows.containsKey(hash)) {
/*  87 */           StatData.this.rows.put(hash, Double.valueOf(((Double)StatData.this.rows.get(hash)).doubleValue() + event.getUpdateValue()));
/*     */         } else {
/*  89 */           StatData.this.rows.put(hash, Double.valueOf(event.getUpdateValue()));
/*  90 */           StatData.this.linker.put(hash, variables);
/*     */         }
/*  92 */         if (!StatData.this.hasUpdate(variables))
/*  93 */           StatData.this.hasUpdate.add(hash);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void addUpdateDouble(Object[] variables, double add)
/*     */   {
/* 107 */     addUpdate(variables, add);
/*     */   }
/*     */ 
/*     */   public void setCurrentValue(Object[] variables, double value) {
/* 111 */     String hash = Arrays.toString(variables);
/* 112 */     this.currentValues.put(hash, Double.valueOf(value));
/* 113 */     this.rows.put(hash, Double.valueOf(value));
/* 114 */     this.linker.put(hash, variables);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void setCurrentValueDouble(Object[] variables, double value) {
/* 119 */     setCurrentValue(variables, value);
/*     */   }
/*     */ 
/*     */   public HashSet<Object[]> getUpdateVariables() {
/* 123 */     HashSet withUpdates = new HashSet();
/* 124 */     for (String hash : this.hasUpdate) {
/* 125 */       withUpdates.add(this.linker.get(hash));
/*     */     }
/* 127 */     return withUpdates;
/*     */   }
/*     */ 
/*     */   public Collection<Object[]> getAllVariables() {
/* 131 */     return this.linker.values();
/*     */   }
/*     */ 
/*     */   public double getValue(Object[] vars) {
/* 135 */     if (!this.rows.containsKey(Arrays.toString(vars))) {
/* 136 */       return 0.0D;
/*     */     }
/* 138 */     return ((Double)this.rows.get(Arrays.toString(vars))).doubleValue();
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public double getValueDouble(Object[] vars) {
/* 143 */     return getValue(vars);
/*     */   }
/*     */ 
/*     */   public double getValueUnsafe() {
/* 147 */     if (this.rows != null) {
/* 148 */       return ((Double)this.rows.get(this.rows.keySet().iterator().next())).doubleValue();
/*     */     }
/* 150 */     return -1.0D;
/*     */   }
/*     */ 
/*     */   public boolean hasValue(Object[] object) {
/* 154 */     if (this.rows != null) {
/* 155 */       return this.rows.containsKey(Arrays.toString(object));
/*     */     }
/* 157 */     return false;
/*     */   }
/*     */ 
/*     */   public void forceUpdate(Object[] variables) {
/* 161 */     this.hasUpdate.add(Arrays.toString(variables));
/*     */   }
/*     */ 
/*     */   public void removeHasUpdate(Object[] object) {
/* 165 */     this.hasUpdate.remove(Arrays.toString(object));
/*     */   }
/*     */ 
/*     */   public void addSign(StatsSign sign, Object[] vars) {
/* 169 */     String hash = Arrays.toString(vars);
/* 170 */     this.signs.put(sign.getLocationString(), hash);
/* 171 */     if (!this.linker.containsKey(hash)) {
/* 172 */       this.linker.put(hash, vars);
/*     */     }
/* 174 */     sign.setAttachedToStat(true);
/*     */   }
/*     */ 
/*     */   public Collection<String> getSignLocations() {
/* 178 */     return this.signs.keySet();
/*     */   }
/*     */ 
/*     */   public boolean hasSigns() {
/* 182 */     return !this.signs.isEmpty();
/*     */   }
/*     */ 
/*     */   public void debug() {
/* 186 */     Main p = this.superClass.getPlugin();
/* 187 */     p.debug("=====" + getStat().toString() + "=====");
/* 188 */     p.debug("Rows");
/* 189 */     for (String value : this.rows.keySet()) {
/* 190 */       p.debug("  " + value + ": " + this.rows.get(value));
/*     */     }
/* 192 */     p.debug("Current values");
/* 193 */     for (String value : this.currentValues.keySet()) {
/* 194 */       p.debug("  " + value + ": " + this.currentValues.get(value));
/*     */     }
/* 196 */     p.debug("Update arrays");
/* 197 */     for (String array : this.hasUpdate)
/* 198 */       p.debug(array);
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.player.StatData
 * JD-Core Version:    0.6.2
 */