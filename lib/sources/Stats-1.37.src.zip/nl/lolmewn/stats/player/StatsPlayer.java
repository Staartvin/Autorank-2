/*     */ package nl.lolmewn.stats.player;
/*     */ 
/*     */ import java.util.Arrays;
/*     */ import java.util.Iterator;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import nl.lolmewn.stats.Main;
/*     */ import nl.lolmewn.stats.Settings;
/*     */ import nl.lolmewn.stats.StatType;
/*     */ import nl.lolmewn.stats.StatTypes;
/*     */ import nl.lolmewn.stats.api.Stat;
/*     */ import nl.lolmewn.stats.api.StatsAPI;
/*     */ import nl.lolmewn.stats.signs.StatsSign;
/*     */ import org.apache.commons.lang.Validate;
/*     */ 
/*     */ public class StatsPlayer
/*     */ {
/*     */   private ConcurrentHashMap<String, ConcurrentHashMap<Stat, StatData>> worldStats;
/*     */   private ConcurrentHashMap<String, StatData> stats;
/*     */   private final String playername;
/*  25 */   private boolean hasDBRow = false;
/*     */   private final Main plugin;
/*     */   private final boolean temp;
/*     */ 
/*     */   public StatsPlayer(Main m, String playername, boolean temp)
/*     */   {
/*  30 */     this.plugin = m;
/*  31 */     this.playername = playername;
/*  32 */     this.temp = temp;
/*  33 */     if (m.getSettings().isUsingBetaFunctions())
/*  34 */       this.worldStats = new ConcurrentHashMap();
/*     */     else
/*  36 */       this.stats = new ConcurrentHashMap();
/*     */   }
/*     */ 
/*     */   public String getPlayername()
/*     */   {
/*  41 */     return this.playername;
/*     */   }
/*     */ 
/*     */   protected Main getPlugin() {
/*  45 */     return this.plugin;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public boolean hasStat(StatType type)
/*     */   {
/*  58 */     Validate.notNull(type);
/*  59 */     return this.stats.containsKey(type.makeMePretty());
/*     */   }
/*     */ 
/*     */   public boolean hasStat(Stat stat) {
/*  63 */     Validate.notNull(stat);
/*  64 */     return this.stats.containsKey(stat.getName());
/*     */   }
/*     */ 
/*     */   public boolean hasStat(Stat stat, String world) {
/*  68 */     Validate.notNull(stat);
/*  69 */     Validate.notNull(world);
/*  70 */     if ((this.worldStats.containsKey(world)) && (((ConcurrentHashMap)this.worldStats.get(world)).containsKey(stat))) {
/*  71 */       return true;
/*     */     }
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void addStat(StatType type, StatData stat) {
/*  78 */     Validate.notNull(type);
/*  79 */     Validate.notNull(stat);
/*  80 */     this.stats.put(type.makeMePretty(), stat);
/*     */   }
/*     */ 
/*     */   public void addStat(Stat stat, StatData statData) {
/*  84 */     Validate.notNull(stat);
/*  85 */     Validate.notNull(statData);
/*  86 */     this.stats.put(stat.getName(), statData);
/*     */   }
/*     */ 
/*     */   public void addStat(final Stat stat, final StatData statData, String world) {
/*  90 */     Validate.notNull(stat);
/*  91 */     Validate.notNull(statData);
/*  92 */     Validate.notNull(world);
/*  93 */     if (this.worldStats.containsKey(world))
/*  94 */       ((ConcurrentHashMap)this.worldStats.get(world)).put(stat, statData);
/*     */     else
/*  96 */       this.worldStats.put(world, new ConcurrentHashMap()
/*     */       {
/*     */       });
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public StatData getStat(StatType type, boolean createIfNotExists)
/*     */   {
/* 106 */     Validate.notNull(type);
/* 107 */     if ((!hasStat(type)) && (createIfNotExists)) {
/* 108 */       Stat stat = getPlugin().getAPI().getStat(type.makeMePretty());
/* 109 */       addStat(type, new StatData(this, stat, type.equals(StatType.MOVE)));
/* 110 */       return getStat(type, false);
/*     */     }
/* 112 */     return (StatData)this.stats.get(type.makeMePretty());
/*     */   }
/*     */ 
/*     */   public StatData getStatData(Stat stat, boolean createIfNotExists) {
/* 116 */     Validate.notNull(stat);
/* 117 */     if ((!hasStat(stat)) && (createIfNotExists)) {
/* 118 */       addStat(stat, new StatData(this, stat));
/* 119 */       return getStatData(stat, false);
/*     */     }
/* 121 */     return (StatData)this.stats.get(stat.getName());
/*     */   }
/*     */ 
/*     */   public StatData getStatData(Stat stat, String world, boolean createIfNotExists) {
/* 125 */     Validate.notNull(stat);
/* 126 */     Validate.notNull(world);
/* 127 */     if ((!hasStat(stat, world)) && (createIfNotExists)) {
/* 128 */       addStat(stat, new StatData(this, stat), world);
/* 129 */       return getStatData(stat, world, false);
/*     */     }
/* 131 */     if (!this.worldStats.containsKey(world)) {
/* 132 */       return null;
/*     */     }
/* 134 */     return (StatData)((ConcurrentHashMap)this.worldStats.get(world)).get(stat);
/*     */   }
/*     */ 
/*     */   private Stat getStat(String name) {
/* 138 */     return (Stat)this.plugin.getStatTypes().get(name);
/*     */   }
/*     */ 
/*     */   @Deprecated
/*     */   public void updateStat(StatType type, Object[] variables, int value) {
/* 143 */     Validate.notNull(type);
/* 144 */     StatData stat = getStat(type, true);
/* 145 */     stat.addUpdate(variables, value);
/*     */   }
/*     */ 
/*     */   public void updateStat(Stat stat, Object[] variables, double value) {
/* 149 */     Validate.notNull(stat);
/* 150 */     getStatData(stat, true).addUpdate(variables, value);
/*     */   }
/*     */ 
/*     */   public void updateStat(Stat stat, Object[] variables, double value, String world) {
/* 154 */     Validate.notNull(stat);
/* 155 */     Validate.notNull(world);
/* 156 */     getStatData(stat, world, true).addUpdate(variables, value);
/*     */   }
/*     */ 
/*     */   public Iterable<StatData> getStats() {
/* 160 */     return this.stats.values();
/*     */   }
/*     */ 
/*     */   public Iterable<StatData> getStatsForWorld(String world) {
/* 164 */     return ((ConcurrentHashMap)this.worldStats.get(world)).values();
/*     */   }
/*     */ 
/*     */   public Iterable<String> getWorlds() {
/* 168 */     return this.worldStats.keySet();
/*     */   }
/*     */ 
/*     */   public ConcurrentHashMap<String, ConcurrentHashMap<Stat, StatData>> getWorldStats() {
/* 172 */     return this.worldStats;
/*     */   }
/*     */ 
/*     */   public boolean hasPlayerDatabaseRow() {
/* 176 */     return this.hasDBRow;
/*     */   }
/*     */ 
/*     */   public void setHasPlayerDatabaseRow(boolean value) {
/* 180 */     this.hasDBRow = value;
/*     */   }
/*     */ 
/*     */   public void syncData(StatsPlayer get)
/*     */   {
/*     */     try
/*     */     {
/* 194 */       Thread.sleep(50L);
/*     */     } catch (InterruptedException ex) {
/* 196 */       Logger.getLogger(StatsPlayer.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/* 198 */     getPlugin().debug("Sync initiated for " + getPlayername());
/*     */     Iterator i$;
/*     */     String world;
/*     */     Iterator i$;
/*     */     StatData statData;
/*     */     Iterator i$;
/* 199 */     if (this.plugin.getSettings().isUsingBetaFunctions())
/* 200 */       for (i$ = get.getWorlds().iterator(); i$.hasNext(); ) { world = (String)i$.next();
/* 201 */         for (i$ = get.getStatsForWorld(world).iterator(); i$.hasNext(); ) { statData = (StatData)i$.next();
/* 202 */           getPlugin().debug("Syncing " + statData.getStat().toString());
/* 203 */           statData.debug();
/* 204 */           for (Object[] vars : statData.getUpdateVariables()) {
/* 205 */             getPlugin().debug("Update vars: " + Arrays.toString(vars));
/* 206 */             if ((statData.getStat().equals(getStat("Lastjoin"))) || (statData.getStat().equals(getStat("Lastleave")))) {
/* 207 */               double syncValue = statData.getValue(vars);
/* 208 */               getStatData(statData.getStat(), world, true).setCurrentValue(vars, syncValue);
/* 209 */               getStatData(statData.getStat(), world, true).forceUpdate(vars);
/*     */             }
/*     */             else {
/* 212 */               double syncValue = statData.getValue(vars);
/* 213 */               getStatData(statData.getStat(), world, true).addUpdate(vars, syncValue);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     else
/* 219 */       for (i$ = get.getStats().iterator(); i$.hasNext(); ) { statData = (StatData)i$.next();
/* 220 */         getPlugin().debug("Syncing " + statData.getStat().toString());
/* 221 */         statData.debug();
/* 222 */         for (Object[] vars : statData.getUpdateVariables()) {
/* 223 */           getPlugin().debug("Update vars: " + Arrays.toString(vars));
/* 224 */           if ((statData.getStat().equals(getStat("Lastjoin"))) || (statData.getStat().equals(getStat("Lastleave")))) {
/* 225 */             double syncValue = statData.getValue(vars);
/* 226 */             getStatData(statData.getStat(), true).setCurrentValue(vars, syncValue);
/* 227 */             getStatData(statData.getStat(), true).forceUpdate(vars);
/*     */           }
/*     */           else {
/* 230 */             double syncValue = statData.getValue(vars);
/* 231 */             getStatData(statData.getStat(), true).addUpdate(vars, syncValue);
/*     */           }
/*     */         } }
/*     */     StatData statData;
/*     */   }
/*     */ 
/*     */   public void addSignReference(StatsSign sign) {
/* 238 */     Validate.notNull(sign);
/* 239 */     getStatData(sign.getStat(), true).addSign(sign, new Object[0]);
/*     */   }
/*     */ 
/*     */   public void addSignReference(StatsSign sign, String world) {
/* 243 */     Validate.notNull(sign);
/* 244 */     Validate.notNull(world);
/* 245 */     getStatData(sign.getStat(), world, true).addSign(sign, new Object[0]);
/*     */   }
/*     */ 
/*     */   public boolean isTemp() {
/* 249 */     return this.temp;
/*     */   }
/*     */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.player.StatsPlayer
 * JD-Core Version:    0.6.2
 */