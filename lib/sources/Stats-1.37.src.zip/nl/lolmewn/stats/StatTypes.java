/*    */ package nl.lolmewn.stats;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import nl.lolmewn.stats.api.Stat;
/*    */ 
/*    */ public class StatTypes extends HashMap<String, Stat>
/*    */ {
/*    */   private static final long serialVersionUID = 1337L;
/*    */ 
/*    */   public Stat addStat(String name, String update, String insert)
/*    */   {
/* 21 */     return addStat(name, new Stat(name, update, insert));
/*    */   }
/*    */ 
/*    */   public Stat addStat(String name, Stat stat) {
/* 25 */     put(name, stat);
/* 26 */     return stat;
/*    */   }
/*    */ 
/*    */   public Stat find(String line) {
/* 30 */     if (line == null) {
/* 31 */       return null;
/*    */     }
/* 33 */     for (String stat : keySet()) {
/* 34 */       if (line.toLowerCase().equals(stat.toLowerCase())) {
/* 35 */         return (Stat)get(stat);
/*    */       }
/* 37 */       if (stat.toLowerCase().startsWith(line.toLowerCase())) {
/* 38 */         return (Stat)get(stat);
/*    */       }
/* 40 */       if (stat.toLowerCase().replace(" ", "").equals(line.toLowerCase())) {
/* 41 */         return (Stat)get(stat);
/*    */       }
/*    */     }
/* 44 */     return null;
/*    */   }
/*    */ }

/* Location:           D:\Users\Vincent\Desktop\Shortcuts\JD-GUI\Projects\Stats-1.37.jar
 * Qualified Name:     nl.lolmewn.stats.StatTypes
 * JD-Core Version:    0.6.2
 */